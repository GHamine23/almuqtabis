/**
 * خادم «المقتبس» على سحابتك في جوجل.
 * يحفظ المقتبسات في درايف، وينشر المجدول منها في التليجرام في موعده،
 * ويحوّل دفاتر الكناشة إلى مستندات جوجل مرتبة في مجلدات.
 *
 * طريقة التشغيل (مرة واحدة):
 *  ١. اختر الدالة setup من القائمة أعلى المحرر واضغط «تشغيل»، ووافق على الأذونات.
 *  ٢. «نشر» ← «نشر جديد» ← النوع: تطبيق ويب ← التنفيذ: «أنا» ← الوصول: «أي شخص».
 *  ٣. انسخ رابط تطبيق الويب (ينتهي بـ exec) والصقه في إعدادات المقتبس.
 */

var SECRET = '__MQ_SECRET__';           // يُملأ تلقائيًا من الإضافة
var ROOT_NAME = 'المقتبس';
var TICK_MINUTES = 5;

// ---------------------------------------------------------------- الإعداد
function setup() {
  var root = rootFolder_();
  sub_(root, 'المقتطفات'); sub_(root, 'الكناشة'); sub_(root, 'النظام');
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'tick') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('tick').timeBased().everyMinutes(TICK_MINUTES).create();
  Logger.log('تمّ الإعداد. المجلد الرئيسي: ' + root.getUrl());
}

// ---------------------------------------------------------------- نقطة الدخول
function doPost(e) {
  var out;
  try {
    var req = JSON.parse(e.postData.contents);
    if (!req || req.key !== SECRET) throw new Error('مفتاح الربط غير صحيح.');
    var fn = ACTIONS[req.action];
    if (!fn) throw new Error('إجراء غير معروف: ' + req.action);
    out = { ok: true, result: fn(req.data || {}) };
  } catch (err) {
    out = { ok: false, error: String(err && err.message || err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}
function doGet() {
  return ContentService.createTextOutput('المقتبس: الخادم يعمل.');
}

var ACTIONS = {
  ping: function () {
    var root = rootFolder_();
    return { email: Session.getEffectiveUser().getEmail(), rootUrl: root.getUrl(), version: 2, trigger: hasTrigger_() };
  },

  // ---------- الرفع إلى درايف ----------
  'upload.start': function (d) {
    var folder = path_(d.path || ['المقتطفات']);
    var res = UrlFetchApp.fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id', {
      method: 'post',
      contentType: 'application/json; charset=UTF-8',
      headers: {
        Authorization: 'Bearer ' + ScriptApp.getOAuthToken(),
        'X-Upload-Content-Type': d.mimeType || 'application/octet-stream',
        'X-Upload-Content-Length': String(d.size || 0)
      },
      payload: JSON.stringify({ name: d.name, parents: [folder.getId()] }),
      muteHttpExceptions: true
    });
    if (res.getResponseCode() >= 300) throw new Error('تعذّر فتح جلسة الرفع: ' + res.getContentText().slice(0, 200));
    var h = res.getAllHeaders();
    var url = h.Location || h.location;
    if (!url) throw new Error('لم يُرجع درايف رابط الرفع.');
    return { uploadUrl: url };
  },
  'upload.direct': function (d) {
    var folder = path_(d.path || ['المقتطفات']);
    var blob = Utilities.newBlob(Utilities.base64Decode(d.b64), d.mimeType || 'application/octet-stream', d.name);
    var f = folder.createFile(blob);
    if (d.share) f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return { fileId: f.getId(), url: f.getUrl(), name: f.getName(), shared: !!d.share };
  },
  'upload.finish': function (d) {
    var f = DriveApp.getFileById(d.fileId);
    if (d.share) f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return { fileId: f.getId(), url: f.getUrl(), name: f.getName(), shared: !!d.share };
  },
  share: function (d) {
    var f = DriveApp.getFileById(d.fileId);
    f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    return { url: f.getUrl() };
  },
  'file.trash': function (d) { DriveApp.getFileById(d.fileId).setTrashed(true); return {}; },

  // ---------- الجدولة ----------
  'queue.put': function (d) {
    var lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      var q = readJson_('queue.json', []);
      (d.items || []).forEach(function (it) {
        var i = indexOf_(q, it.id);
        var keep = i >= 0 ? q[i] : {};
        var next = Object.assign({}, keep, it);
        if (!next.status || next.status === 'failed') next.status = 'scheduled';
        if (it.reset) { next.status = 'scheduled'; next.error = ''; delete next.reset; }
        if (i >= 0) q[i] = next; else q.push(next);
      });
      writeJson_('queue.json', q);
      return { count: q.length };
    } finally { lock.releaseLock(); }
  },
  'queue.remove': function (d) {
    var lock = LockService.getScriptLock(); lock.waitLock(20000);
    try {
      var ids = d.ids || [d.id];
      var q = readJson_('queue.json', []).filter(function (x) { return ids.indexOf(x.id) < 0; });
      writeJson_('queue.json', q);
      return { count: q.length };
    } finally { lock.releaseLock(); }
  },
  'queue.list': function () {
    return readJson_('queue.json', []).map(function (x) {
      return { id: x.id, status: x.status, at: x.at, sentAt: x.sentAt || 0, messageId: x.messageId || 0, error: x.error || '' };
    });
  },
  'queue.runNow': function () { tick(); return ACTIONS['queue.list'](); },

  // ---------- الكناشة ----------
  'notebook.ensure': function (d) {
    var f = notebookFolder_(d.id, d.title);
    return { folderId: f.getId(), url: f.getUrl() };
  },
  'notebook.rename': function (d) {
    var f = notebookFolder_(d.id, d.title);
    if (f.getName() !== d.title) f.setName(d.title);
    return { folderId: f.getId() };
  },
  'note.sync': function (d) {
    var folder = notebookFolder_(d.notebook.id, d.notebook.title);
    var doc = null;
    if (d.docId) { try { doc = DocumentApp.openById(d.docId); } catch (e) { doc = null; } }
    if (!doc) {
      doc = DocumentApp.create(d.note.title || 'تدوين');
      var file = DriveApp.getFileById(doc.getId());
      file.moveTo(folder);
    } else {
      var file2 = DriveApp.getFileById(doc.getId());
      var parents = file2.getParents();
      if (!parents.hasNext() || parents.next().getId() !== folder.getId()) file2.moveTo(folder);
    }
    buildDoc_(doc, d.note);
    if (doc.getName() !== (d.note.title || 'تدوين')) doc.setName(d.note.title || 'تدوين');
    doc.saveAndClose();
    return { docId: doc.getId(), url: 'https://docs.google.com/document/d/' + doc.getId() + '/edit', folderId: folder.getId(), folderUrl: folder.getUrl() };
  },
  'note.trash': function (d) { if (d.docId) DriveApp.getFileById(d.docId).setTrashed(true); return {}; },

  // ---------- الفهرس (للتطبيق والموقع لاحقًا) ----------
  'index.put': function (d) {
    writeJson_('index.json', { updatedAt: Date.now(), quotes: d.quotes || [], notebooks: d.notebooks || [] });
    return { ok: true };
  }
};

// ---------------------------------------------------------------- النشر المجدول
function tick() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return;
  try {
    var q = readJson_('queue.json', []);
    var now = Date.now(), changed = false, sentThisRun = 0;
    for (var i = 0; i < q.length && sentThisRun < 6; i++) {
      var it = q[i];
      if (it.status !== 'scheduled' || !it.at || it.at > now) continue;
      try {
        var r = sendVideo_(it);
        it.status = 'sent'; it.sentAt = Date.now(); it.messageId = r.message_id; it.error = '';
      } catch (err) {
        it.tries = (it.tries || 0) + 1;
        it.error = String(err && err.message || err);
        if (it.tries >= 3) it.status = 'failed';
      }
      changed = true; sentThisRun++;
    }
    // تنظيف ما أُرسل قبل أكثر من 60 يومًا
    var cutoff = now - 60 * 86400000;
    var kept = q.filter(function (x) { return !(x.status === 'sent' && x.sentAt && x.sentAt < cutoff); });
    if (kept.length !== q.length) { q = kept; changed = true; }
    if (changed) writeJson_('queue.json', q);
  } finally { lock.releaseLock(); }
}

function sendVideo_(it) {
  var blob = DriveApp.getFileById(it.fileId).getBlob();
  var payload = { chat_id: String(it.chatId), video: blob, supports_streaming: 'true' };
  if (it.caption) { payload.caption = it.caption; payload.parse_mode = 'HTML'; }
  if (it.silent) payload.disable_notification = 'true';
  if (it.duration) payload.duration = String(Math.round(it.duration));
  if (it.w) payload.width = String(it.w);
  if (it.h) payload.height = String(it.h);
  if (it.coverFileId) { try { payload.cover = DriveApp.getFileById(it.coverFileId).getBlob(); } catch (e) {} }
  var res = UrlFetchApp.fetch('https://api.telegram.org/bot' + it.token + '/sendVideo', {
    method: 'post', payload: payload, muteHttpExceptions: true
  });
  var j = JSON.parse(res.getContentText() || '{}');
  if (!j.ok) throw new Error(j.description || ('HTTP ' + res.getResponseCode()));
  return j.result;
}

// ---------------------------------------------------------------- بناء المستند
var STYLE = { font: 'Noto Naskh Arabic', ink: '#23261F', muted: '#868A7C', accent: '#4A5A32', copper: '#A56C3C' };

function rtl_(p) { p.setLeftToRight(false); p.setAlignment(DocumentApp.HorizontalAlignment.RIGHT); return p; }

function buildDoc_(doc, note) {
  var body = doc.getBody();
  body.clear();
  body.setMarginTop(56).setMarginBottom(56).setMarginLeft(64).setMarginRight(64);

  var t = rtl_(body.getParagraphs()[0]);
  t.setText(note.title || 'تدوين');
  t.setHeading(DocumentApp.ParagraphHeading.TITLE);
  style_(t.editAsText(), { size: 24, bold: true, color: STYLE.ink });

  var m = note.meta || {};
  var metaParts = [];
  if (m.videoTitle) metaParts.push('المحاضرة: ' + m.videoTitle);
  if (m.speaker) metaParts.push('المحاضر: ' + m.speaker);
  if (m.series) metaParts.push('السلسلة: ' + m.series);
  if (metaParts.length) {
    var mp = rtl_(body.appendParagraph(metaParts.join('   ·   ')));
    style_(mp.editAsText(), { size: 10.5, color: STYLE.muted });
  }
  if (m.link) {
    var lp = rtl_(body.appendParagraph('مشاهدة المحاضرة'));
    style_(lp.editAsText(), { size: 10.5, color: STYLE.accent });
    lp.editAsText().setLinkUrl(m.link);
  }
  var dates = [];
  if (m.created) dates.push('كُتب: ' + m.created);
  if (m.updated && m.updated !== m.created) dates.push('آخر تعديل: ' + m.updated);
  if (dates.length) { var dp = rtl_(body.appendParagraph(dates.join('   ·   '))); style_(dp.editAsText(), { size: 9.5, color: STYLE.muted }); }
  if (note.tags && note.tags.length) {
    var tp = rtl_(body.appendParagraph(note.tags.map(function (x) { return '#' + x; }).join('  ')));
    style_(tp.editAsText(), { size: 10, color: STYLE.copper });
  }
  body.appendHorizontalRule();

  (note.blocks || []).forEach(function (b) {
    if (b.type === 'hr') { body.appendHorizontalRule(); return; }
    if (b.type === 'img') {
      try {
        var parts = String(b.src).split(','), mime = (parts[0].match(/data:([^;]+)/) || [])[1] || 'image/png';
        var blob = Utilities.newBlob(Utilities.base64Decode(parts[1]), mime, 'img');
        var ip = rtl_(body.appendParagraph(''));
        ip.setAlignment(DocumentApp.HorizontalAlignment.CENTER);
        var img = ip.appendInlineImage(blob);
        var w = img.getWidth(), h = img.getHeight(), max = 460;
        if (w > max) { img.setWidth(max); img.setHeight(Math.round(h * max / w)); }
      } catch (e) {}
      return;
    }
    var text = (b.runs || []).map(function (r) { return r.t; }).join('');
    var p;
    if (b.type === 'li' || b.type === 'oli') {
      p = body.appendListItem(text || ' ');
      p.setGlyphType(b.type === 'oli' ? DocumentApp.GlyphType.NUMBER : DocumentApp.GlyphType.BULLET);
      p.setNestingLevel(Math.min(4, b.level || 0));
    } else {
      p = body.appendParagraph(text || '');
    }
    rtl_(p);
    p.setLineSpacing(1.5);
    p.setSpacingAfter(b.type === 'li' || b.type === 'oli' ? 2 : 8);
    var tx = p.editAsText();
    var size = 13;
    if (b.type === 'h1') { p.setHeading(DocumentApp.ParagraphHeading.HEADING1); size = 18; }
    else if (b.type === 'h2') { p.setHeading(DocumentApp.ParagraphHeading.HEADING2); size = 15.5; }
    else if (b.type === 'h3') { p.setHeading(DocumentApp.ParagraphHeading.HEADING3); size = 14; }
    if (!text) return;
    style_(tx, { size: size, color: STYLE.ink, bold: /^h/.test(b.type) });
    if (b.type === 'quote') {
      p.setIndentStart(18).setIndentFirstLine(18);
      style_(tx, { size: 13, color: STYLE.accent, italic: false });
    }
    var pos = 0;
    (b.runs || []).forEach(function (r) {
      var len = r.t.length;
      if (!len) return;
      var a = pos, z = pos + len - 1;
      if (r.b) tx.setBold(a, z, true);
      if (r.i) tx.setItalic(a, z, true);
      if (r.u) tx.setUnderline(a, z, true);
      if (r.mark) tx.setBackgroundColor(a, z, '#F3E3C4');
      if (r.ts) { tx.setForegroundColor(a, z, STYLE.copper); tx.setFontSize(a, z, 11); tx.setBold(a, z, true); }
      if (r.link) tx.setLinkUrl(a, z, r.link);
      pos += len;
    });
  });
}

function style_(tx, o) {
  if (o.font !== false) tx.setFontFamily(STYLE.font);
  if (o.size) tx.setFontSize(o.size);
  if (o.color) tx.setForegroundColor(o.color);
  if (o.bold != null) tx.setBold(!!o.bold);
  if (o.italic != null) tx.setItalic(!!o.italic);
}

// ---------------------------------------------------------------- أدوات درايف
function rootFolder_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('ROOT_ID');
  if (id) { try { var f = DriveApp.getFolderById(id); if (!f.isTrashed()) return f; } catch (e) {} }
  var it = DriveApp.getRootFolder().getFoldersByName(ROOT_NAME);
  var folder = it.hasNext() ? it.next() : DriveApp.getRootFolder().createFolder(ROOT_NAME);
  props.setProperty('ROOT_ID', folder.getId());
  return folder;
}
function sub_(parent, name) {
  var clean = String(name || 'بلا اسم').replace(/[\/\\]/g, '-').slice(0, 120);
  var it = parent.getFoldersByName(clean);
  return it.hasNext() ? it.next() : parent.createFolder(clean);
}
function path_(parts) {
  var f = rootFolder_();
  (parts || []).forEach(function (p) { f = sub_(f, p); });
  return f;
}
function notebookFolder_(id, title) {
  var props = PropertiesService.getScriptProperties();
  var key = 'NB_' + id;
  var fid = props.getProperty(key);
  if (fid) { try { var f = DriveApp.getFolderById(fid); if (!f.isTrashed()) { if (title && f.getName() !== title) f.setName(title); return f; } } catch (e) {} }
  var folder = sub_(sub_(rootFolder_(), 'الكناشة'), title || 'دفتر');
  props.setProperty(key, folder.getId());
  return folder;
}
function sysFolder_() { return sub_(rootFolder_(), 'النظام'); }
function readJson_(name, fallback) {
  var it = sysFolder_().getFilesByName(name);
  if (!it.hasNext()) return fallback;
  try { return JSON.parse(it.next().getBlob().getDataAsString('UTF-8')); } catch (e) { return fallback; }
}
function writeJson_(name, obj) {
  var folder = sysFolder_(), it = folder.getFilesByName(name), txt = JSON.stringify(obj);
  if (it.hasNext()) it.next().setContent(txt); else folder.createFile(name, txt, 'application/json');
}
function indexOf_(arr, id) { for (var i = 0; i < arr.length; i++) if (arr[i].id === id) return i; return -1; }
function hasTrigger_() { return ScriptApp.getProjectTriggers().some(function (t) { return t.getHandlerFunction() === 'tick'; }); }
