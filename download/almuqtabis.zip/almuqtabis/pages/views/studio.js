// المقتبس — الاستوديو: صفحة المقتبس الكاملة — معلوماته ونشره، وتحريره المتقدّم بمعاينة حيّة.
(() => {
  const { h, icon } = MQ;
  const E = MQEditor;
  const TOOLS = [
    ['info', 'info', 'المعلومات'],
    ['trim', 'scissors', 'القصّ'],
    ['text', 'text', 'النص'],
    ['frame', 'frame', 'الإطار'],
    ['template', 'layers', 'القالب'],
    ['color', 'palette', 'الألوان'],
    ['audio', 'volume', 'الصوت'],
    ['logo', 'badge', 'الشعار'],
    ['cover', 'image', 'الغلاف'],
    ['intro', 'film', 'المقدّمة'],
    ['versions', 'copy', 'النسخ'],
  ];
  const SWATCHES = ['#1D2117', '#0B0D09', '#22303A', '#3A2A16', '#4A5A32', '#F4F2EA'];
  const loadImg = (src) => new Promise((r) => { if (!src) return r(null); const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = src; });

  App.views.studio = {
    title: 'الاستوديو',
    async render(page, parts, query) {
      if (!parts[0]) return picker(page);
      const q = await MQDB.get('quotes', parts[0]);
      if (!q) { page.appendChild(App.empty('المقتبس غير موجود', '', h('a.btn', { href: '#/studio' }, 'رجوع'))); return; }
      return studio(page, q, query.get('tab'));
    },
  };

  async function picker(page) {
    const quotes = (await MQDB.all('quotes')).sort((a, b) => b.createdAt - a.createdAt);
    page.appendChild(App.header('الاستوديو', 'اختر مقتبسًا: عدّل معلوماته وانشره، أو حرّره — قصّ بالنص، ترجمة، أبعاد وقوالب، ألوان، صوت، شعار، غلاف، ومقدّمة وخاتمة.'));
    if (!quotes.length) { page.appendChild(App.empty('لا مقتبسات بعد', 'ابدأ باقتباس من محاضرة في يوتيوب.')); return; }
    const posts = await MQDB.all('posts');
    const g = h('div.qgrid');
    quotes.forEach((q, i) => g.appendChild(App.quoteCard(q, i, posts)));
    page.appendChild(g);
  }

  async function studio(page, q, startTab) {
    const settings = App.settings;
    let srcClip = await MQPub.getClip(q.sourceClipId);
    let edits = E.withDefaults(q.edits || settings.editDefaults || {});
    edits.zoom = edits.zoom || 1;
    let tool = TOOLS.some((t) => t[0] === startTab) ? startTab : 'info';
    let dur = 0, trim = null, cues = q.cues || null, transcriptKind = q.cuesKind || '';
    const { customLogo } = await chrome.storage.local.get('customLogo');
    const logos = { builtin: await loadImg('../assets/mark512.png'), white: await loadImg('../assets/mark-white512.png'), custom: await loadImg(customLogo) };
    window.__mqDefaultLogo = logos.white;
    const logoImg = () => edits.logo === 'builtin' ? logos.builtin : edits.logo === 'white' ? logos.white : edits.logo === 'custom' ? logos.custom : null;
    const info = () => ({ title: q.title || '', lecture: q.videoTitle || '', speaker: q.speaker || '', series: q.series || '' });

    // ---------- الهيكل ----------
    const rail = h('nav.rail');
    const tools = h('div.tools');
    const canvas = h('canvas');
    const ctx = canvas.getContext('2d', { alpha: false });
    const tag = h('div.stage-tag'), hint = h('div.stage-hint');
    const view = h('div.stage-view', canvas, tag, hint);
    const v = h('video', { playsInline: true, preload: 'auto' });
    const trimHost = h('div');
    const exportBtn = h('button.btn.btn-primary', { type: 'button' }, icon('download'), 'تصدير');
    const pubBtn = h('button.btn', { type: 'button', onclick: () => App.publishDialog(q) }, icon('send'), 'نشر');
    const previewBtn = h('button.btn', { type: 'button', title: 'معاينة كاملة بالمقدّمة والخاتمة', onclick: () => fullPreview() }, icon('play'), 'معاينة كاملة');
    const titleEl = h('div.tt', q.title || 'اقتباس');
    const top = h('div.stage-top',
      h('a.btn.btn-sm', { href: '#/studio', title: 'كل المقتبسات' }, icon('chevron')),
      titleEl, previewBtn, pubBtn, exportBtn);
    const bottom = h('div.stage-bottom', trimHost);
    const stage = h('section.stage', top, view, bottom);
    const root = h('div.studio', rail, tools, stage);
    page.appendChild(root);

    TOOLS.forEach(([id, ic, label]) => rail.appendChild(h('button' + (id === tool ? '.on' : ''), { type: 'button', dataset: { t: id }, title: label, onclick: () => setTool(id) }, icon(ic), label)));

    if (!srcClip) {
      tools.appendChild(h('div', h('h3', 'الملف غير موجود في المنصّة'),
        h('p.lead', 'ملف هذا المقتبس محفوظ في مجلّد التنزيلات فقط. اختره من جهازك ليُحفظ في المنصّة ويصير قابلًا للتحرير.'),
        h('label.btn.btn-primary', icon('upload'), 'اختر الملف', h('input', { type: 'file', accept: 'video/*', hidden: true, onchange: async (e) => {
          const f = e.target.files[0]; if (!f) return;
          const c = { id: MQ.uid(), quoteId: q.id, kind: 'source', blob: f, mime: f.type, ext: (f.name.split('.').pop() || 'mp4').toLowerCase(), w: 0, h: 0, duration: q.duration, createdAt: Date.now() };
          await MQPub.putClip(c); await MQPub.patchQuote(q.id, { sourceClipId: c.id }); App.refresh();
        } }))));
      tools.appendChild(infoPanel());
      stage.querySelector('.stage-view').appendChild(h('img', { src: App.thumbOf(q), alt: '', style: { maxWidth: '70%', borderRadius: '10px', opacity: .5 } }));
      canvas.remove(); exportBtn.disabled = true; previewBtn.disabled = true;
      return;
    }

    v.src = await App.clipUrl(srcClip.id);
    try { await E.prepareVideo(v); } catch (_) {}
    dur = isFinite(v.duration) && v.duration > 0 ? v.duration : (srcClip.duration || q.duration);
    trim = q.trim ? { start: Math.max(0, q.trim.start), end: Math.min(dur, q.trim.end || dur) } : { start: 0, end: dur };
    v.volume = Math.min(1, edits.audio.gain); v.muted = edits.audio.mute;
    await E.loadFonts();

    const trimUI = MQTrim.create(trimHost, { video: v, duration: dur, trim, onChange: (t) => { trim = t; if (tool === 'trim') paintWords(); } });
    E.peaks(srcClip.blob, 700).then((p) => p && trimUI.setPeaks(p.data));

    // النص من يوتيوب
    if (!cues && q.videoId) {
      const tr = await MQDB.get('transcripts', q.videoId);
      if (tr && tr.events && q.captureStart != null) { cues = MQText.forClip(tr.events, q.captureStart, q.captureStart + dur); transcriptKind = tr.kind; }
    }
    cues = cues || [];

    // ---------- المعاينة ----------
    let cw = 0, chh = 0, prog = null; // prog: معاينة كاملة جارية
    function layout() {
      const sw = v.videoWidth || srcClip.w || 1920, sh = v.videoHeight || srcClip.h || 1080;
      const { W, H } = E.outSize(edits, sw, sh, 1080);
      const r = view.getBoundingClientRect();
      const k = Math.min((r.width - 32) / W, (r.height - 32) / H);
      const dpr = Math.min(2, devicePixelRatio || 1);
      cw = Math.max(40, Math.floor(W * k)); chh = Math.max(40, Math.floor(H * k));
      canvas.style.width = cw + 'px'; canvas.style.height = chh + 'px';
      canvas.width = Math.round(cw * dpr); canvas.height = Math.round(chh * dpr);
      tag.textContent = `${W}×${H}`;
      canvas.classList.toggle('pan', canPan());
      E.resetCard();
      draw();
    }
    const canPan = () => edits.zoom > 1.001 || (edits.aspect !== 'orig' && edits.fit === 'cover') || tool === 'cover';
    function draw() {
      if (v.readyState < 2) { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, canvas.width, canvas.height); return; }
      if (prog) return; // المعاينة الكاملة ترسم بنفسها
      if (tool === 'cover') { E.drawCoverImage(ctx, v, edits, canvas.width, canvas.height, info(), logoImg(), edits.cover.layout); return; }
      if (tool === 'intro' && introPeek) {
        const spec = edits[introPeek];
        E.drawProgram(ctx, v, { ...edits, [introPeek]: { ...spec, on: true } }, canvas.width, canvas.height, info(), logoImg(), v.currentTime, cues,
          introPeek === 'intro' ? { name: 'intro', el: 0.6 } : { name: 'outro', el: 1.2 });
        return;
      }
      E.drawProgram(ctx, v, edits, canvas.width, canvas.height, info(), logoImg(), v.currentTime, cues, { name: 'main', rel: v.currentTime - trim.start, len: trim.end - trim.start });
    }
    let introPeek = null;
    let raf = 0;
    const loop = () => { draw(); highlightNow(); if (!v.paused) raf = requestAnimationFrame(loop); };
    v.addEventListener('play', () => { cancelAnimationFrame(raf); raf = requestAnimationFrame(loop); });
    v.addEventListener('pause', draw); v.addEventListener('seeked', () => { draw(); highlightNow(); }); v.addEventListener('loadeddata', draw);
    const ro = new ResizeObserver(layout); ro.observe(view);
    App.onCleanup(() => { ro.disconnect(); v.pause(); cancelAnimationFrame(raf); document.removeEventListener('keydown', onKey); stopPreview(); flushInfo(); });

    // معاينة كاملة: المقدّمة ثم المقطع ثم الخاتمة كما ستُصدَّر
    function stopPreview() { if (!prog) return; prog.stop = true; prog = null; previewBtn.replaceChildren(icon('play'), 'معاينة كاملة'); v.pause(); draw(); }
    async function fullPreview() {
      if (prog) return stopPreview();
      introPeek = null; E.resetCard();
      prog = { stop: false };
      const me = prog;
      previewBtn.replaceChildren(icon('pause'), 'إيقاف المعاينة');
      const W = canvas.width, H = canvas.height, len = trim.end - trim.start;
      const pre = E.introBefore(edits), post = E.outroAfter(edits);
      await E.seekTo(v, trim.start);
      const timed = (name, d) => new Promise((res) => {
        const t0 = performance.now();
        const tick = () => {
          if (me.stop) return res();
          const el = (performance.now() - t0) / 1000;
          E.drawProgram(ctx, v, edits, W, H, info(), logoImg(), v.currentTime, cues, { name, el: Math.min(el, d), rel: name === 'outro' ? len : 0, len });
          if (el >= d) return res();
          requestAnimationFrame(tick);
        };
        tick();
      });
      if (pre) await timed('intro', pre);
      if (me.stop) return;
      await v.play().catch(() => {});
      await new Promise((res) => {
        const tick = () => {
          if (me.stop) return res();
          E.drawProgram(ctx, v, edits, W, H, info(), logoImg(), v.currentTime, cues, { name: 'main', rel: v.currentTime - trim.start, len });
          if (v.currentTime >= trim.end - 0.03 || v.ended) { v.pause(); return res(); }
          requestAnimationFrame(tick);
        };
        tick();
      });
      if (post && !me.stop) await timed('outro', post);
      if (prog === me) stopPreview();
    }

    // تحريك الصورة بالسحب
    let pan = null;
    canvas.addEventListener('pointerdown', (e) => {
      if (!canPan()) { flash('كبّر الصورة أو اختر «ملء الإطار» لتحريكها'); return; }
      canvas.setPointerCapture(e.pointerId); canvas.classList.add('panning');
      pan = { x: e.clientX, y: e.clientY, px: edits.panX, py: edits.panY };
    });
    canvas.addEventListener('pointermove', (e) => {
      if (!pan) return;
      const k = 2.4 / Math.max(1, edits.zoom);
      edits.panX = MQ.clamp(pan.px - ((e.clientX - pan.x) / cw) * k * 2, -1, 1);
      edits.panY = MQ.clamp(pan.py - ((e.clientY - pan.y) / chh) * k * 2, -1, 1);
      draw();
    });
    const endPan = () => { pan = null; canvas.classList.remove('panning'); };
    canvas.addEventListener('pointerup', endPan); canvas.addEventListener('pointercancel', endPan);
    function flash(t) { hint.textContent = t; hint.classList.add('show'); clearTimeout(flash.t); flash.t = setTimeout(() => hint.classList.remove('show'), 2200); }

    function change(p, rerenderPanel) {
      edits = { ...edits, ...p };
      if (p.audio) { v.volume = Math.min(1, edits.audio.gain); v.muted = edits.audio.mute; }
      E.resetCard();
      layout();
      if (rerenderPanel) renderTool();
      saveEditsSoon();
    }
    const sub = (key, p, rerender) => change({ [key]: { ...edits[key], ...p } }, rerender);
    // حفظ التعديلات تلقائيًّا (دون تصدير)، فلا تضيع إن غادرت الصفحة
    const saveEditsSoon = MQ.debounce(() => { MQPub.patchQuote(q.id, { edits: stripEdits(), trim: { ...trim }, cues, cuesKind: transcriptKind }); }, 900);

    // ---------- أدوات الواجهة ----------
    const grp = (title, ...kids) => h('div.tgrp', title ? h('div.tgrp-t', title) : null, ...kids);
    const opts = (cls, items, cur, onPick) => h('div.optgrid' + (cls ? '.' + cls : ''), items.map(([val, label, extra]) => h('button.opt' + (val === cur ? '.on' : ''), { type: 'button', onclick: () => onPick(val) }, extra || null, label)));
    const slider = (label, val, min, max, step, fmt, onInput) => {
      const out = h('span.v', fmt(val));
      const r = h('input.range', { type: 'range', min, max, step, value: val, oninput: (e) => { const x = Number(e.target.value); out.textContent = fmt(x); onInput(x); } });
      return h('div.slider', h('label', label), r, out);
    };
    const toggle = (label, checked, onChange) => h('label.row-switch', h('span', label), h('span.switch', h('input', { type: 'checkbox', checked, onchange: (e) => onChange(e.target.checked) }), h('span')));
    const seg = (items, cur, onPick) => h('div.seg.block', items.map(([k, l]) => h('button' + (cur === k ? '.on' : ''), { type: 'button', onclick: () => onPick(k) }, l)));
    const themeSw = (cur, onPick) => h('div.themes', Object.entries(E.THEMES).map(([k, t]) => h('button' + (cur === k ? '.on' : ''), { type: 'button', title: t.label, onclick: () => onPick(k) },
      h('i', { style: { background: t.bg + '1)' } }, h('b', { style: { background: t.accent } })), h('span', t.label))));
    const subSel = (cur, onPick, withSeries = true) => h('select.select', { onchange: (e) => onPick(e.target.value) },
      [['speaker', 'اسم المحاضر'], ['lecture', 'اسم المحاضرة'], ['both', 'المحاضر والمحاضرة'], withSeries ? ['series', 'السلسلة'] : null, ['none', 'بلا']].filter(Boolean).map(([k, l]) => h('option', { value: k, selected: cur === k }, l)));
    const pct = (x) => Math.round(x * 100) + '%';

    function setTool(id) {
      tool = id; introPeek = null;
      rail.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.t === id));
      renderTool(); layout();
      history.replaceState(null, '', '#/studio/' + q.id + '?tab=' + id);
    }

    let wordsBox = null, cuesBox = null;
    function renderTool() {
      tools.replaceChildren();
      wordsBox = null; cuesBox = null;
      const T = (t, lead) => tools.append(h('h3', t), lead ? h('p.lead', lead) : null);
      if (tool === 'info') { tools.appendChild(infoPanel()); return; }
      if (tool === 'trim') {
        T('القصّ', 'اسحب المقبضين على الخط الزمني أسفل المعاينة، أو حدّد كلمات من النص ليصير المقطع ما بينها.');
        tools.appendChild(grp('مدّة المقطع', h('div.hint', `الأصل ${MQ.fmtTime(dur)} · المحدّد `, h('b.num', MQ.fmtTime(trim.end - trim.start)))));
        const g = grp('القصّ بالنص');
        if (!cues.length) {
          g.append(h('div.note-info', icon('info'), h('span', 'لا يوجد نصّ لهذا المقطع. يُجلب النص من ترجمات يوتيوب عند الاقتباس إن توفّرت، أو ارفع ملف ترجمة أو الصق النص من أداة «النص».')),
            h('button.btn.btn-sm', { style: { marginTop: '8px' }, onclick: () => setTool('text') }, 'إضافة النص'));
        } else {
          g.appendChild(accuracy());
          wordsBox = h('div.words');
          g.appendChild(wordsBox);
          g.appendChild(h('div.hint', { style: { marginTop: '6px' } }, 'اضغط كلمة البداية ثم اضغط كلمة النهاية مع مفتاح الإزاحة (Shift). والضغط على كلمة وحدها ينقلك إليها.'));
          g.appendChild(h('div', { style: { display: 'flex', gap: '6px', marginTop: '8px' } },
            h('button.btn.btn-sm.btn-soft', { onclick: applyWordSel }, icon('scissors'), 'اجعل التحديد هو المقطع'),
            h('button.btn.btn-sm.btn-ghost', { onclick: () => { selA = selB = null; paintWords(); } }, 'مسح التحديد')));
          paintWords();
        }
        tools.appendChild(g);
      }
      if (tool === 'text') {
        T('النص والترجمة', 'اعرض كلام المحاضر مكتوبًا على المقطع، فأكثر الناس يشاهدون بلا صوت.');
        tools.appendChild(toggle('إظهار الترجمة على المقطع', edits.subs.on, (x) => sub('subs', { on: x })));
        tools.appendChild(grp('النمط', opts('c2', Object.entries(E.SUB_STYLES).map(([k, s]) => [k, s.label]), edits.subs.style, (x) => sub('subs', { style: x, on: true }, true))));
        tools.appendChild(grp('الموضع', opts('c2', [['bottom', 'أسفل الفيديو'], ['below', 'تحت الفيديو (في الإطار)'], ['middle', 'الوسط'], ['top', 'الأعلى']], edits.subs.pos, (x) => sub('subs', { pos: x, on: true }, true)),
          h('div', { style: { marginTop: '8px' } }, seg([['modern', 'خطّ حديث'], ['naskh', 'خطّ النسخ']], edits.subs.font, (k) => sub('subs', { font: k }, true))),
          slider('الحجم', edits.subs.size, 0.6, 1.8, 0.05, pct, (x) => sub('subs', { size: x }))));
        const g = grp('السطور');
        if (cues.length) g.appendChild(accuracy());
        cuesBox = h('div.cues');
        g.appendChild(cuesBox);
        g.appendChild(h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap', marginTop: '8px' } },
          h('button.btn.btn-sm', { onclick: addCue }, icon('plus'), 'سطر عند الموضع الحالي'),
          h('label.btn.btn-sm.btn-soft', { title: 'ملف ترجمة بتوقيتاته (SRT أو VTT) — يُضبط على المقطع تلقائيًّا' }, icon('upload'), 'رفع ملف ترجمة SRT', h('input', { type: 'file', accept: '.srt,.vtt,text/vtt,application/x-subrip,text/plain', hidden: true, onchange: (e) => importSrt(e.target.files[0]) })),
          h('button.btn.btn-sm.btn-ghost', { onclick: importText }, icon('text'), cues.length ? 'استبدال بنصّ ملصوق' : 'لصق النص كاملًا'),
          cues.length ? h('button.btn.btn-sm.btn-ghost.btn-danger', { onclick: async () => { if (await App.confirm('حذف كل السطور؟', 'حذف', true)) { cues = []; renderTool(); draw(); saveEditsSoon(); } } }, 'حذف الكل') : null));
        tools.appendChild(g);
        paintCues();
      }
      if (tool === 'frame') {
        T('الإطار', 'أبعاد المقطع وطريقة عرضه، والكتابة على إطاره.');
        const shapes = { orig: [30, 17], reel: [13, 23], portrait: [18, 22], square: [21, 21], wide: [30, 17] };
        tools.appendChild(grp('الأبعاد', opts('', Object.entries(E.ASPECTS).filter(([k]) => k !== 'wide').map(([k, a]) => [k, a.label, h('i.shape', { style: { width: shapes[k][0] + 'px', height: shapes[k][1] + 'px' } })]), edits.aspect, (x) => change({ aspect: x, panX: 0, panY: 0, inset: x === 'orig' ? edits.inset : Math.max(edits.inset, 0.9) }, true))));
        const isOrig = edits.aspect === 'orig';
        if (isOrig) {
          tools.appendChild(grp('إطار بنفس الأبعاد الأصلية',
            toggle('صغّر الفيديو داخل إطار', edits.inset < 0.999, (x) => change({ inset: x ? 0.82 : 1 }, true)),
            edits.inset < 0.999 ? slider('حجم الفيديو', edits.inset, 0.6, 0.98, 0.01, pct, (x) => change({ inset: x })) : null,
            edits.inset < 0.999 ? slider('تدوير الزوايا', edits.radius || 0, 0, 1, 0.05, pct, (x) => change({ radius: x })) : null,
            h('div.hint', 'يبقى المقطع بأبعاده (16:9)، وتظهر حوله خلفية تتّسع للعنوان واسم المحاضرة.')));
        } else {
          tools.appendChild(grp('طريقة العرض', opts('c2', [['frame', 'الفيديو كاملًا في إطار'], ['cover', 'ملء الإطار بالقصّ']], edits.fit, (x) => change({ fit: x }, true))));
          if (edits.fit === 'frame') tools.appendChild(grp('حجم الفيديو', slider('الحجم', edits.inset, 0.7, 1, 0.01, pct, (x) => change({ inset: x })),
            slider('تدوير الزوايا', edits.radius || 0, 0, 1, 0.05, pct, (x) => change({ radius: x }))));
        }
        const framed = (isOrig && edits.inset < 0.999) || (!isOrig && edits.fit === 'frame');
        if (framed) {
          const sw = h('div.swatches', SWATCHES.map((c) => h('button' + (edits.bg === 'color' && edits.bgColor === c ? '.on' : ''), { type: 'button', style: { background: c }, onclick: () => change({ bg: 'color', bgColor: c }, true) })),
            h('input', { type: 'color', value: edits.bgColor, oninput: (e) => change({ bg: 'color', bgColor: e.target.value }) }));
          tools.appendChild(grp('الخلفية', opts('c2', [['blur', 'ضبابية من المقطع'], ['color', 'لون ثابت']], edits.bg, (x) => change({ bg: x }, true)), edits.bg === 'color' ? h('div', { style: { marginTop: '8px' } }, sw) : null));
          tools.appendChild(grp('الكتابة على الإطار',
            toggle('عنوان الاقتباس فوق الفيديو', edits.showTitle, (x) => change({ showTitle: x }, true)),
            edits.showTitle ? h('div', { style: { margin: '6px 0' } }, seg([['naskh', 'خطّ النسخ'], ['modern', 'خطّ حديث']], edits.titleFont, (k) => change({ titleFont: k }, true))) : null,
            edits.showTitle ? slider('الحجم', edits.titleScale, 0.7, 1.4, 0.02, pct, (x) => change({ titleScale: x })) : null,
            h('div.field', { style: { marginTop: '10px' } }, h('span.label', 'السطر تحت الفيديو'),
              h('select.select', { onchange: (e) => change({ lowerLine: e.target.value }) }, [['lecture', 'اسم المحاضرة'], ['speaker', 'اسم المحاضر'], ['both', 'المحاضر والمحاضرة'], ['series', 'السلسلة'], ['none', 'بلا']].map(([k, l]) => h('option', { value: k, selected: edits.lowerLine === k }, l))))));
        }
        tools.appendChild(grp('التكبير والتحريك', slider('التكبير', edits.zoom, 1, 2.5, 0.01, pct, (x) => change({ zoom: x })),
          h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px' } }, h('span.hint', 'اسحب على المعاينة لتحريك الصورة.'), h('button.btn.btn-sm.btn-ghost', { onclick: () => change({ panX: 0, panY: 0 }) }, 'توسيط'))));
      }
      if (tool === 'template') {
        const o = edits.overlay;
        T('القالب', 'طبقة شفافة فوق المقطع طوال عرضه — كالغلاف، لكنها تبقى مع الفيديو: عنوان واسم المحاضر بتصميم ثابت لهويّتك.');
        const og = h('div.optgrid.c2');
        Object.entries(E.OVERLAYS).forEach(([k, l]) => {
          const c = h('canvas', { width: 160, height: 90, style: { width: '100%', borderRadius: '8px', display: 'block' } });
          try { E.drawFrame(c.getContext('2d'), v, { ...E.withDefaults({}), color: edits.color, overlay: { ...o, kind: k } }, 160, 90, info(), null, null, null); } catch (_) {}
          og.appendChild(h('button.opt' + (o.kind === k ? '.on' : ''), { type: 'button', onclick: () => sub('overlay', { kind: k }, true) }, c, l.label));
        });
        tools.appendChild(grp('القوالب', og));
        if (o.kind !== 'none') {
          tools.appendChild(grp('الألوان', themeSw(o.theme, (k) => sub('overlay', { theme: k }, true)),
            slider('الكثافة', o.opacity, 0.3, 1, 0.01, pct, (x) => sub('overlay', { opacity: x }))));
          tools.appendChild(grp('المحتوى',
            toggle('عنوان الاقتباس', o.title, (x) => sub('overlay', { title: x }, true)),
            h('div.field', { style: { marginTop: '6px' } }, h('span.label', 'السطر الثاني'), subSel(o.sub, (x) => sub('overlay', { sub: x }))),
            h('div', { style: { margin: '6px 0' } }, seg([['naskh', 'خطّ النسخ'], ['modern', 'خطّ حديث']], o.font, (k) => sub('overlay', { font: k }, true))),
            slider('حجم الكتابة', o.size, 0.7, 1.5, 0.02, pct, (x) => sub('overlay', { size: x })),
            o.kind === 'tag' ? h('div', { style: { marginTop: '6px' } }, seg([['top', 'أعلى'], ['bottom', 'أسفل']], o.pos === 'bottom' ? 'bottom' : 'top', (k) => sub('overlay', { pos: k }, true))) : null));
          tools.appendChild(h('div.note-info', icon('info'), h('span', 'إن فعّلتَ عنوان الإطار من أداة «الإطار» أيضًا فقد يتكرّر العنوان؛ اختر أحدهما.')));
        }
      }
      if (tool === 'color') {
        T('الألوان', 'لمسة لونية خفيفة تمنح مقتبساتك هويّة واحدة.');
        const pg = h('div.optgrid');
        Object.entries(E.COLOR_PRESETS).forEach(([k, p]) => {
          const c = h('canvas', { width: 120, height: 68, style: { width: '100%', borderRadius: '8px', display: 'block' } });
          try { const x = c.getContext('2d'); x.filter = `brightness(${p.brightness}) contrast(${p.contrast}) saturate(${p.saturate})`; x.drawImage(v, 0, 0, 120, 68); x.filter = 'none';
            if (p.warmth) { x.globalCompositeOperation = 'soft-light'; x.fillStyle = `rgba(255,150,60,${p.warmth * 0.55})`; x.fillRect(0, 0, 120, 68); } } catch (_) {}
          pg.appendChild(h('button.opt' + (edits.color.preset === k ? '.on' : ''), { type: 'button', onclick: () => change({ color: { preset: k, ...p } }, true) }, c, p.label));
        });
        tools.appendChild(grp('أنماط جاهزة', pg));
        const c = edits.color;
        const setC = (p) => change({ color: { ...edits.color, preset: 'custom', ...p } });
        tools.appendChild(grp('ضبط يدوي',
          slider('السطوع', c.brightness, 0.6, 1.4, 0.01, pct, (x) => setC({ brightness: x })),
          slider('التباين', c.contrast, 0.6, 1.5, 0.01, pct, (x) => setC({ contrast: x })),
          slider('التشبّع', c.saturate, 0, 2, 0.01, pct, (x) => setC({ saturate: x })),
          slider('الدفء', c.warmth, -1, 1, 0.01, (x) => (x > 0 ? '+' : '') + Math.round(x * 100), (x) => setC({ warmth: x })),
          slider('التظليل', c.vignette, 0, 1, 0.01, pct, (x) => setC({ vignette: x })),
          h('button.btn.btn-sm.btn-ghost', { onclick: () => change({ color: { preset: 'natural', ...E.COLOR_PRESETS.natural } }, true) }, 'إرجاع الطبيعي')));
      }
      if (tool === 'audio') {
        const a = edits.audio;
        T('الصوت', 'وضوح الصوت نصف أثر المقتبس.');
        tools.appendChild(grp('',
          slider('مستوى الصوت', a.gain, 0, 2, 0.01, pct, (x) => sub('audio', { gain: x })),
          slider('ظهور تدريجي', a.fadeIn, 0, 3, 0.1, (x) => x.toFixed(1) + 'ث', (x) => sub('audio', { fadeIn: x })),
          slider('اختفاء تدريجي', a.fadeOut, 0, 3, 0.1, (x) => x.toFixed(1) + 'ث', (x) => sub('audio', { fadeOut: x })),
          toggle('تحسين الصوت (توحيد المستوى وتنقية الهمهمة)', a.enhance, (x) => sub('audio', { enhance: x })),
          toggle('كتم الصوت', a.mute, (x) => sub('audio', { mute: x }))));
        tools.appendChild(h('div.note-info', icon('info'), h('span', 'المعاينة لا تتجاوز 100٪ من الصوت؛ أما التضخيم والتحسين والتدرّج فتظهر في الملف المصدَّر.')));
      }
      if (tool === 'logo') {
        T('الشعار', 'علامة صغيرة تحفظ نسبة المقتبس إليك.');
        tools.appendChild(grp('الشعار', opts('c2', [['none', 'بلا شعار'], ['builtin', 'شعار المقتبس'], ['white', 'المقتبس بالأبيض'], ['custom', 'شعاري']], edits.logo, (x) => {
          if (x === 'custom' && !logos.custom) { pickLogo(); return; }
          change({ logo: x }, true);
        })));
        tools.appendChild(grp('', h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } },
          logos.custom ? h('img', { src: customLogo || '', style: { width: '42px', height: '42px', objectFit: 'contain', borderRadius: '8px', background: 'var(--surface-2)' } }) : null,
          h('button.btn.btn-sm', { onclick: pickLogo }, icon('upload'), logos.custom ? 'تغيير شعاري' : 'رفع شعاري'))));
        if (edits.logo !== 'none') {
          const posBtns = ['tl', 'tr', 'bl', 'br'].map((p) => h('button' + (edits.logoPos === p ? '.on' : ''), { type: 'button', onclick: () => change({ logoPos: p }, true) }));
          tools.appendChild(grp('الموضع', h('div.pos4', posBtns),
            slider('الحجم', edits.logoSize, 0.05, 0.3, 0.005, pct, (x) => change({ logoSize: x })),
            slider('الظهور', edits.logoOpacity, 0.2, 1, 0.01, pct, (x) => change({ logoOpacity: x }))));
        }
      }
      if (tool === 'cover') {
        const cv = edits.cover;
        T('الغلاف', 'صورة جذّابة بعنوان كبير، تُرسل غلافًا للمقطع أو تُنشر وحدها، وتصلح مقدّمةً للمقطع.');
        const lg = h('div.optgrid.c2');
        Object.entries(E.COVER_LAYOUTS).forEach(([k, l]) => {
          const c = h('canvas', { width: 160, height: 90, style: { width: '100%', borderRadius: '8px', display: 'block' } });
          try { E.drawCoverImage(c.getContext('2d'), v, { ...edits, cover: { ...cv, layout: k } }, 160, 90, info(), null, k); } catch (_) {}
          lg.appendChild(h('button.opt' + (cv.layout === k ? '.on' : ''), { type: 'button', onclick: () => sub('cover', { layout: k }, true) }, c, l.label));
        });
        tools.appendChild(grp('القوالب', lg));
        const txt = h('textarea.textarea', { rows: 2, placeholder: q.title || 'عنوان الغلاف', style: { minHeight: '60px' }, oninput: MQ.debounce((e) => sub('cover', { text: e.target.value }), 250) });
        txt.value = cv.text || '';
        tools.appendChild(grp('النص',
          h('div.field', h('span.label', 'العنوان على الغلاف'), txt, h('span.hint', 'اتركه فارغًا ليُستعمل عنوان الاقتباس.')),
          h('div.field', h('span.label', 'سطر علوي صغير (اختياري)'), h('input.input', { value: cv.kicker || '', placeholder: 'مثل: فائدة · من دروس…', oninput: MQ.debounce((e) => sub('cover', { kicker: e.target.value }), 250) })),
          h('div.field', h('span.label', 'السطر الثاني'), subSel(cv.sub, (x) => sub('cover', { sub: x }))),
          seg([['naskh', 'خطّ النسخ'], ['modern', 'خطّ حديث']], cv.font, (k) => sub('cover', { font: k }, true))));
        tools.appendChild(grp('الشكل', themeSw(cv.theme, (k) => sub('cover', { theme: k }, true)),
          slider('حجم العنوان', cv.size, 0.6, 1.5, 0.02, pct, (x) => sub('cover', { size: x })),
          slider('تعتيم الصورة', cv.dark, 0, 1, 0.01, pct, (x) => sub('cover', { dark: x })),
          h('div.hint', 'حرّك مؤشّر الخط الزمني إلى اللقطة التي تعجبك. تستطيع سحب الصورة لتحريكها، والتكبير من أداة «الإطار».')));
        tools.appendChild(grp('',
          h('button.btn.btn-primary', { onclick: saveCover }, icon('image'), 'حفظ الغلاف من هذه اللقطة'),
          q.coverClipId ? h('button.btn.btn-ghost', { style: { marginTop: '6px' }, onclick: downloadCover }, icon('download'), 'تنزيل الغلاف المحفوظ') : null,
          q.coverClipId ? h('div.note-info', { style: { marginTop: '10px' } }, icon('check'), h('span', 'للمقتبس غلاف محفوظ، ويُرسل مع المقطع في التليجرام.')) : null));
      }
      if (tool === 'intro') {
        T('المقدّمة والخاتمة', 'افتتح المقتبس بغلافه أو شعارك أو عنوانه، واختمه بشعارك — بانتقالات سلسة.');
        const part = (key, label) => {
          const s = edits[key];
          const g = grp(label, toggle(key === 'intro' ? 'تفعيل المقدّمة' : 'تفعيل الخاتمة', s.on, (x) => sub(key, { on: x }, true)));
          if (s.on) {
            g.append(
              h('div.field', { style: { marginTop: '8px' } }, h('span.label', 'المحتوى'), opts('', [['cover', 'الغلاف'], ['logo', 'الشعار'], ['title', 'نصّ']], s.kind, (x) => sub(key, { kind: x }, true))),
              s.kind !== 'cover' ? h('div.field', h('span.label', s.kind === 'logo' ? 'نصّ تحت الشعار (اختياري)' : 'النص'), h('input.input', { value: s.text || '', placeholder: s.kind === 'title' ? (key === 'intro' ? 'عنوان الاقتباس' : 'مثل: تابعونا…') : 'مثل: قناة…', oninput: MQ.debounce((e) => sub(key, { text: e.target.value }), 250) })) : null,
              h('div.field', h('span.label', 'التوقيت'), seg(key === 'intro' ? [['before', 'قبل المقطع'], ['overlay', 'مع بدايته فوقه']] : [['after', 'بعد المقطع'], ['overlay', 'مع نهايته فوقه']], s.mode, (x) => sub(key, { mode: x }, true))),
              slider('المدّة', s.dur, 1, 6, 0.1, (x) => x.toFixed(1) + 'ث', (x) => sub(key, { dur: x })),
              h('div.field', h('span.label', 'الانتقال'), opts('c4', Object.entries(E.TRANSITIONS), s.transition, (x) => sub(key, { transition: x }, true))),
              h('button.btn.btn-sm.btn-ghost', { onclick: () => { introPeek = introPeek === key ? null : key; E.resetCard(); draw(); renderTool(); } }, icon('eye'), introPeek === key ? 'إخفاء اللقطة' : 'أرني لقطة منها'));
          }
          return g;
        };
        tools.appendChild(part('intro', 'المقدّمة'));
        tools.appendChild(part('outro', 'الخاتمة'));
        if (edits.intro.on && edits.intro.kind === 'cover') tools.appendChild(h('div.hint', 'تُستعمل إعدادات قالب الغلاف من أداة «الغلاف».'));
        tools.appendChild(h('button.btn.btn-soft', { style: { marginTop: '10px' }, onclick: () => fullPreview() }, icon('play'), 'معاينة كاملة كما ستُصدَّر'));
      }
      if (tool === 'versions') renderVersions();
    }

    function accuracy() {
      return h('div.note-info', { style: { marginBottom: '8px' } }, icon('info'), h('span', transcriptKind === 'asr' || !transcriptKind
        ? 'النص مأخوذ من ترجمة يوتيوب الآلية، وقد لا يكون دقيقًا. صحّحه من أداة «النص» قبل نشره على المقطع.'
        : transcriptKind === 'file' ? 'النص من ملف الترجمة الذي رفعته.' : 'النص من ترجمة يوتيوب المكتوبة. راجعه قبل النشر.'));
    }

    // ---------- المعلومات والنشر (بدل النافذة المنبثقة) ----------
    let infoDirty = null;
    async function flushInfo() { if (infoDirty) { const p = infoDirty; infoDirty = null; await MQPub.patchQuote(q.id, p); await MQ.mergeCategories(p.categories || []); } }
    function infoPanel() {
      const wrap = h('div.infopanel');
      const saved = h('span.saved');
      const markSaved = () => { saved.textContent = 'حُفظ ✓'; saved.classList.add('show'); clearTimeout(markSaved.t); markSaved.t = setTimeout(() => saved.classList.remove('show'), 1600); };
      const save = MQ.debounce(async () => { await flushInfo(); markSaved(); }, 600);
      const set = (p) => { Object.assign(q, p); infoDirty = { ...(infoDirty || {}), ...p }; save(); if ('title' in p) { titleEl.textContent = p.title || 'اقتباس'; E.resetCard(); draw(); } if ('speaker' in p || 'series' in p) { E.resetCard(); draw(); } };
      const title = h('input.input.lg', { value: q.title || '', placeholder: 'عنوان الاقتباس', oninput: (e) => set({ title: e.target.value.trim() }) });
      const desc = h('textarea.textarea', { rows: 4, placeholder: 'وصف أو تعليق (اختياري)', oninput: (e) => set({ desc: e.target.value.trim() }) }); desc.value = q.desc || '';
      const speaker = h('input.input', { value: q.speaker || '', list: 'mqSpk', oninput: (e) => set({ speaker: e.target.value.trim() }) });
      const series = h('input.input', { value: q.series || '', placeholder: 'اختياري', list: 'mqSer', oninput: (e) => set({ series: e.target.value.trim() }) });
      const dl1 = h('datalist#mqSpk'), dl2 = h('datalist#mqSer');
      MQDB.all('quotes').then((all) => {
        dl1.replaceChildren(...[...new Set(all.map((x) => x.speaker).filter(Boolean))].map((x) => h('option', { value: x })));
        dl2.replaceChildren(...[...new Set(all.map((x) => x.series).filter(Boolean))].map((x) => h('option', { value: x })));
      });
      const chosen = new Set(q.categories || []);
      const catBox = h('div.chips');
      MQ.getCategories().then((cats) => {
        const paintCats = () => catBox.replaceChildren(...[...new Set([...cats, ...chosen])].map((c) => h('button.chip' + (chosen.has(c) ? '.on' : ''), { type: 'button', onclick: () => { chosen.has(c) ? chosen.delete(c) : chosen.add(c); set({ categories: [...chosen] }); paintCats(); } }, c)),
          h('button.chip', { type: 'button', onclick: async () => { const nv = await App.prompt('تصنيف جديد'); if (nv) { chosen.add(nv); cats.push(nv); set({ categories: [...chosen] }); paintCats(); } } }, '＋'));
        paintCats();
      });
      const shareBtn = h('button.btn', { type: 'button' }, icon('share'), 'مشاركة');
      shareBtn.onclick = () => App.shareMenu(shareBtn, q);
      const posts = h('div.qd-posts');
      MQDB.byIndex('posts', 'quoteId', q.id).then((ps) => posts.replaceChildren(...ps.sort((a, b) => (b.at || 0) - (a.at || 0)).map((p) => h('div.qd-post', h('span.dot', { style: { background: p.color } }), h('span', p.channelName),
        h('span.muted', p.at ? MQ.fmtDateTime(p.at) : ''), h('span.st', App.statusTag(p.status))))));
      const drive = h('div');
      const paintDrive = () => drive.replaceChildren(q.drive && q.drive.fileId
        ? h('div.note-info', icon('drive'), h('span', 'مرفوع إلى درايف'), h('a.btn.btn-sm', { href: q.drive.url, target: '_blank', style: { marginInlineStart: 'auto' } }, 'فتح'))
        : App.linked() ? h('button.btn.btn-sm.btn-soft', { type: 'button', onclick: async (e) => { e.target.disabled = true; App.toast('جارٍ الرفع إلى درايف…'); try { await MQPub.ensureDrive(q); Object.assign(q, await MQDB.get('quotes', q.id)); App.toast('رُفع إلى درايف ✓'); paintDrive(); } catch (er) { App.toast(er.message, 4000); e.target.disabled = false; } } }, icon('upload'), 'ارفعه إلى درايف')
          : App.lockNote('رفع المقطع إلى درايف ومشاركة رابطه.'));
      paintDrive();
      const fileInfo = h('div.hint');
      MQPub.publishClip(q).then((clip) => { fileInfo.textContent = `من ${MQ.fmtTime(q.start)} إلى ${MQ.fmtTime(q.end)} في «${q.videoTitle || ''}» · ${clip ? MQ.fmtSize(clip.blob.size) + (clip.w ? ` · ${clip.w}×${clip.h}` : '') : 'الملف غير محفوظ محليًّا'}`; });
      wrap.append(
        h('div.ip-head', h('h3', 'المعلومات'), saved),
        h('p.lead', 'تُحفظ تعديلاتك تلقائيًّا.'),
        h('div.field', h('label', 'العنوان'), title),
        h('div.field', h('label', 'الوصف'), desc),
        h('div.grid2', h('div.field', h('label', 'المحاضر'), speaker, dl1), h('div.field', h('label', 'السلسلة'), series, dl2)),
        h('div.field', h('span.label', 'التصنيفات'), catBox),
        h('div.tgrp', h('div.tgrp-t', 'النشر والمشاركة'),
          h('div.ip-acts',
            h('button.btn.btn-primary', { type: 'button', onclick: () => App.publishDialog(q, { onDone: () => renderTool() }) }, icon('send'), 'نشر'),
            shareBtn,
            h('button.btn', { type: 'button', onclick: async () => { const c = await MQPub.publishClip(q); if (!c) return; const r = await MQPub.saveFile(c.blob, MQPub.fileName(q, c.ext)); App.toast('حُفظ في ' + (r.filename || 'مجلّد المقتطفات')); } }, icon('download'), 'تنزيل'),
            h('a.btn.btn-ghost', { href: q.link, target: '_blank' }, icon('play'), 'في المحاضرة')),
          posts),
        h('div.tgrp', h('div.tgrp-t', 'درايف'), drive),
        h('div.tgrp', fileInfo,
          h('button.btn.btn-sm.btn-ghost.btn-danger', { type: 'button', style: { marginTop: '10px' }, onclick: async () => {
            if (!(await App.confirm('حذف هذا المقتبس من المكتبة؟ يُحذف ملفه المحلي، وتُلغى منشوراته المجدولة.', 'حذف', true))) return;
            infoDirty = null; await MQPub.deleteQuote(q); App.toast('حُذف'); App.go('#/quotes');
          } }, icon('trash'), 'حذف المقتبس')));
      if (!q.title) setTimeout(() => title.focus(), 50);
      return wrap;
    }

    // ---------- القصّ بالنص ----------
    let selA = null, selB = null;
    const allWords = () => cues.flatMap((c, ci) => MQText.ensureWords(c).map((w, wi) => ({ ...w, ci, wi })));
    function paintWords() {
      if (!wordsBox) return;
      const words = allWords();
      wordsBox.replaceChildren(...words.map((w, i) => {
        const s = h('span', w.w);
        const inTrim = w.t >= trim.start - 0.05 && w.t <= trim.end;
        if (!inTrim) s.classList.add('out');
        if (selA != null && i >= Math.min(selA, selB ?? selA) && i <= Math.max(selA, selB ?? selA)) s.classList.add('in');
        s.dataset.t = w.t;
        s.addEventListener('click', (e) => {
          if (e.shiftKey && selA != null) selB = i; else { selA = i; selB = null; v.currentTime = w.t; }
          paintWords();
        });
        return [s, ' '];
      }).flat());
      highlightNow();
    }
    function applyWordSel() {
      if (selA == null) { App.toast('حدّد كلمة البداية ثم كلمة النهاية مع Shift'); return; }
      const words = allWords();
      const a = words[Math.min(selA, selB ?? selA)], b = words[Math.max(selA, selB ?? selA)], next = words[Math.max(selA, selB ?? selA) + 1];
      const end = next ? next.t : Math.min(dur, b.t + 1.2);
      trimUI.setTrim({ start: Math.max(0, a.t - 0.15), end: Math.min(dur, end + 0.1) });
      App.toast('صار المقطع من «' + a.w + '» إلى «' + b.w + '»');
    }
    function highlightNow() {
      const t = v.currentTime;
      if (wordsBox) {
        let last = null;
        wordsBox.querySelectorAll('span[data-t]').forEach((s) => { s.classList.remove('now'); if (Number(s.dataset.t) <= t) last = s; });
        if (last) last.classList.add('now');
      }
      if (cuesBox) cuesBox.querySelectorAll('.cue').forEach((row, i) => row.classList.toggle('now', !!cues[i] && t >= cues[i].s && t < cues[i].e));
    }

    // ---------- تحرير السطور ----------
    function paintCues() {
      if (!cuesBox) return;
      if (!cues.length) { cuesBox.replaceChildren(h('div.hint', 'لا سطور بعد.')); return; }
      cuesBox.replaceChildren(...cues.map((c, i) => {
        const ta = h('textarea', { rows: 1, oninput: (e) => { c.text = e.target.value; c.words = []; autoGrow(e.target); draw(); saveEditsSoon(); } });
        ta.value = c.text;
        requestAnimationFrame(() => autoGrow(ta));
        return h('div.cue',
          h('div.tm', { title: 'انتقل إلى السطر', onclick: () => { v.currentTime = c.s + 0.01; } }, MQ.fmtTime(c.s)),
          ta,
          h('div', { style: { display: 'flex', flexDirection: 'column', gap: '2px' } },
            h('button.x', { title: 'حذف السطر', onclick: () => { cues.splice(i, 1); paintCues(); draw(); saveEditsSoon(); } }, icon('x', 14)),
            i < cues.length - 1 ? h('button.x', { title: 'دمج مع التالي', onclick: () => { const n = cues[i + 1]; c.text = c.text + ' ' + n.text; c.e = n.e; c.words = []; cues.splice(i + 1, 1); paintCues(); draw(); saveEditsSoon(); } }, icon('chevronDown', 14)) : null));
      }));
      highlightNow();
    }
    const autoGrow = (t) => { t.style.height = 'auto'; t.style.height = t.scrollHeight + 'px'; };
    function addCue() {
      const t = v.currentTime;
      const c = { s: t, e: Math.min(dur, t + 3), text: '', words: [] };
      cues.push(c); cues.sort((a, b) => a.s - b.s);
      for (let i = 0; i < cues.length - 1; i++) if (cues[i].e > cues[i + 1].s) cues[i].e = cues[i + 1].s;
      sub('subs', { on: true });
      renderTool();
      const idx = cues.indexOf(c);
      setTimeout(() => cuesBox && cuesBox.querySelectorAll('textarea')[idx]?.focus(), 30);
    }
    function importText() {
      const ta = h('textarea.textarea', { rows: 8, placeholder: 'الصق نصّ كلام المحاضر في هذا المقطع…' });
      App.dialog({ title: 'لصق النص', body: h('div', h('p.hint', 'يوزَّع النص على مدّة المقطع المحدّد بحسب عدد الكلمات، ثم تضبط توقيت السطور بالنقر عليها. وإن كان عندك ملف ترجمة بتوقيتاته (SRT) فارفعه بدل اللصق ليُضبط وحده.'), ta),
        actions: [{ label: 'توزيع النص', primary: true, onClick: () => {
          const list = MQText.fromText(ta.value, trim.end - trim.start).map((c) => ({ ...c, s: c.s + trim.start, e: c.e + trim.start, words: c.words.map((w) => ({ ...w, t: w.t + trim.start })) }));
          cues = list; transcriptKind = 'manual'; sub('subs', { on: true }); renderTool(); draw();
        } }, { label: 'إلغاء', ghost: true }] });
    }
    async function importSrt(file) {
      if (!file) return;
      const text = await file.text();
      const parsed = MQText.fromSrt(text);
      if (!parsed.length) { App.toast('لم أجد سطورًا بتوقيتات في الملف. تأكّد أنه بصيغة SRT أو VTT.', 4500); return; }
      const r = MQText.srtForClip(parsed, dur, q.captureStart != null ? q.captureStart : q.start);
      if (!r.cues.length) { App.toast('أزمنة الملف لا تقع في هذا المقطع.', 4500); return; }
      if (cues.length && !(await App.confirm(`وجدتُ ${r.cues.length} سطرًا. أستبدل بها السطور الحالية؟`, 'استبدال'))) return;
      cues = r.cues; transcriptKind = 'file';
      sub('subs', { on: true }); renderTool(); draw();
      App.toast(r.mode === 'lecture' ? `ضُبطت ${r.cues.length} سطرًا على موضع المقطع من المحاضرة ✓` : `أُضيفت ${r.cues.length} سطرًا بتوقيتاتها ✓`, 3500);
    }

    // ---------- الشعار ----------
    function pickLogo() {
      const inp = h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml,image/jpeg' });
      inp.onchange = async () => {
        const f = inp.files[0]; if (!f) return;
        if (f.size > 3 * 1024 * 1024) { App.toast('ملف الشعار كبير؛ الحدّ 3 ميغابايت'); return; }
        const url = await new Promise((r) => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
        const img = await loadImg(url); if (!img) { App.toast('تعذّر فتح الصورة'); return; }
        logos.custom = img; await chrome.storage.local.set({ customLogo: url });
        change({ logo: 'custom' }, true);
      };
      inp.click();
    }

    // ---------- الغلاف ----------
    async function saveCover() {
      const blob = await E.coverBlob(v, edits, info(), logoImg(), edits.cover.layout, null, 1080);
      const c = { id: MQ.uid(), quoteId: q.id, kind: 'cover', blob, mime: 'image/jpeg', ext: 'jpg', createdAt: Date.now() };
      await MQPub.putClip(c);
      if (q.coverClipId) { try { await MQDB.del('clips', q.coverClipId); } catch (_) {} }
      q.coverClipId = c.id;
      await MQPub.patchQuote(q.id, { coverClipId: c.id, coverDrive: '', edits: stripEdits() });
      App.toast('حُفظ الغلاف ✓');
      renderTool();
    }
    async function downloadCover() {
      const c = await MQPub.getClip(q.coverClipId); if (!c) return;
      await MQPub.saveFile(c.blob, `${MQ.safeFileName(q.title || 'اقتباس')} - غلاف.jpg`);
      App.toast('حُفظ الغلاف');
    }

    // ---------- النسخ ----------
    async function renderVersions() {
      tools.append(h('h3', 'النسخ'), h('p.lead', 'كل تصدير يحفظ نسخة جديدة. النسخة المعتمدة هي التي تُنشر وتُرفع.'));
      const clips = (await MQDB.byIndex('clips', 'quoteId', q.id)).filter((c) => c.kind !== 'cover').sort((a, b) => a.createdAt - b.createdAt);
      const active = q.finalClipId || q.sourceClipId;
      const list = h('div.versions');
      clips.forEach((c, i) => {
        const label = c.kind === 'source' ? 'الأصل كما التُقط' : `نسخة ${i}${c.quality ? ' · ' + (E.QUALITY[c.quality] || {}).label : ''}`;
        list.appendChild(h('div.ver' + (c.id === active ? '.on' : ''),
          h('span', h('b', label), h('br'), h('small.muted', `${c.w && c.h ? c.w + '×' + c.h + ' · ' : ''}${MQ.fmtTime(c.duration)} · ${MQ.fmtSize(c.blob.size)} · ${MQ.relTime(c.createdAt)}`)),
          c.id !== active ? h('button.btn.btn-sm', { onclick: async () => { const p = { finalClipId: c.kind === 'source' ? null : c.id }; Object.assign(q, p); await MQPub.patchQuote(q.id, p); App.toast('اعتُمدت النسخة'); renderTool(); } }, 'اعتمادها') : h('span.ptag.sent', 'المعتمدة'),
          h('button.btn.btn-icon.sm.btn-ghost', { title: 'تنزيل', onclick: async () => { const r = await MQPub.saveFile(c.blob, MQPub.fileName(q, c.ext)); App.toast('حُفظ في ' + r.filename); } }, icon('download')),
          c.kind !== 'source' && c.id !== active ? h('button.btn.btn-icon.sm.btn-ghost', { title: 'حذف', onclick: async () => { await MQDB.del('clips', c.id); renderTool(); } }, icon('trash')) : null));
      });
      tools.appendChild(list);
      if (q.drive && q.drive.fileId) tools.appendChild(h('div.note-info', { style: { marginTop: '12px' } }, icon('drive'), h('span', 'المرفوع إلى درايف هو النسخة التي كانت معتمدة وقت الرفع. بعد اعتماد نسخة جديدة سيُعاد الرفع عند الجدولة القادمة.')));
    }

    // ---------- التصدير ----------
    const stripEdits = () => { const { zoom, panX, panY, ...rest } = edits; return { ...rest, zoom, panX, panY }; };
    let abort = null;
    function exportDialog() {
      return new Promise((resolve) => {
        let qual = App.settings.exportPreset || 'high', fmt = 'auto', fps = 0, save = !!App.settings.localCopy;
        const sw = v.videoWidth || srcClip.w || 1920, sh = v.videoHeight || srcClip.h || 1080;
        const body = h('div');
        const paint = () => {
          const Q = E.QUALITY[qual];
          const { W, H } = E.outSize(edits, sw, sh, Q.short);
          const total = (trim.end - trim.start) + E.introBefore(edits) + E.outroAfter(edits);
          const est = (Q.bitrate * (fps === 60 ? 1.3 : 1) * total) / 8 + 192000 * total / 8;
          body.replaceChildren(
            h('div.field', h('span.label', 'الجودة'),
              h('div.qualgrid', Object.entries(E.QUALITY).map(([k, x]) => {
                const s = E.outSize(edits, sw, sh, x.short);
                return h('button.qopt' + (k === qual ? '.on' : ''), { type: 'button', onclick: () => { qual = k; paint(); } }, h('b', x.label), h('span.num', `${s.W}×${s.H}`), h('small', x.hint));
              }))),
            Math.min(sw, sh) < Q.short && qual === 'max' ? h('p.hint', `دقّة المصدر ${sw}×${sh}؛ لا تُرفع الدقّة فوق المصدر حتى لا تفقد الصورة حدّتها.`) : null,
            h('div.grid2',
              h('div.field', h('span.label', 'الصيغة'), seg([['auto', 'MP4 (الأنسب)'], ['webm', 'WebM']], fmt, (k) => { fmt = k; paint(); })),
              h('div.field', h('span.label', 'الإطارات في الثانية'), seg([[0, 'تلقائي'], [30, '30'], [60, '60']], fps, (k) => { fps = k; paint(); }))),
            h('label.check', h('input', { type: 'checkbox', checked: save, onchange: (e) => { save = e.target.checked; } }), h('span', 'احفظ نسخة في مجلّد المقتطفات على جهازك')),
            h('div.note-info', icon('info'), h('span', `المقاس ${W}×${H} · المدّة ${MQ.fmtTime(total)} · الحجم التقريبي ${MQ.fmtSize(est)}. يستغرق التصدير قدر مدّة المقطع، فلا تغلق هذه الصفحة.`)));
        };
        paint();
        let ok = false;
        App.dialog({ title: 'تصدير النسخة', body, onClose: () => resolve(ok ? { quality: qual, format: fmt === 'auto' ? '' : fmt, fps: fps || null, save } : null),
          actions: [{ label: 'ابدأ التصدير', primary: true, icon: 'download', onClick: () => { ok = true; } }, { label: 'إلغاء', ghost: true }] });
      });
    }
    exportBtn.addEventListener('click', async () => {
      if (abort) { abort.abort(); return; }
      stopPreview();
      const identity = E.isIdentity(edits, trim, dur);
      const patch = {
        edits: stripEdits(), trim: { ...trim }, cues, cuesKind: transcriptKind,
        start: (q.captureStart != null ? q.captureStart : q.start) + trim.start,
        end: (q.captureStart != null ? q.captureStart : q.start) + trim.end,
        duration: trim.end - trim.start,
      };
      patch.link = MQ.timeLink(q.videoId, patch.start);
      const { zoom, panX, panY, cover, ...defaults } = edits;
      await MQ.saveSettings({ editDefaults: defaults });
      if (identity) {
        Object.assign(q, patch, { finalClipId: null });
        await MQPub.patchQuote(q.id, { ...patch, finalClipId: null });
        App.toast('لا تعديلات على الأصل؛ اعتُمد الأصل كما هو');
        return;
      }
      const opt = await exportDialog();
      if (!opt) return;
      await MQ.saveSettings({ exportPreset: opt.quality, localCopy: opt.save });
      abort = new AbortController();
      exportBtn.replaceChildren(icon('x'), 'إيقاف التصدير');
      v.pause();
      const ov = h('div.expov',
        h('div', { style: { width: 'min(360px, 80%)', textAlign: 'center' } },
          h('div', { style: { fontFamily: 'var(--font-title)', fontSize: '20px', marginBottom: '10px' } }, 'جارٍ التصدير…'),
          h('div.progress', h('div', { id: 'expProg' })),
          h('div.muted', { style: { fontSize: '12.5px', marginTop: '8px' } }, 'يستغرق قدر مدّة المقطع. لا تغادر هذه الصفحة.')));
      view.appendChild(ov);
      try {
        const ac = new AudioContext();
        const out = await E.render({
          url: v.src, edits, trim, quality: opt.quality, format: opt.format, fps: opt.fps, info: info(), logoImg: logoImg(), cues, signal: abort.signal, audioCtx: ac,
          onProgress: (p) => { const el = document.getElementById('expProg'); if (el) el.style.width = Math.round(p * 100) + '%'; },
        });
        try { ac.close(); } catch (_) {}
        const c = { id: MQ.uid(), quoteId: q.id, kind: 'final', blob: out.blob, mime: out.blob.type, ext: out.ext, w: out.W, h: out.H, duration: out.duration, quality: opt.quality, createdAt: Date.now() };
        await MQPub.putClip(c);
        Object.assign(q, patch, { finalClipId: c.id });
        await MQPub.patchQuote(q.id, { ...patch, finalClipId: c.id });
        App.toast(`صُدّرت النسخة ✓ (${out.W}×${out.H} · ${MQ.fmtSize(out.blob.size)})`, 3500);
        if (opt.save) { try { await MQPub.saveFile(out.blob, MQPub.fileName(q, out.ext)); } catch (_) {} }
        if (tool === 'versions') renderTool();
      } catch (e) {
        if (e.name !== 'AbortError') App.toast('تعذّر التصدير: ' + e.message, 5000); else App.toast('أُوقف التصدير');
      } finally {
        abort = null; ov.remove(); E.resetCard(); draw();
        exportBtn.replaceChildren(icon('download'), 'تصدير');
      }
    });

    function onKey(e) {
      if (abort) return;
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (trimUI.key(e)) e.preventDefault();
    }
    document.addEventListener('keydown', onKey);
    renderTool();
    layout();
  }
})();
