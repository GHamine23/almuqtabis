// المقتبس — الكناشة: دفاتر التدوين، والتدوينات، والتصدير إلى مستندات جوجل.
(() => {
  const { h, icon } = MQ;

  App.noteCard = (n, nbs, i) => {
    const nb = (nbs || []).find((x) => x.id === n.notebookId);
    const text = MQRich.htmlToText(n.html);
    return h('article.ncard.rise', { style: { '--c': nb ? nb.color : 'var(--accent)', '--i': Math.min(i || 0, 20) }, onclick: () => App.go('#/kanasha/note/' + n.id) },
      h('h3', n.title || 'تدوين'),
      text ? h('p', text.slice(0, 220)) : h('p.muted', 'فارغ'),
      h('div.ft',
        nb ? h('span', nb.title) : null,
        n.videoTitle ? h('span', '· ' + n.videoTitle.slice(0, 40)) : null,
        h('span', '· ' + MQ.relTime(n.updatedAt)),
        n.syncedAt && n.syncedVersion >= n.updatedAt ? h('span', { title: 'متزامن مع درايف' }, icon('cloud', 14)) : null,
        (n.tags || []).slice(0, 3).map((t) => h('span.chip.tag', '#' + t))));
  };

  App.views.kanasha = {
    title: 'الكناشة',
    async render(page, parts, query) {
      if (parts[0] === 'nb' && parts[1]) return notebookPage(page, parts[1]);
      if (parts[0] === 'note' && parts[1]) return notePage(page, parts[1]);
      return shelf(page, query && query.get('video'));
    },
  };

  function syncNote() {
    if (!App.linked()) return h('div', { style: { marginBottom: '16px' } }, App.lockNote('بعد الربط يصير لكل دفتر مجلّد بنفس اسمه في درايف، ولكل تدوين مستند جوجل مرتّب في مجلّده.'));
    if (!App.settings.autoSyncNotes) return h('div.note-info', { style: { marginBottom: '16px' } }, icon('info'), h('span', 'الحفظ التلقائي في درايف متوقّف. فعّله من الإعدادات ← حساب جوجل.'));
    return null;
  }

  // ---------- الرفّ ----------
  async function shelf(page, video) {
    const nbs = await MQNotes.ensureDefault();
    const notes = (await MQDB.all('notes')).filter((n) => !n.trashed);
    const tags = [...new Set(notes.flatMap((n) => n.tags || []))];
    page.appendChild(App.header('الكناشة', 'دفاترك وما دوّنته من ملخّصات وفوائد أثناء المشاهدة.', [
      h('button.btn.btn-primary', { onclick: newNotebook }, icon('plus'), 'دفتر جديد')]));
    const sn = syncNote(); if (sn) page.appendChild(sn);
    const shelfEl = h('div.shelf');
    nbs.forEach((nb, i) => {
      const n = notes.filter((x) => x.notebookId === nb.id).length;
      shelfEl.appendChild(h('div.book.rise', { style: { '--c': nb.color, '--i': i }, onclick: () => App.go('#/kanasha/nb/' + nb.id) },
        h('img.bmark', { src: '../assets/mark-white.svg', alt: '' }),
        nb.folderId ? h('span.cloudic', { title: 'له مجلّد في درايف' }, icon('cloud', 16)) : null,
        h('h3', nb.title), h('div.n', n ? `${n} تدوين` : 'فارغ')));
    });
    shelfEl.appendChild(h('div.book.new', { onclick: newNotebook }, icon('plus', 26), 'دفتر جديد'));
    page.appendChild(shelfEl);

    const search = h('input.input', { placeholder: 'ابحث في كل التدوينات…' });
    if (video) page.appendChild(h('div.filterbar', icon('play', 17), h('span', 'تدويناتك في: ', h('b', (notes.find((n) => n.videoId === video) || {}).videoTitle || 'المحاضرة')), h('a.btn.btn-sm.btn-ghost', { href: '#/kanasha', style: { marginInlineStart: 'auto' } }, 'إظهار الكل')));
    let tag = null;
    const tagBox = h('div.chips');
    const list = h('div.ngrid');
    page.append(h('div.sec-t', h('h2', 'كل التدوينات'), h('span.hint', `${notes.length}`)), h('div.toolbar', h('div.searchbox', icon('search'), search)), tagBox, h('div', { style: { height: '12px' } }), list);
    const paint = () => {
      tagBox.replaceChildren(...(tags.length ? [h('button.chip' + (!tag ? '.on' : ''), { onclick: () => { tag = null; paint(); } }, 'الكل'), ...tags.map((t) => h('button.chip' + (tag === t ? '.on' : ''), { onclick: () => { tag = t; paint(); } }, '#' + t))] : []));
      const s = search.value.trim();
      const shown = notes.filter((n) => (!video || n.videoId === video) && (!tag || (n.tags || []).includes(tag)) && (!s || [n.title, n.videoTitle, n.speaker, MQRich.htmlToText(n.html)].join(' ').includes(s))).sort((a, b) => b.updatedAt - a.updatedAt);
      list.replaceChildren(...(shown.length ? shown.map((n, i) => App.noteCard(n, nbs, i)) : [h('p.hint', notes.length ? 'لا نتائج.' : 'لا تدوينات بعد. افتح محاضرة في يوتيوب واضغط «الدفتر» في الشريط تحت المقطع.')]));
    };
    search.addEventListener('input', MQ.debounce(paint, 150));
    paint();
  }

  async function newNotebook() {
    const color = { v: MQNotes.NB_COLORS[0] };
    const name = h('input.input', { placeholder: 'مثلًا: السيرة النبوية، دفتر المنهج' });
    const desc = h('input.input', { placeholder: 'اختياري' });
    const sw = h('div.swatches');
    const paintSw = () => sw.replaceChildren(...MQNotes.NB_COLORS.map((c) => h('button' + (color.v === c ? '.on' : ''), { type: 'button', style: { background: c }, onclick: () => { color.v = c; paintSw(); } })));
    paintSw();
    App.dialog({ title: 'دفتر جديد', body: h('div', h('div.field', h('label', 'اسم الدفتر'), name), h('div.field', h('label', 'وصف قصير'), desc), h('div.field', h('label', 'لون الغلاف'), sw),
      App.linked() ? h('div.note-info', icon('drive'), h('span', 'سيُنشأ له مجلّد بنفس الاسم في درايف ← المقتبس ← الكناشة.')) : null),
      actions: [{ label: 'إنشاء', primary: true, onClick: async () => { if (!name.value.trim()) throw new Error('اكتب اسم الدفتر.'); const nb = await MQNotes.createNotebook(name.value.trim(), color.v, desc.value.trim()); App.go('#/kanasha/nb/' + nb.id); } }, { label: 'إلغاء', ghost: true }] });
    setTimeout(() => name.focus(), 40);
  }

  // ---------- دفتر ----------
  async function notebookPage(page, id) {
    const nb = await MQDB.get('notebooks', id);
    if (!nb || nb.trashed) { page.appendChild(App.empty('الدفتر غير موجود', '', h('a.btn', { href: '#/kanasha' }, 'الكناشة'))); return; }
    const nbs = await MQNotes.notebooks();
    const notes = (await MQDB.byIndex('notes', 'notebookId', id)).filter((n) => !n.trashed).sort((a, b) => b.updatedAt - a.updatedAt);
    const more = h('button.btn.btn-icon', { title: 'المزيد' }, icon('more'));
    more.onclick = () => App.menu(more, [
      { icon: 'edit', label: 'إعادة التسمية', onClick: async () => { const t = await App.prompt('اسم الدفتر', nb.title); if (t) { await MQNotes.updateNotebook(id, { title: t }); App.refresh(); } } },
      { icon: 'palette', label: 'تغيير اللون', onClick: () => colorDialog(nb) },
      nb.folderUrl ? { icon: 'drive', label: 'فتح مجلّده في درايف', href: nb.folderUrl } : null,
      'hr',
      { icon: 'trash', label: 'حذف الدفتر', danger: true, onClick: async () => {
        const others = nbs.filter((x) => x.id !== id);
        if (others.length && notes.length) {
          if (!(await App.confirm(`حذف «${nb.title}»؟\nستُنقل تدويناته (${notes.length}) إلى «${others[0].title}».`, 'حذف ونقل', true))) return;
          await MQNotes.deleteNotebook(id, others[0].id);
        } else {
          if (!(await App.confirm(`حذف «${nb.title}»${notes.length ? ' وتدويناته' : ''}؟`, 'حذف', true))) return;
          await MQNotes.deleteNotebook(id, null);
        }
        App.go('#/kanasha');
      } },
    ]);
    page.appendChild(App.header(nb.title, nb.desc || `${notes.length} تدوين`, [
      h('button.btn.btn-primary', { onclick: async () => { const n = await MQNotes.saveNote({ id: MQ.uid(), notebookId: id, title: 'تدوين جديد', html: '', tags: [] }); App.go('#/kanasha/note/' + n.id); } }, icon('plus'), 'تدوين جديد'),
      more], [{ label: 'الكناشة', href: '#/kanasha' }, { label: nb.title }]));
    const sn = syncNote(); if (sn) page.appendChild(sn);
    page.appendChild(notes.length ? h('div.ngrid', notes.map((n, i) => App.noteCard(n, nbs, i))) : App.empty('الدفتر فارغ', 'اختر هذا الدفتر من «الدفتر» في يوتيوب، أو أنشئ تدوينًا هنا.'));
  }
  function colorDialog(nb) {
    let c = nb.color;
    const sw = h('div.swatches');
    const paint = () => sw.replaceChildren(...MQNotes.NB_COLORS.map((x) => h('button' + (c === x ? '.on' : ''), { type: 'button', style: { background: x }, onclick: () => { c = x; paint(); } })));
    paint();
    App.dialog({ title: 'لون الدفتر', body: sw, actions: [{ label: 'حفظ', primary: true, onClick: async () => { await MQNotes.updateNotebook(nb.id, { color: c }); App.refresh(); } }] });
  }

  // ---------- تدوين ----------
  async function notePage(page, id) {
    let note = await MQDB.get('notes', id);
    if (!note || note.trashed) { page.appendChild(App.empty('التدوين غير موجود', '', h('a.btn', { href: '#/kanasha' }, 'الكناشة'))); return; }
    const nbs = await MQNotes.notebooks();
    const nb = nbs.find((x) => x.id === note.notebookId);
    const status = h('div.status');
    const setStatus = (t, k) => { status.textContent = t; status.className = 'status' + (k ? ' ' + k : ''); };
    const save = async (p = {}) => {
      note = await MQNotes.saveNote({ ...note, ...p });
      setStatus('حُفظ ' + MQ.fmtClock(Date.now()) + (App.linked() && App.settings.autoSyncNotes ? ' · يُزامَن مع درايف' : ''), 'ok');
    };
    const title = h('input.note-title', { value: note.title || '', placeholder: 'عنوان التدوين', oninput: MQ.debounce(() => save({ title: title.value.trim() }), 500) });
    const meta = h('div.note-meta',
      note.videoId ? h('a', { href: MQ.watchLink(note.videoId), target: '_blank' }, icon('play'), note.videoTitle || 'المحاضرة') : null,
      note.speaker ? h('span', icon('user'), ' ', note.speaker) : null,
      note.series ? h('span', icon('series'), ' ', note.series) : null,
      h('span', icon('clock'), ' كُتب ', MQ.fmtDate(note.createdAt)));
    const edHost = h('div');
    const paper = h('div.note-paper', title, meta, edHost);
    MQRich.create(edHost, {
      html: note.html, autoStamp: false,
      onTimeClick: (t) => { if (note.videoId) window.open(MQ.watchLink(note.videoId, t), '_blank'); },
      onChange: (html) => save({ html }),
    });

    // الجانب
    const nbSel = h('select.select', { onchange: (e) => save({ notebookId: e.target.value }) }, nbs.map((x) => h('option', { value: x.id, selected: x.id === note.notebookId }, x.title)));
    const tagBox = h('div.chips');
    const paintTags = () => {
      tagBox.replaceChildren(...(note.tags || []).map((t) => h('span.chip.tag', '#' + t, h('span', { style: { cursor: 'pointer', marginInlineStart: '4px' }, onclick: () => { save({ tags: note.tags.filter((x) => x !== t) }).then(paintTags); } }, '×'))),
        h('input.input', { placeholder: '＋ وسم ثم Enter', style: { width: '130px', padding: '3px 10px', borderRadius: '999px', fontSize: '12.5px' }, onkeydown: async (e) => {
          if (e.key !== 'Enter') return;
          const v = e.target.value.replace(/^#/, '').trim(); if (!v) return;
          await save({ tags: [...new Set([...(note.tags || []), v])] }); MQ.mergeNoteTags([v]); paintTags();
          tagBox.querySelector('input').focus();
        } }));
    };
    paintTags();
    const docsBtn = h('button.btn.btn-soft', { disabled: !App.linked(), onclick: async () => {
      docsBtn.disabled = true; setStatus('جارٍ التصدير إلى مستندات جوجل…');
      try { const r = await MQNotes.exportDocs(note); setStatus('صُدّر إلى مستندات جوجل ✓', 'ok'); window.open(r.url, '_blank'); note = await MQDB.get('notes', id); paintDoc(); }
      catch (e) { setStatus(e.message, 'err'); }
      docsBtn.disabled = !App.linked();
    } }, icon('doc'), 'مستندات جوجل');
    const docLink = h('div');
    const paintDoc = () => docLink.replaceChildren(note.docUrl ? h('a.btn.btn-sm.btn-ghost', { href: note.docUrl, target: '_blank' }, icon('link'), 'فتح المستند') : '');
    paintDoc();
    const side = h('aside.note-side',
      h('div.card', h('span.label', 'الدفتر'), nbSel),
      h('div.card', h('span.label', 'الوسوم'), tagBox),
      h('div.card', h('span.label', 'التصدير'),
        h('div', { style: { display: 'flex', flexDirection: 'column', gap: '8px' } }, docsBtn,
          !App.linked() ? h('span.hint', 'التصدير إلى مستندات جوجل يتطلّب ربط حساب جوجل.') : null,
          h('button.btn', { onclick: async () => { await MQNotes.exportWord(note); App.toast('نُزّل ملف وورد في مجلّد المقتطفات'); } }, icon('download'), 'ملف وورد'),
          docLink)),
      h('div.card', status, h('button.btn.btn-sm.btn-ghost.btn-danger', { style: { marginTop: '8px' }, onclick: async () => { if (await App.confirm('حذف هذا التدوين؟', 'حذف', true)) { await MQNotes.trashNote(id); App.go('#/kanasha/nb/' + note.notebookId); } } }, icon('trash'), 'حذف التدوين')));
    setStatus(note.syncedAt && note.syncedVersion >= note.updatedAt ? 'متزامن مع درايف ✓' : 'يُحفظ تلقائيًا');
    page.append(
      h('div.crumb', h('a', { href: '#/kanasha' }, 'الكناشة'), icon('chevron'), nb ? h('a', { href: '#/kanasha/nb/' + nb.id }, nb.title) : null),
      h('div.note-page', paper, side));
  }
})();
