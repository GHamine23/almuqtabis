// المقتبس — الرئيسية: الساعة والتاريخ، عبارة تتبدّل، بطاقة «تابع من حيث توقّفت»، والمراجعة والكناشة والنشر.
(() => {
  const { h, icon } = MQ;
  // نصوص موثّقة: آيات (ورقمها)، وأحاديث صحيحة بتخريجها المختصر
  const SAYINGS = [
    { text: '﴿وقل رب زدني علما﴾', src: 'طه: 114' },
    { text: '﴿يرفع الله الذين آمنوا منكم والذين أوتوا العلم درجات﴾', src: 'المجادلة: 11' },
    { text: '﴿قل هل يستوي الذين يعلمون والذين لا يعلمون﴾', src: 'الزمر: 9' },
    { text: '﴿إنما يخشى الله من عباده العلماء﴾', src: 'فاطر: 28' },
    { text: '«من سلك طريقًا يلتمس فيه علمًا سهّل الله له به طريقًا إلى الجنة»', src: 'رواه مسلم' },
    { text: '«من يُرد الله به خيرًا يفقّهه في الدين»', src: 'متفق عليه' },
    { text: '«نضّر الله امرأً سمع منّا حديثًا فحفظه حتى يبلّغه»', src: 'رواه أبو داود والترمذي' },
    { text: '﴿لعلّي آتيكم منها بقبس﴾', src: 'طه: 10' },
  ];

  App.views.home = {
    title: 'الرئيسية',
    async render(page) {
      const [quotes, watch, posts, notes, nbs, series] = await Promise.all([MQDB.all('quotes'), MQDB.all('watch'), MQDB.all('posts'), MQDB.all('notes'), MQDB.all('notebooks'), MQDB.all('series')]);
      const liveNotes = notes.filter((n) => !n.trashed);

      // ---------- الواجهة العلوية: تحية، ساعة، تاريخ، وعبارة ----------
      const clock = h('div.clock');
      const dateEl = h('div.hdate');
      const greet = h('h1');
      const tick = () => {
        const d = new Date();
        const hr = d.getHours();
        greet.textContent = hr < 5 ? 'ليلة مباركة' : hr < 12 ? 'صباح الخير' : hr < 17 ? 'طاب يومك' : 'مساء الخير';
        clock.replaceChildren(h('b', d.toLocaleTimeString('ar', { hour: 'numeric', minute: '2-digit' }).replace(/\s?(ص|م)$/, '')), h('span', d.getHours() < 12 ? 'صباحًا' : 'مساءً'));
        dateEl.replaceChildren(h('span', d.toLocaleDateString('ar', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })), h('span.hij', MQ.hijriDate(d)));
      };
      tick();
      const timer = setInterval(tick, 15000);
      const mine = (App.settings.motivation || []).filter((m) => m && m.text);
      const pool = App.settings.motivationOnlyMine && mine.length ? mine : [...SAYINGS, ...mine];
      let si = Math.floor(Math.random() * pool.length);
      const say = h('blockquote.saying');
      const paintSay = () => {
        const s = pool[si % pool.length];
        say.classList.remove('in'); void say.offsetWidth;
        say.replaceChildren(h('p', s.text), s.src ? h('cite', s.src) : null);
        say.classList.add('in');
      };
      paintSay();
      const sayTimer = setInterval(() => { si++; paintSay(); }, 14000);
      say.addEventListener('click', () => { si++; paintSay(); });
      say.title = 'اضغط لعبارة أخرى';
      App.onCleanup(() => { clearInterval(timer); clearInterval(sayTimer); });
      page.appendChild(h('div.hero2.rise',
        h('div.hero-l', h('img.mark', { src: '../assets/mark.svg', alt: '' }), h('div', greet, dateEl)),
        say,
        clock));

      // بطاقات التعريف بالربط (تُخفى بضغطة، أو تختفي وحدها بعد الربط)
      const hints = await hintCards();
      if (hints) page.appendChild(hints);

      // تنبيه إذن مجلّد الحفظ
      const need = await MQDB.get('kv', 'saveDirNeedsGrant').catch(() => null);
      if (need && App.settings.saveTarget === 'folder') {
        page.appendChild(h('div.lock-note.rise', { style: { marginTop: '14px' } }, icon('folder'), h('span', h('b', 'حُفظت ملفات في «التنزيلات» بدل مجلّدك، '), 'لأن المتصفح يحتاج إذنك من جديد.'),
          h('a.btn.btn-sm', { href: '#/settings/record' }, 'منح الإذن')));
      }

      // ---------- تابع من حيث توقّفت ----------
      const allSeries = App.allSeries ? App.allSeries(watch, series) : [];
      const last = [...watch].sort((a, b) => b.lastAt - a.lastAt)[0];
      page.appendChild(continueCard(last, allSeries, watch, liveNotes));

      // ---------- الأرقام ----------
      const weekAgo = MQ.dayStart() - 6 * 86400e3;
      const weekSec = watch.reduce((a, w) => a + Object.entries(w.days || {}).filter(([d]) => new Date(d + 'T00:00').getTime() >= weekAgo).reduce((s, [, v]) => s + v, 0), 0);
      const done = watch.filter((w) => w.completed).length;
      const upcoming = posts.filter((p) => p.status === 'scheduled').sort((a, b) => a.at - b.at);
      page.appendChild(h('div.stats',
        stat(MQ.fmtDur(weekSec), 'دراسة هذا الأسبوع', 0, true, '#/stats'), stat(done, 'محاضرة أتممتها', 1, false, '#/history/done'),
        stat(quotes.length, 'مقتبسًا', 2, false, '#/quotes'), stat(liveNotes.length, 'تدوينًا في الكناشة', 3, false, '#/kanasha')));

      // ---------- للمراجعة ----------
      if (quotes.length) {
        const picks = App.pickForReview(quotes, 4);
        page.appendChild(secTitle('مقترحة لك للمراجعة', '#/quotes/review', 'ابدأ المراجعة', icon('shuffle')));
        page.appendChild(h('div.qgrid.review4', picks.map((q, i) => App.quoteCard(q, i, posts))));
      }

      // ---------- من الكناشة ----------
      const snippets = pickSnippets(liveNotes, 3);
      if (snippets.length) {
        page.appendChild(secTitle('من كنّاشتك', '#/kanasha', 'كل الدفاتر'));
        page.appendChild(h('div.snips', snippets.map((s, i) => {
          const nb = nbs.find((b) => b.id === s.note.notebookId);
          return h('a.snip.rise', { href: '#/kanasha/note/' + s.note.id, style: { '--i': i, '--c': (nb && nb.color) || 'var(--accent)' } },
            h('p', s.text), h('div.snip-f', icon('book', 14), h('span', [s.note.title || 'تدوين', nb && nb.title].filter(Boolean).join(' · ')), s.t != null ? h('span.ts', MQ.fmtTime(s.t)) : null));
        })));
      }

      // ---------- السلاسل والنشر ----------
      const cols = h('div.cols2');
      const left = h('div'), right = h('div');
      cols.append(left, right);
      const active = allSeries.filter((s) => s.started && s.done < s.members.length).slice(0, 3);
      left.appendChild(secTitle('سلاسلك الجارية', '#/history/series'));
      left.appendChild(active.length ? h('div.row-list', active.map((s, i) => h('a.serline.rise', { href: '#/history/series?s=' + encodeURIComponent(s.id), style: { '--i': i } },
        h('div.bigring.sm', { style: { '--p': s.pct } }, h('b', s.pct + '٪')),
        h('div', { style: { flex: 1, minWidth: 0 } }, h('div.tt', s.title), h('div.hint', `${s.done} من ${s.members.length} · ${s.next ? 'التالية: ' + (s.next.title || '') : ''}`)))))
        : soft('استورد سلسلة من سجلّ الإنجاز، أو شاهد من قائمة تشغيل، فيظهر تقدّمك هنا.'));
      right.appendChild(secTitle('القادم في النشر', '#/publish'));
      right.appendChild(upcoming.length ? h('div.row-list', upcoming.slice(0, 4).map((p, i) => postRow(p, quotes, i))) : soft(App.linked() ? 'لا منشورات مجدولة.' : 'الجدولة تعمل بعد ربط حساب جوجل.'));
      page.appendChild(cols);

      page.appendChild(secTitle('أحدث المقتبسات', '#/quotes'));
      const recent = [...quotes].sort((a, b) => b.createdAt - a.createdAt).slice(0, 4);
      page.appendChild(recent.length ? h('div.qgrid', recent.map((q, i) => App.quoteCard(q, i, posts))) :
        App.empty('لا مقتبسات بعد', 'افتح محاضرة في يوتيوب، واضغط زرّ المقتبس في المشغّل أو في الشريط تحت المقطع.'));

      // الإبلاغ عن مشكلة
      page.appendChild(h('div.report.rise',
        h('div.report-i', icon('feedback', 22)),
        h('div', { style: { flex: 1, minWidth: 0 } }, h('b', 'واجهتك مشكلة، أو عندك اقتراح؟'), h('p', 'المقتبس في نسخته التجريبية، وكل ملاحظة تصل إلى صاحبه مباشرة وتحسّنه.')),
        h('button.btn.btn-primary', { type: 'button', onclick: () => App.reportDialog() }, icon('send'), 'أبلغ عن مشكلة'),
        h('button.btn.btn-ghost', { type: 'button', onclick: () => App.reportDialog('اقتراح') }, 'اقترح ميزة')));

      if (!App.settings.tourDone) setTimeout(() => App.tour && App.tour(), 700);
    },
  };

  async function hintCards() {
    const hidden = new Set(App.settings.hintsHidden || []);
    const chans = await MQ.getChannels();
    const needG = !App.linked() && !hidden.has('google');
    const needT = !(App.settings.tgToken && chans.length) && !hidden.has('telegram');
    if (!needG && !needT) return null;
    const hide = async (id, card) => {
      card.classList.add('out');
      App.settings = await MQ.saveSettings({ hintsHidden: [...new Set([...(App.settings.hintsHidden || []), id])] });
      setTimeout(() => { card.remove(); if (!wrap.children.length) wrap.remove(); }, 280);
    };
    const card = (id, cls, logo, title, why, perks, cta, href) => {
      const c = h('section.hintc.rise.' + cls,
        h('button.hint-x', { type: 'button', title: 'إخفاء — تجده دائمًا في الإعدادات', onclick: () => hide(id, c) }, icon('x', 16)),
        h('div.hint-h', h('div.hint-logos', h('img', { src: '../assets/mark.svg', alt: '' }), h('span.plus', '+'), logo), h('div', h('span.hint-k', 'خطوة مقترحة'), h('h3', title))),
        h('p.hint-why', why),
        h('ul.hint-l', perks.map((t) => h('li', icon('check', 15), t))),
        h('div.hint-a', h('a.btn.btn-primary', { href }, cta), h('button.btn.btn-ghost', { type: 'button', onclick: () => hide(id, c) }, 'لاحقًا')));
      return c;
    };
    const gLogo = h('span.svc-logo.g', icon('drive', 26));
    const tLogo = h('span.svc-logo.t', icon('telegram', 26));
    const wrap = h('div.hints');
    if (needG) wrap.appendChild(card('google', 'g', gLogo, 'اربط المقتبس بحساب جوجل',
      'يعمل المقتبس على جهازك دون ربط، لكن بعض الخدمات تحتاج سحابة تعمل وجهازك مطفأ — والربط يتمّ عبر سكربت في حسابك أنت، فلا تمرّ بياناتك بأي خادم آخر.',
      ['جدولة المنشورات فتُنشر في وقتها ولو كان جهازك مطفأً', 'رفع المقتبسات إلى درايف ومشاركة روابطها', 'حفظ الكنّاشة: مجلّد لكل دفتر، ومستند جوجل مرتّب لكل تدوين', 'نسخة من بياناتك في سحابتك تحفظها من الضياع'],
      'اربط حساب جوجل', '#/settings/google'));
    if (needT) wrap.appendChild(card('telegram', 't', tLogo, 'اربط قناتك في تليجرام',
      'انشر ما ينفع: مقتبس واحد بضغطة يصل إلى قناتك بعنوانه ووصفه ورابطه، بقالب تختاره لكل قناة.',
      ['نشر فوري للمقتبس في قناة أو أكثر', 'قوالب نصّ لكل قناة، بمعاينة كما يظهر في تليجرام', 'تقويم تسحب إليه المقتبسات، وخطة نشر تلقائية', 'يكفي بوت واحد لكل قنواتك، الخاصة والعامة'],
      'اضبط التليجرام', App.settings.tgToken ? '#/publish/channels' : '#/settings/telegram'));
    return wrap;
  }

  // نافذة الإبلاغ عن مشكلة أو اقتراح — تصل إلى صاحب المقتبس في تليجرام
  App.reportDialog = (kind0) => {
    let kind = kind0 || 'خطأ';
    const kinds = h('div.chips');
    const paintK = () => kinds.replaceChildren(...[['خطأ', '🐞 مشكلة'], ['اقتراح', '💡 اقتراح'], ['ملاحظة', '📝 ملاحظة'], ['شكر', '🤍 شكر']].map(([k, l]) => h('button.chip' + (k === kind ? '.on' : ''), { type: 'button', onclick: () => { kind = k; paintK(); } }, l)));
    paintK();
    const msg = h('textarea.textarea', { rows: 6, placeholder: 'صف ما حدث: ماذا فعلت، وماذا توقّعت، وماذا ظهر لك…' });
    const contact = h('input.input', { placeholder: 'وسيلة تواصل للرد (اختياري)' });
    const withInfo = h('input', { type: 'checkbox', checked: true });
    App.dialog({
      title: 'أبلغ عن مشكلة أو أرسل ملاحظة',
      body: h('div', h('div.field', kinds), h('div.field', msg), h('div.field', contact),
        h('label.check', withInfo, h('span', 'أرفق معلومات تقنية تساعد على حلّ المشكلة', h('div.hint', 'رقم الإصدار، والمتصفح، والصفحة التي أنت فيها، وآخر الأخطاء — بلا شيء من مقتبساتك أو تدويناتك.')))),
      actions: [{ label: 'أرسل', primary: true, icon: 'send', onClick: async (dlg, btn) => {
        const text = msg.value.trim();
        if (text.length < 3) throw new Error('اكتب ملاحظتك أولًا.');
        btn.textContent = 'جارٍ الإرسال…';
        const info = withInfo.checked ? `\n\n— الإصدار ${chrome.runtime.getManifest().version} · ${navigator.userAgent.match(/Chrome\/[\d.]+/)?.[0] || ''} · ${location.hash || '#/home'}${App.errors.length ? '\n— أخطاء: ' + App.errors.slice(-3).join(' | ') : ''}` : '';
        await MQ.sendFeedback({ kind, msg: text + info, contact: contact.value.trim(), version: chrome.runtime.getManifest().version, page: 'extension' });
        App.toast('وصلت رسالتك — جزاك الله خيرًا 🤍', 3500);
      } }, { label: 'إلغاء', ghost: true }],
    });
    setTimeout(() => msg.focus(), 40);
  };

  function continueCard(w, allSeries, watch, notes) {
    if (!w) {
      return h('div.cont.empty-cont.rise', { style: { '--i': 1 } },
        h('div.cont-b', h('span.cont-k', 'تابع من حيث توقّفت'), h('h2', 'لا محاضرة في سجلّ دراستك بعد'),
          h('p.hint', 'افتح محاضرة في يوتيوب واضغط «أضف إلى سجلّ الدراسة» تحت المقطع، أو استورد سلسلة كاملة.'),
          h('div.cont-a', h('a.btn.btn-primary', { href: 'https://www.youtube.com', target: '_blank' }, 'افتح يوتيوب'), h('button.btn', { type: 'button', onclick: () => { App.go('#/history'); setTimeout(() => App.importSeriesDialog && App.importSeriesDialog(), 300); } }, icon('playlist'), 'استورد سلسلة'))));
    }
    const ser = allSeries.find((s) => s.members.some((m) => m.videoId === w.videoId));
    let target = w, isNext = false;
    if (w.completed && ser && ser.next) { target = { videoId: ser.next.videoId, title: ser.next.title, duration: ser.next.duration, position: ser.next.w ? ser.next.w.position : 0, ...(ser.next.w || {}) }; isNext = true; }
    const pct = App.pctOf(target.completed ? null : target) || (target.duration ? Math.round(((target.position || 0) / target.duration) * 100) : 0);
    const nN = notes.filter((n) => n.videoId === target.videoId).length;
    const listQ = ser && !ser.id.startsWith('n:') ? '&list=' + encodeURIComponent(ser.id) : '';
    const url = MQ.watchLink(target.videoId, target.position > 30 ? target.position : 0) + listQ;
    const idx = ser ? ser.members.findIndex((m) => m.videoId === target.videoId) : -1;
    return h('a.cont.rise', { href: url, target: '_blank', style: { '--i': 1 } },
      h('div.cont-th', h('img', { src: MQ.thumbUrl(target.videoId, 'hqdefault'), alt: '' }), h('span.cont-play', icon('play', 30)),
        target.duration ? h('span.cont-dur', MQ.fmtTime(target.duration)) : null,
        h('div.cont-bar', h('div', { style: { width: pct + '%' } }))),
      h('div.cont-b',
        h('span.cont-k', isNext ? 'أتممتَ السابقة — التالية في السلسلة' : 'تابع من حيث توقّفت'),
        h('h2', target.title || 'محاضرة'),
        h('div.cont-m', [target.speaker || target.channel || (ser && ser.channel), ser ? ser.title + (idx >= 0 ? ` · ${idx + 1} من ${ser.members.length}` : '') : '', w.lastAt ? 'آخر مشاهدة ' + MQ.dayLabel(w.lastAt) : ''].filter(Boolean).map((x) => h('span', x))),
        App.progressBar(pct),
        h('div.cont-st', target.position > 30 ? `توقّفتَ عند ${MQ.fmtTime(target.position)}${target.duration ? ' — بقي ' + MQ.fmtDur(Math.max(0, target.duration - target.position)) : ''}` : 'لم تبدأها بعد', nN ? h('span', { style: { color: 'var(--copper)' } }, ` · ${nN} تدوين`) : null),
        h('div.cont-a', h('span.btn.btn-primary.btn-lg', icon('play'), target.position > 30 ? 'تابع المشاهدة' : 'ابدأ المشاهدة'),
          ser ? h('span.btn', { onclick: (e) => { e.preventDefault(); App.go('#/history/series?s=' + encodeURIComponent(ser.id)); } }, icon('series'), 'السلسلة') : null)));
  }

  // مقاطع قصيرة من التدوينات للقراءة (فقرات حقيقية، مع وقتها إن كان)
  function pickSnippets(notes, n) {
    const out = [];
    const shuffled = [...notes].sort(() => Math.random() - 0.5);
    for (const note of shuffled) {
      const d = document.createElement('div');
      d.innerHTML = note.html || '';
      const paras = [...d.querySelectorAll('p, li, blockquote')].map((p) => {
        const ts = p.querySelector('.ts');
        const t = ts ? Number(ts.dataset.t) : null;
        if (ts) ts.remove();
        return { text: p.textContent.replace(/\s+/g, ' ').trim(), t };
      }).filter((x) => x.text.length > 40);
      if (!paras.length) continue;
      const p = paras[Math.floor(Math.random() * paras.length)];
      out.push({ note, text: p.text.length > 260 ? p.text.slice(0, 250).replace(/\s\S*$/, '') + '…' : p.text, t: p.t });
      if (out.length >= n) break;
    }
    return out;
  }

  function stat(n, label, i, accent, href) { return h('a.stat.rise' + (accent ? '.accent' : ''), { href: href || null, style: { '--i': i } }, h('b', String(n)), h('span', label)); }
  function secTitle(t, href, label, ic) { return h('div.sec-t', h('h2', t), href ? h('a', { href }, ic || null, ' ', label || 'عرض الكل') : null); }
  function soft(t) { return h('div.note-info', icon('info'), h('span', t)); }

  function postRow(p, quotes, i) {
    const q = quotes.find((x) => x.id === p.quoteId) || {};
    return h('div.lrow.rise', { style: { '--i': i } },
      h('div.th', h('img', { src: App.thumbOf(q), alt: '' })),
      h('div.bd', h('div.tt', q.title || 'اقتباس'), h('div.sb', h('span', h('span.dot', { style: { background: p.color } }), ' ', p.channelName), h('span', MQ.fmtDateTime(p.at)))),
      h('div.ac', App.statusTag(p.status)));
  }
})();
