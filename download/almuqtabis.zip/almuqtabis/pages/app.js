// المقتبس — هيكل المنصّة: التنقّل، الإعدادات المشتركة، والأدوات العامة للواجهات.
(() => {
  const { h, icon } = MQ;
  const NAV = [
    ['home', 'home', 'الرئيسية'],
    ['quotes', 'quote', 'المقتبسات'],
    ['studio', 'studio', 'الاستوديو'],
    ['publish', 'calendar', 'النشر'],
    'sep',
    ['kanasha', 'book', 'الكناشة'],
    ['history', 'history', 'سجلّ الإنجاز'],
    ['stats', 'chart', 'الإحصاءات'],
    'sep',
    ['settings', 'settings', 'الإعدادات'],
  ];

  const App = {
    views: {}, settings: null, cleanup: [],
    async start() {
      App.settings = await MQ.getSettings();
      await MQ.migrateV1().catch(() => {});
      applyTheme();
      renderNav();
      renderFoot();
      window.addEventListener('hashchange', () => route());
      chrome.storage.onChanged.addListener((ch, area) => {
        if (area === 'local' && ch.settings) MQ.getSettings().then((s) => { App.settings = s; applyTheme(); renderFoot(); });
      });
      MQDB.onChange((e) => { if (e.store === 'posts' || e.store === 'quotes') paintBadges(); });
      paintBadges();
      route();
    },
    go(hash) { if (location.hash === hash) route(); else location.hash = hash; },
    refresh() { App._noTransition = true; route().finally(() => { App._noTransition = false; }); },
    params() {
      const raw = location.hash.replace(/^#\/?/, '');
      const [path, qs] = raw.split('?');
      return { parts: path.split('/').filter(Boolean).map(decodeURIComponent), query: new URLSearchParams(qs || '') };
    },
    linked() { return MQ.cloudReady(App.settings); },
    onCleanup(fn) { App.cleanup.push(fn); },
  };
  window.App = App;
  // آخر الأخطاء (تُرفق بالإبلاغ عن المشكلات إن أذن المستخدم)
  App.errors = [];
  window.addEventListener('error', (e) => { if (e.message) App.errors.push(String(e.message).slice(0, 160)); App.errors = App.errors.slice(-5); });
  window.addEventListener('unhandledrejection', (e) => { App.errors.push(String((e.reason && e.reason.message) || e.reason).slice(0, 160)); App.errors = App.errors.slice(-5); });
  // صورة بديلة هادئة إن تعذّر تحميل صورة مصغّرة
  window.addEventListener('error', (e) => {
    const t = e.target;
    if (t && t.tagName === 'IMG' && !t.dataset.fb && !t.closest('.avatar')) { t.dataset.fb = '1'; t.src = '../assets/thumb-ph.svg'; }
  }, true);

  function applyTheme() {
    const t = App.settings && App.settings.theme;
    if (t === 'light' || t === 'dark') document.documentElement.dataset.theme = t; else delete document.documentElement.dataset.theme;
  }

  function renderNav() {
    const nav = document.getElementById('nav');
    nav.replaceChildren();
    for (const it of NAV) {
      if (it === 'sep') { nav.appendChild(h('div.sep')); continue; }
      const [id, ic, label] = it;
      nav.appendChild(h('a', { href: '#/' + id, dataset: { id } }, icon(ic), h('span', label), h('span.badge', { hidden: true })));
    }
  }
  async function paintBadges() {
    const posts = await MQDB.all('posts');
    const up = posts.filter((p) => p.status === 'scheduled').length;
    const fail = posts.filter((p) => p.status === 'failed').length;
    const b = document.querySelector('.nav a[data-id="publish"] .badge');
    if (b) { b.hidden = !(up || fail); b.textContent = fail ? '!' : String(up); b.title = fail ? 'منشورات تعذّر إرسالها' : 'منشورات مجدولة'; }
  }
  function renderFoot() {
    const f = document.getElementById('sideFoot');
    const on = App.linked();
    const theme = App.settings.theme || 'auto';
    const next = { auto: 'light', light: 'dark', dark: 'auto' }[theme];
    const tLabel = { auto: 'المظهر: تلقائي', light: 'المظهر: فاتح', dark: 'المظهر: داكن' }[theme];
    f.replaceChildren(
      h('a.gpill' + (on ? '.on' : ''), { href: '#/settings/google', title: on ? 'مربوط بحساب جوجل' : 'غير مربوط بحساب جوجل' },
        h('span.dot'), h('span', on ? (App.settings.cloud.email || 'مربوط بجوجل') : 'اربط حساب جوجل')),
      h('button.btn.btn-sm.btn-ghost', { onclick: async () => { App.settings = await MQ.saveSettings({ theme: next }); applyTheme(); renderFoot(); } }, icon('eye'), tLabel),
    );
  }

  async function route() {
    const { parts } = App.params();
    const name = parts[0] || 'home';
    const view = App.views[name] || App.views.home;
    document.querySelectorAll('.nav a').forEach((a) => a.classList.toggle('on', a.dataset.id === name));
    App.cleanup.splice(0).forEach((fn) => { try { fn(); } catch (_) {} });
    const main = document.getElementById('main');
    const render = async () => {
      const page = h('div.page' + (view.wide ? '.wide' : ''));
      main.replaceChildren(page);
      window.scrollTo(0, 0);
      try { await view.render(page, parts.slice(1), App.params().query); }
      catch (e) { console.error(e); page.replaceChildren(h('div.empty', h('h3', 'حدث خطأ'), h('p', String(e && e.message || e)))); }
    };
    // الانتقال المرئي لا ينتظر الواجهات البطيئة (كالاستوديو) أكثر من لحظة، حتى لا تبدو الصفحة متجمّدة
    if (document.startViewTransition && !App._noTransition) {
      let done;
      const p = new Promise((r) => { done = r; });
      document.startViewTransition(() => Promise.race([render().finally(done), new Promise((r) => setTimeout(r, 220))]));
      await p;
    } else await render();
    document.title = (view.title ? view.title + ' — ' : '') + 'المقتبس';
  }

  // ---------------- أدوات عامة ----------------
  App.toast = (msg, ms = 2600) => {
    const t = document.getElementById('toast');
    if (!t.hasAttribute('popover')) t.setAttribute('popover', 'manual');
    try { t.hidePopover(); t.showPopover(); } catch (_) {}
    t.textContent = msg; t.classList.add('show');
    clearTimeout(App.toast._t); App.toast._t = setTimeout(() => t.classList.remove('show'), ms);
  };
  App.header = (title, sub, actions, crumbs) => h('div.ph',
    h('div.ph-t',
      crumbs ? h('div.crumb', crumbs.map((c, i) => [i ? icon('chevron') : null, c.href ? h('a', { href: c.href }, c.label) : h('span', c.label)])) : null,
      h('h1', title), sub ? h('p', sub) : null),
    actions ? h('div.ph-a', actions) : null);
  App.menu = (anchor, items) => {
    document.querySelectorAll('.menu').forEach((m) => m.remove());
    const m = h('div.menu');
    items.forEach((it) => {
      if (!it) return;
      if (it === 'hr') { m.appendChild(h('hr')); return; }
      if (it.title) { m.appendChild(h('div.menu-t', it.title)); return; }
      const el = it.href
        ? h('a', { href: it.href, target: it.target || '_blank', rel: 'noopener', onclick: () => m.remove() }, it.icon ? icon(it.icon) : null, it.label)
        : h('button', { type: 'button', disabled: it.disabled, title: it.hint || '', onclick: () => { m.remove(); it.onClick && it.onClick(); } }, it.icon ? icon(it.icon) : null, it.label);
      if (it.danger) el.style.color = 'var(--danger)';
      m.appendChild(el);
    });
    // القائمة في الطبقة العليا (popover) حتى تظهر فوق النوافذ الحوارية لا خلفها
    m.setAttribute('popover', 'manual');
    document.body.appendChild(m);
    try { m.showPopover(); } catch (_) {}
    const r = anchor.getBoundingClientRect();
    const mw = m.offsetWidth, mh = m.offsetHeight;
    let left = r.right - mw; if (left < 8) left = Math.min(innerWidth - mw - 8, r.left);
    let top = r.bottom + 6; if (top + mh > innerHeight - 8) top = Math.max(8, r.top - mh - 6);
    m.style.left = left + 'px'; m.style.top = top + 'px';
    setTimeout(() => document.addEventListener('pointerdown', function off(e) { if (!m.contains(e.target)) { m.remove(); document.removeEventListener('pointerdown', off); } }), 0);
    return m;
  };
  App.dialog = ({ title, body, actions = [], wide, onClose }) => {
    const dlg = h('dialog.dlg' + (wide ? '.wide' : ''));
    const foot = h('div.dlg-foot');
    const close = () => { dlg.close(); };
    actions.forEach((a) => {
      const b = h('button.btn' + (a.primary ? '.btn-primary' : '') + (a.danger ? '.btn-danger' : '') + (a.ghost ? '.btn-ghost' : ''), { type: 'button' }, a.icon ? icon(a.icon) : null, a.label);
      b.addEventListener('click', async () => {
        if (!a.onClick) return close();
        b.disabled = true;
        try { const r = await a.onClick(dlg, b); if (r !== false) close(); }
        catch (e) { App.toast(e.message || String(e), 4500); }
        finally { b.disabled = false; }
      });
      foot.appendChild(b);
    });
    dlg.append(h('div.dlg-head', h('h2', title), h('button.btn.btn-icon.sm.btn-ghost', { type: 'button', onclick: close, 'aria-label': 'إغلاق' }, icon('x'))), h('div.dlg-body', body), actions.length ? foot : null);
    dlg.addEventListener('close', () => { dlg.remove(); onClose && onClose(); });
    document.body.appendChild(dlg);
    dlg.showModal();
    return dlg;
  };
  App.confirm = (text, okLabel = 'تأكيد', danger) => new Promise((resolve) => {
    let ok = false;
    App.dialog({ title: 'تأكيد', body: h('p', { style: { margin: '4px 0 0', whiteSpace: 'pre-line' } }, text), onClose: () => resolve(ok),
      actions: [{ label: okLabel, primary: !danger, danger, onClick: () => { ok = true; } }, { label: 'إلغاء', ghost: true }] });
  });
  App.prompt = (title, value = '', placeholder = '') => new Promise((resolve) => {
    let out = null;
    const inp = h('input.input', { value, placeholder });
    const dlg = App.dialog({ title, body: inp, onClose: () => resolve(out), actions: [{ label: 'حفظ', primary: true, onClick: () => { out = inp.value.trim() || null; } }, { label: 'إلغاء', ghost: true }] });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') { out = inp.value.trim() || null; dlg.close(); } });
    setTimeout(() => { inp.focus(); inp.select(); }, 30);
  });
  App.lockNote = (text) => h('div.lock-note', icon('lock'), h('span', h('b', 'يتطلّب ربط حساب جوجل. '), text || ''),
    h('a.btn.btn-sm', { href: '#/settings/google' }, 'اربط الآن'));
  App.copy = async (text, msg = 'نُسخ') => { try { await navigator.clipboard.writeText(text); App.toast(msg); } catch (_) { App.toast('تعذّر النسخ'); } };
  App.empty = (title, text, action) => h('div.empty', h('img.mark', { src: '../assets/mark.svg', alt: '' }), h('h3', title), text ? h('p', text) : null, action || null);

  // ---------------- الجولة التعريفية ----------------
  const TOUR = [
    { t: 'أهلًا بك في المقتبس', d: 'رفيقك في طلب العلم من المحاضرات: تقتبس اللحظات المهمّة، وتدوّن، وتتابع إنجازك، وتنشر ما ينفع. هذه جولة قصيرة — دقيقة واحدة.' },
    { sel: '.nav a[data-id="home"]', t: 'الرئيسية', d: 'آخر ما كنت تشاهده لتتابعه بضغطة، ومقتبسات مقترحة لمراجعتها، وفقرات من كنّاشتك لتقرأها.' },
    { sel: '.nav a[data-id="quotes"]', t: 'المقتبسات', d: 'مكتبتك: الكل، أو بطاقات التصنيفات، أو المتحدّثون، أو المواد والسلاسل — مع وضع مراجعة يعرضها متتابعة.' },
    { sel: '.nav a[data-id="studio"]', t: 'الاستوديو', d: 'صفحة كل مقتبس: معلوماته ونشره، وتحريره: قصّ بالنص، ترجمة، أبعاد وقوالب، غلاف، مقدّمة وخاتمة، وتصدير بجودات عالية.' },
    { sel: '.nav a[data-id="publish"]', t: 'النشر', d: 'قنواتك وقوالبها، وجدول زمني تسحب إليه المقتبسات وتوزّعها على الأيام.' },
    { sel: '.nav a[data-id="kanasha"]', t: 'الكنّاشة', d: 'دفاترك: ما تكتبه بجانب المحاضرة مختومًا بوقته، ويُحفظ في درايف مستندات مرتّبة إن شئت.' },
    { sel: '.nav a[data-id="history"]', t: 'سجلّ الإنجاز', d: 'ما أضفته إلى سجلّ دراستك وأين توقّفت، مرتّبًا بالأيام، وتقدّمك في كل سلسلة. وتستطيع استيراد سلسلة كاملة من يوتيوب.' },
    { sel: '.nav a[data-id="stats"]', t: 'الإحصاءات', d: 'تقارير دراستك ونشرك، مع نصائح وتوصيات بحسب ما تفعل.' },
    { sel: '.gpill', t: 'حساب جوجل', d: 'الجدولة ودرايف ومستندات الكناشة تعمل بعد الربط. وكل ما سواها يعمل الآن على جهازك.' },
    { t: 'وفي يوتيوب', d: 'تحت كل محاضرة شريط المقتبس: «أضف إلى سجلّ الدراسة»، و«الدفتر»، و«اقتباس»، و«وضع التركيز». وزرّ المقتبس في المشغّل، واختصاره ', cta: { label: 'افتح يوتيوب', href: 'https://www.youtube.com' } },
  ];
  App.tour = (force) => {
    if (document.querySelector('.tour')) return;
    if (!force && App.settings.tourDone) return;
    let i = 0;
    const hole = h('div.tour-hole');
    const card = h('div.tour-card');
    const root = h('div.tour', hole, card);
    document.body.appendChild(root);
    const end = async () => { root.classList.add('out'); setTimeout(() => root.remove(), 250); window.removeEventListener('resize', place); App.settings = await MQ.saveSettings({ tourDone: true }); };
    function place() {
      const st = TOUR[i];
      const el = st.sel && document.querySelector(st.sel);
      if (el && el.offsetParent !== null) {
        const r = el.getBoundingClientRect(), p = 6;
        Object.assign(hole.style, { left: r.left - p + 'px', top: r.top - p + 'px', width: r.width + p * 2 + 'px', height: r.height + p * 2 + 'px', opacity: 1 });
        const cw = Math.min(360, innerWidth - 24);
        let left = r.left - cw - 18; if (left < 12) left = Math.min(innerWidth - cw - 12, r.right + 18);
        let top = Math.min(innerHeight - card.offsetHeight - 12, Math.max(12, r.top - 10));
        Object.assign(card.style, { left: left + 'px', top: top + 'px', transform: 'none' });
      } else {
        Object.assign(hole.style, { left: '50%', top: '50%', width: '0px', height: '0px', opacity: 0 });
        Object.assign(card.style, { left: '50%', top: '50%', transform: 'translate(-50%, -50%)' });
      }
    }
    function paint() {
      const st = TOUR[i];
      card.replaceChildren(
        h('div.tour-k', `${i + 1} / ${TOUR.length}`),
        h('h3', st.t), h('p', st.d, st.cta ? h('span.kbd', MQ.shortcutLabel(App.settings.shortcut)) : null, st.cta ? '.' : null),
        h('div.tour-a',
          i < TOUR.length - 1 ? h('button.btn.btn-primary.btn-sm', { type: 'button', onclick: () => { i++; paint(); } }, 'التالي') : h('button.btn.btn-primary.btn-sm', { type: 'button', onclick: end }, 'ابدأ'),
          i ? h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { i--; paint(); } }, 'السابق') : null,
          st.cta ? h('a.btn.btn-sm', { href: st.cta.href, target: '_blank', onclick: end }, st.cta.label) : null,
          i < TOUR.length - 1 ? h('button.btn.btn-sm.btn-ghost.tour-skip', { type: 'button', onclick: end }, 'تخطَّ الجولة') : null));
      card.classList.remove('in'); void card.offsetWidth; card.classList.add('in');
      requestAnimationFrame(place);
    }
    window.addEventListener('resize', place);
    root.addEventListener('keydown', (e) => { if (e.key === 'Escape') end(); });
    paint();
  };

  // روابط الكائنات المؤقتة للمقاطع
  const urls = new Map();
  App.clipUrl = async (clipId) => {
    if (!clipId) return '';
    if (urls.has(clipId)) return urls.get(clipId);
    const c = await MQDB.get('clips', clipId);
    if (!c) return '';
    const u = URL.createObjectURL(c.blob); urls.set(clipId, u); return u;
  };
  App.thumbOf = (q) => q.thumb || (q.videoId ? MQ.thumbUrl(q.videoId) : '../assets/mark512.png');

  // ألوان ثابتة للأسماء (للمتحدثين بلا صور)
  App.nameColor = (name) => {
    const cols = ['#4A5A32', '#A56C3C', '#3E5C74', '#7A4E6B', '#5F7F6E', '#8C7A3B', '#6B5A45'];
    let x = 0; for (const ch of String(name || '')) x = (x * 31 + ch.charCodeAt(0)) >>> 0;
    return cols[x % cols.length];
  };
  App.avatar = (name, img, sm) => {
    const a = h('div.avatar' + (sm ? '.sm' : ''), { style: { background: App.nameColor(name) } });
    if (img) { const i = h('img', { src: img, alt: '', referrerPolicy: 'no-referrer' }); i.onerror = () => { i.remove(); a.textContent = MQ.initials(name); }; a.appendChild(i); }
    else a.textContent = MQ.initials(name);
    return a;
  };
  App.statusTag = (st) => h('span.ptag.' + st, { scheduled: 'مجدول', sent: 'نُشر', failed: 'تعذّر', draft: 'مسودّة' }[st] || st);

  // حوار الجدولة/النشر لمقتبس — يُستعمل من المكتبة والتقويم
  App.publishDialog = async (q, opts = {}) => {
    const [channels, templates] = await Promise.all([MQ.getChannels(), MQ.getTemplates()]);
    if (!channels.length) { App.toast('أضف قناة أولًا من النشر ← القنوات'); App.go('#/publish/channels'); return; }
    let ch = channels.find((c) => c.id === opts.channelId) || channels[0];
    let tplId = ch.templateId || 'tpl-default';
    let when = opts.at ? 'later' : (opts.mode || 'now');
    let at = opts.at || (() => { const d = new Date(Date.now() + 3600e3); d.setMinutes(0, 0, 0); return d.getTime(); })();
    let silent = false, edited = false;
    const body = h('div');
    const cap = MQ.captionBox('', () => { edited = true; });
    const fill = () => { if (edited) return; const t = templates.find((x) => x.id === tplId); cap.set(MQ.buildCaption(t ? t.body : '', q).text); };
    const localInput = (ts) => { const d = new Date(ts); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
    const paint = () => {
      const chSel = h('div.chips', channels.map((c) => h('button.chip' + (c.id === ch.id ? '.on' : ''), { type: 'button', onclick: () => { ch = c; tplId = c.templateId || tplId; edited = false; paint(); } }, h('span.dot', { style: { background: c.color } }), c.name)));
      const tplSel = h('select.select', { onchange: (e) => { tplId = e.target.value; edited = false; fill(); } }, templates.map((t) => h('option', { value: t.id, selected: t.id === tplId }, t.name)));
      const seg = h('div.seg',
        h('button' + (when === 'now' ? '.on' : ''), { type: 'button', onclick: () => { when = 'now'; paint(); } }, 'انشر الآن'),
        h('button' + (when === 'later' ? '.on' : ''), { type: 'button', onclick: () => { when = 'later'; paint(); } }, 'جدولة'));
      const whenBox = h('div', { style: { display: 'flex', gap: '10px', alignItems: 'center', flexWrap: 'wrap' } }, seg);
      if (when === 'later') {
        if (!App.linked()) whenBox.appendChild(App.lockNote('الجدولة تُنفَّذ من سحابتك في موعدها ولو كان جهازك مطفأً.'));
        else whenBox.appendChild(h('input.input', { type: 'datetime-local', value: localInput(at), style: { width: 'auto', direction: 'ltr' }, oninput: (e) => { at = new Date(e.target.value).getTime() || at; } }));
      }
      body.replaceChildren(
        h('div.field', h('span.label', 'القناة'), chSel),
        h('div.field', h('span.label', 'القالب'), tplSel),
        h('div.field', h('span.label', 'نصّ المنشور'), cap.el),
        h('label.check', h('input', { type: 'checkbox', checked: silent, onchange: (e) => { silent = e.target.checked; } }), h('span', 'بلا إشعار للمشتركين')),
        h('div.field', h('span.label', 'التوقيت'), whenBox),
      );
      fill();
    };
    paint();
    const progress = h('div.progress', { hidden: true }, h('div'));
    body.appendChild(progress);
    const setP = (p) => { if (p == null) { progress.hidden = true; return; } progress.hidden = false; progress.firstElementChild.style.width = Math.round(p * 100) + '%'; };
    App.dialog({
      title: 'نشر: ' + (q.title || 'اقتباس'), body,
      actions: [{
        label: 'تنفيذ', primary: true, icon: 'send', onClick: async () => {
          const caption = cap.value;
          const fresh = await MQDB.get('quotes', q.id);
          if (when === 'later') {
            if (!App.linked()) throw new Error(MQCloud.NEEDS);
            App.toast('جارٍ الجدولة…');
            await MQPub.schedule(fresh, ch, caption, at, { silent, onUpload: setP });
            App.toast('جُدول المنشور ✓');
          } else {
            try { await MQPub.sendNow(fresh, ch, caption, { silent, onProgress: setP, cover: !!fresh.coverClipId }); }
            catch (e) {
              if (e.code !== 'TOO_BIG') throw e;
              if (!(await App.confirm(`المقطع ${MQ.fmtSize(e.size)}، وحدّ التليجرام للبوتات 50 ميغابايت.\nأجهّز نسخة أخفّ للإرسال فقط؟ (المحفوظ يبقى بجودته)`, 'جهّز وأرسل'))) return false;
              await MQPub.sendNow(fresh, ch, caption, { silent, allowLight: true, onLightProgress: setP, onProgress: setP });
            }
            App.toast('نُشر في «' + ch.name + '» ✓');
          }
          setP(null);
          if (opts.onDone) opts.onDone();
        },
      }, { label: 'إلغاء', ghost: true }],
    });
  };
})();
