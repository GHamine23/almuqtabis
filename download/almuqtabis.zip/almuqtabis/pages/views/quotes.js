// المقتبس — مكتبة المقتبسات: الكل، بطاقات التصنيفات، المتحدّثون، والمواد والسلاسل مع وضع المراجعة.
(() => {
  const { h, icon } = MQ;
  const CAT_COLORS = ['#4A5A32', '#A56C3C', '#3E5C74', '#7A4E6B', '#5F7F6E', '#8C7A3B', '#6B5A45', '#2F4F4F', '#8E4A3A'];

  App.quoteCard = (q, i, posts) => {
    const ps = (posts || []).filter((p) => p.quoteId === q.id);
    const flags = h('div.qflags');
    if (ps.some((p) => p.status === 'sent')) flags.appendChild(h('span.qflag.sent', icon('check', 12), 'نُشر'));
    else if (ps.some((p) => p.status === 'scheduled')) flags.appendChild(h('span.qflag.sched', icon('clock', 12), 'مجدول'));
    const asp = { reel: 'ريلز', square: 'مربّع', portrait: 'عمودي' }[q.edits && q.edits.aspect];
    if (asp) flags.appendChild(h('span.qflag.edit', asp));
    const card = h('article.qcard.rise', { style: { '--i': Math.min(i, 20) }, onclick: () => openQuote(q.id) },
      h('div.qthumb', h('img', { src: App.thumbOf(q), alt: '', loading: 'lazy' }), flags,
        h('span.qbadge', MQ.fmtTime(q.duration)), h('span.qplay', icon('play', 20))),
      h('div.qbody',
        h('h3.qtitle', q.title || 'بلا عنوان'),
        h('div.qsub', [q.speaker, q.videoTitle].filter(Boolean).join(' · ')),
        q.desc ? h('div.qdesc', q.desc) : null,
        (q.categories || []).length ? h('div.qcats', q.categories.map((c) => h('span.chip.tag', c))) : null));
    return card;
  };
  const groupKey = (q) => q.series ? 's:' + q.series : 'v:' + q.videoId;
  const groupName = (q) => q.series || q.videoTitle || 'محاضرة';

  App.views.quotes = {
    title: 'المقتبسات',
    async render(page, parts, query) {
      if (parts[0] === 'review') return renderReview(page, query);
      const view = query.get('view') || 'all';
      const cat = query.get('cat'), speaker = query.get('speaker'), video = query.get('video');
      const [quotes, posts, cats, catMeta, spMeta] = await Promise.all([MQDB.all('quotes'), MQDB.all('posts'), MQ.getCategories(), MQ.getCatMeta(), MQ.getSpeakerMeta()]);
      const go = (v) => App.go('#/quotes?view=' + v);
      const switcher = App.switcher([['all', 'grid', 'الكل'], ['cats', 'tag', 'التصنيفات'], ['speakers', 'user', 'المتحدّثون'], ['series', 'series', 'المواد والسلاسل']], cat || speaker || video ? 'all' : view, go);
      const reviewBtn = quotes.length ? h('a.btn.btn-soft', { href: '#/quotes/review' }, icon('shuffle'), 'راجع مقتبسات') : null;
      page.appendChild(App.header('المقتبسات', quotes.length ? `${quotes.length} مقتبسًا من ${new Set(quotes.map((q) => q.videoId)).size} محاضرة` : 'كل ما اقتبسته من المحاضرات', [reviewBtn, switcher]));

      if (!quotes.length) {
        page.appendChild(App.empty('لا مقتبسات بعد', 'افتح محاضرة في يوتيوب، واضغط زرّ المقتبس في المشغّل، أو الاختصار ' + MQ.shortcutLabel(App.settings.shortcut) + '.',
          h('a.btn.btn-primary', { href: 'https://www.youtube.com', target: '_blank' }, 'افتح يوتيوب')));
        return;
      }

      if (view === 'cats' && !cat) return renderCats(page, quotes, cats, catMeta);
      if (view === 'speakers' && !speaker) return renderSpeakers(page, quotes, spMeta);
      if (view === 'series') return renderSeries(page, quotes);

      if (cat || speaker || video) {
        const lbl = cat ? ['tag', 'التصنيف: ', cat] : speaker ? ['user', 'المتحدّث: ', speaker] : ['play', 'المحاضرة: ', (quotes.find((q) => q.videoId === video) || {}).videoTitle || video];
        page.appendChild(h('div.filterbar', icon(lbl[0], 17), h('span', lbl[1], h('b', lbl[2])),
          h('a.btn.btn-sm.btn-ghost', { href: '#/quotes/review?' + (cat ? 'cat=' + encodeURIComponent(cat) : speaker ? 'speaker=' + encodeURIComponent(speaker) : 'g=' + encodeURIComponent('v:' + video)), style: { marginInlineStart: 'auto' } }, icon('play'), 'شاهدها متتابعة'),
          h('a.btn.btn-sm.btn-ghost', { href: '#/quotes?view=' + (cat ? 'cats' : speaker ? 'speakers' : 'all') }, 'رجوع')));
      }
      const search = h('input.input', { placeholder: 'ابحث في العناوين والأوصاف والمحاضرات…', value: query.get('q') || '' });
      const sort = h('select.select', h('option', { value: 'new' }, 'الأحدث'), h('option', { value: 'old' }, 'الأقدم'), h('option', { value: 'lecture' }, 'حسب المحاضرة'), h('option', { value: 'len' }, 'الأطول'), h('option', { value: 'review' }, 'الأقلّ مراجعة'));
      const state = h('select.select', h('option', { value: '' }, 'كل الحالات'), h('option', { value: 'sent' }, 'المنشورة'), h('option', { value: 'scheduled' }, 'المجدولة'), h('option', { value: 'none' }, 'غير المنشورة'));
      page.appendChild(h('div.toolbar', h('div.searchbox', icon('search'), search), sort, state));
      const grid = h('div.qgrid');
      page.appendChild(grid);
      const paint = () => {
        const s = search.value.trim().toLowerCase();
        let list = quotes.filter((q) => {
          if (cat && !(q.categories || []).includes(cat)) return false;
          if (speaker && (q.speaker || q.channel || 'بلا اسم') !== speaker) return false;
          if (video && q.videoId !== video) return false;
          const ps = posts.filter((p) => p.quoteId === q.id);
          if (state.value === 'sent' && !ps.some((p) => p.status === 'sent')) return false;
          if (state.value === 'scheduled' && !ps.some((p) => p.status === 'scheduled')) return false;
          if (state.value === 'none' && ps.length) return false;
          return !s || [q.title, q.desc, q.videoTitle, q.speaker, q.series, ...(q.categories || [])].join(' ').toLowerCase().includes(s);
        });
        const so = sort.value;
        list.sort((a, b) => so === 'old' ? a.createdAt - b.createdAt : so === 'lecture' ? (a.videoTitle || '').localeCompare(b.videoTitle || '', 'ar') || a.start - b.start : so === 'len' ? b.duration - a.duration : so === 'review' ? (a.reviews || 0) - (b.reviews || 0) || (a.reviewedAt || 0) - (b.reviewedAt || 0) : b.createdAt - a.createdAt);
        grid.replaceChildren(...(list.length ? list.map((q, i) => App.quoteCard(q, i, posts)) : [h('p.hint', 'لا نتائج تطابق البحث.')]));
      };
      search.addEventListener('input', MQ.debounce(paint, 150));
      sort.onchange = paint; state.onchange = paint;
      paint();
      if (parts[0]) openQuote(parts[0]);
    },
  };

  // ---------- بطاقات التصنيفات (قابلة للتعديل) ----------
  function renderCats(page, quotes, cats, meta) {
    const map = new Map(cats.map((c) => [c, []]));
    const none = [];
    quotes.forEach((q) => { if (!(q.categories || []).length) none.push(q); (q.categories || []).forEach((c) => { if (!map.has(c)) map.set(c, []); map.get(c).push(q); }); });
    const grid = h('div.cgrid');
    let i = 0;
    const entries = [...map.entries()].sort((a, b) => ((meta[a[0]] || {}).order ?? 999) - ((meta[b[0]] || {}).order ?? 999) || b[1].length - a[1].length);
    for (const [c, list] of entries) grid.appendChild(catCard(c, list, i++, '#/quotes?view=all&cat=' + encodeURIComponent(c), meta[c] || {}, quotes));
    if (none.length) grid.appendChild(catCard('بلا تصنيف', none, i++, null, {}, quotes, true));
    grid.appendChild(h('button.ccard.cnew.rise', { type: 'button', style: { '--i': i }, onclick: async () => { const v = await App.prompt('تصنيف جديد'); if (v) { await MQ.mergeCategories([v]); App.refresh(); } } }, icon('plus', 28), h('span', 'تصنيف جديد')));
    page.appendChild(grid);
  }
  function catCard(name, list, i, href, m, quotes, virtual) {
    const thumbs = [...list].sort((a, b) => b.createdAt - a.createdAt).slice(0, 4);
    let cover;
    if (m.cover) cover = h('div.mosaic.n1', h('img', { src: m.cover, alt: '' }));
    else {
      cover = h('div.mosaic.n' + Math.min(4, thumbs.length));
      if (!thumbs.length) cover.appendChild(h('div.ph1', icon('tag', 34)));
      thumbs.forEach((q) => cover.appendChild(h('img', { src: App.thumbOf(q), alt: '', loading: 'lazy' })));
    }
    const edit = virtual ? null : h('button.cedit', { type: 'button', title: 'تعديل البطاقة' }, icon('more', 18));
    if (edit) edit.onclick = (e) => { e.stopPropagation(); App.menu(edit, [
      { title: name },
      { icon: 'edit', label: 'تعديل البطاقة', onClick: () => editCat(name, m, list) },
      { icon: 'play', label: 'شاهد مقتبساته متتابعة', onClick: () => App.go('#/quotes/review?cat=' + encodeURIComponent(name)) },
      'hr',
      { icon: 'trash', label: 'حذف التصنيف', danger: true, onClick: () => deleteCat(name, list) },
    ]); };
    return h('div.ccard.rise', { style: { '--i': i, '--cc': m.color || 'transparent' }, onclick: () => href ? App.go(href) : null },
      cover, h('span.tagdot', { style: m.color ? { background: m.color } : null }, icon('tag')), edit,
      h('div.ccard-b', h('div', { style: { flex: 1, minWidth: 0 } }, h('h3', name), m.desc ? h('p.cdesc', m.desc) : null), h('span.n', list.length ? `${list.length} مقتبس` : 'فارغ')));
  }
  async function editCat(name, m, list) {
    const nm = h('input.input', { value: name });
    const desc = h('input.input', { value: m.desc || '', placeholder: 'وصف قصير (اختياري)' });
    let color = m.color || '', cover = m.cover || '';
    const sw = h('div.swatches');
    const paintSw = () => sw.replaceChildren(
      h('button', { type: 'button', title: 'بلا لون', class: color ? '' : 'on', style: { background: 'var(--surface-2)' }, onclick: () => { color = ''; paintSw(); } }),
      ...CAT_COLORS.map((c) => h('button', { type: 'button', class: c === color ? 'on' : '', style: { background: c }, onclick: () => { color = c; paintSw(); } })));
    paintSw();
    const covers = h('div.covpick');
    const paintCov = () => covers.replaceChildren(
      h('button.cov' + (!cover ? '.on' : ''), { type: 'button', onclick: () => { cover = ''; paintCov(); } }, h('span', 'فسيفساء تلقائية')),
      ...[...new Set(list.map((q) => App.thumbOf(q)))].slice(0, 8).map((src) => h('button.cov' + (cover === src ? '.on' : ''), { type: 'button', onclick: () => { cover = src; paintCov(); } }, h('img', { src, alt: '' }))),
      h('label.cov.up', icon('upload', 18), h('span', 'صورة من جهازك'), h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async (e) => { const f = e.target.files[0]; if (f) { cover = await App.imageToDataUrl(f, 640); paintCov(); } } })));
    paintCov();
    App.dialog({ title: 'تعديل بطاقة التصنيف', body: h('div',
      h('div.field', h('label', 'الاسم'), nm),
      h('div.field', h('label', 'الوصف'), desc),
      h('div.field', h('span.label', 'اللون'), sw),
      h('div.field', h('span.label', 'الغلاف'), covers)),
    actions: [{ label: 'حفظ', primary: true, onClick: async () => {
      const to = nm.value.trim() || name;
      if (to !== name) await renameCategory(name, to);
      await MQ.setCatMeta(to, { color, cover, desc: desc.value.trim() });
      App.toast('حُفظت البطاقة'); App.refresh();
    } }, { label: 'إلغاء', ghost: true }] });
  }
  async function renameCategory(from, to) {
    const qs = await MQDB.all('quotes');
    for (const q of qs) if ((q.categories || []).includes(from)) await MQDB.put('quotes', { ...q, categories: [...new Set(q.categories.map((c) => c === from ? to : c))], indexDirty: true });
    const cats = await MQ.getCategories();
    await MQ.setCategories(cats.map((c) => c === from ? to : c));
    await MQ.renameMetaKey('catMeta', from, to);
    MQDB.notify('quotes');
  }
  async function deleteCat(name, list) {
    if (!(await App.confirm(`حذف التصنيف «${name}»؟ يُزال من ${list.length} مقتبس، ولا تُحذف المقتبسات.`, 'حذف', true))) return;
    for (const q of list) await MQDB.put('quotes', { ...q, categories: (q.categories || []).filter((c) => c !== name) });
    await MQ.setCategories((await MQ.getCategories()).filter((c) => c !== name));
    await MQ.setCatMeta(name, null);
    App.toast('حُذف التصنيف'); App.refresh();
  }

  // ---------- المتحدّثون (قابلون للتعديل) ----------
  function renderSpeakers(page, quotes, meta) {
    const map = new Map();
    quotes.forEach((q) => { const k = q.speaker || q.channel || 'بلا اسم'; if (!map.has(k)) map.set(k, []); map.get(k).push(q); });
    const grid = h('div.sgrid');
    [...map.entries()].sort((a, b) => b[1].length - a[1].length).forEach(([name, list], i) => {
      const m = meta[name] || {};
      const img = m.avatar || (list.find((q) => q.avatar) || {}).avatar;
      const lectures = new Set(list.map((q) => q.videoId)).size;
      const edit = h('button.cedit', { type: 'button', title: 'تعديل' }, icon('more', 18));
      edit.onclick = (e) => { e.stopPropagation(); App.menu(edit, [
        { title: name },
        { icon: 'edit', label: 'تعديل الاسم والصورة', onClick: () => editSpeaker(name, m, img, [...map.keys()]) },
        { icon: 'play', label: 'شاهد مقتبساته متتابعة', onClick: () => App.go('#/quotes/review?speaker=' + encodeURIComponent(name)) },
      ]); };
      grid.appendChild(h('div.scard.rise', { style: { '--i': i }, onclick: () => App.go('#/quotes?view=all&speaker=' + encodeURIComponent(name)) },
        edit, App.avatar(name, img), h('h3', name), m.bio ? h('p.sbio', m.bio) : null, h('div.n', `${list.length} مقتبس · ${lectures} محاضرة`),
        h('div.strip', list.slice(0, 3).map((q) => h('img', { src: App.thumbOf(q), alt: '', loading: 'lazy' })))));
    });
    page.appendChild(grid);
  }
  function editSpeaker(name, m, img, names) {
    const nm = h('input.input', { value: name, list: 'mqSpeakers' });
    const dl = h('datalist#mqSpeakers', names.filter((n) => n !== name).map((n) => h('option', { value: n })));
    const bio = h('input.input', { value: m.bio || '', placeholder: 'تعريف قصير (اختياري)' });
    let avatar = m.avatar || '';
    const prev = h('div.avprev');
    const paint = () => prev.replaceChildren(App.avatar(nm.value || name, avatar || img),
      h('div', { style: { display: 'flex', gap: '6px', flexWrap: 'wrap' } },
        h('label.btn.btn-sm', icon('upload'), 'رفع صورة', h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: async (e) => { const f = e.target.files[0]; if (f) { avatar = await App.imageToDataUrl(f, 256, true); paint(); } } })),
        avatar ? h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { avatar = ''; paint(); } }, 'إزالة الصورة') : null));
    paint();
    App.dialog({ title: 'تعديل المتحدّث', body: h('div', prev,
      h('div.field', h('label', 'الاسم'), nm, dl, h('span.hint', 'إن كتبتَ اسم متحدّث موجود دُمج الاثنان في بطاقة واحدة.')),
      h('div.field', h('label', 'تعريف'), bio)),
    actions: [{ label: 'حفظ', primary: true, onClick: async () => {
      const to = nm.value.trim() || name;
      if (to !== name) await renameSpeaker(name, to);
      await MQ.setSpeakerMeta(to, { avatar, bio: bio.value.trim() });
      App.toast('حُفظ'); App.refresh();
    } }, { label: 'إلغاء', ghost: true }] });
  }
  async function renameSpeaker(from, to) {
    const qs = await MQDB.all('quotes');
    for (const q of qs) if ((q.speaker || q.channel || 'بلا اسم') === from) await MQDB.put('quotes', { ...q, speaker: to, indexDirty: true });
    const ws = await MQDB.all('watch');
    for (const w of ws) if ((w.speaker || w.channel || 'بلا اسم') === from) await MQDB.put('watch', { ...w, speaker: to, speakerEdited: true });
    await MQ.renameMetaKey('speakerMeta', from, to);
    MQDB.notify('quotes');
  }

  // تصغير صورة مرفوعة إلى رابط بيانات
  App.imageToDataUrl = (file, max = 512, square) => new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      let w = img.naturalWidth, hh = img.naturalHeight, sx = 0, sy = 0, sw = w, sh = hh;
      if (square) { const m = Math.min(w, hh); sx = (w - m) / 2; sy = (hh - m) / 2; sw = sh = m; w = hh = m; }
      const k = Math.min(1, max / Math.max(w, hh));
      const c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(hh * k);
      c.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
      resolve(c.toDataURL('image/jpeg', 0.9)); URL.revokeObjectURL(img.src);
    };
    img.onerror = () => reject(new Error('تعذّر قراءة الصورة'));
    img.src = URL.createObjectURL(file);
  });

  // ---------- المواد والسلاسل ----------
  function renderSeries(page, quotes) {
    const map = new Map();
    quotes.forEach((q) => { const k = groupKey(q); if (!map.has(k)) map.set(k, { key: k, name: groupName(q), isSeries: !!q.series, list: [] }); map.get(k).list.push(q); });
    const groups = [...map.values()].sort((a, b) => Math.max(...b.list.map((q) => q.createdAt)) - Math.max(...a.list.map((q) => q.createdAt)));
    page.appendChild(h('p.hint', { style: { margin: '-8px 0 14px' } }, 'مقتبساتك مجمّعة بالسلسلة، أو بالمحاضرة إن لم تكن في سلسلة. افتح أيّها لتشاهد مقتبساته متتابعة، مع مقترحات أخرى للمراجعة.'));
    page.appendChild(h('div.mgrid', groups.map((g, i) => {
      const lectures = new Set(g.list.map((q) => q.videoId)).size;
      const reviewed = g.list.filter((q) => q.reviews).length;
      const dur = g.list.reduce((a, q) => a + (q.duration || 0), 0);
      const thumbs = [...new Set(g.list.map((q) => q.videoId))].slice(0, 3);
      return h('div.mcard.rise', { style: { '--i': Math.min(i, 20) }, onclick: () => App.go('#/quotes/review?g=' + encodeURIComponent(g.key)) },
        h('div.mstack', thumbs.map((v, k) => h('img', { src: MQ.thumbUrl(v), alt: '', loading: 'lazy', style: { '--k': k } }))),
        h('span.mkind', icon(g.isSeries ? 'series' : 'play', 13), g.isSeries ? 'سلسلة' : 'محاضرة'),
        h('div.mbd', h('h3', g.name),
          h('div.hint', [g.list[0].speaker, g.isSeries ? `${lectures} محاضرة` : '', `${g.list.length} مقتبس`, MQ.fmtDur(dur)].filter(Boolean).join(' · ')),
          App.progressBar(Math.round((reviewed / g.list.length) * 100), { sm: true, label: false }),
          h('div.hint', { style: { marginTop: '4px', fontSize: '12px' } }, reviewed ? `راجعتَ ${reviewed} من ${g.list.length}` : 'لم تراجع منها شيئًا بعد')));
    })));
  }

  // ---------- وضع المراجعة: مشاهدة متتابعة ومقترحات ----------
  async function renderReview(page, query) {
    const [all, posts] = await Promise.all([MQDB.all('quotes'), MQDB.all('posts')]);
    if (!all.length) { page.appendChild(App.empty('لا مقتبسات', '')); return; }
    const g = query.get('g'), cat = query.get('cat'), speaker = query.get('speaker');
    let title = 'مراجعة المقتبسات', set;
    if (g) { set = all.filter((q) => groupKey(q) === g).sort((a, b) => (a.videoTitle || '').localeCompare(b.videoTitle || '', 'ar') || a.start - b.start); title = set[0] ? groupName(set[0]) : title; }
    else if (cat) { set = all.filter((q) => (q.categories || []).includes(cat)); title = 'التصنيف: ' + cat; }
    else if (speaker) { set = all.filter((q) => (q.speaker || q.channel || 'بلا اسم') === speaker); title = 'المتحدّث: ' + speaker; }
    else { set = App.pickForReview(all, 12); title = 'مقترحة لك للمراجعة'; }
    if (!set.length) { page.appendChild(App.empty('لا شيء هنا', '')); return; }
    let idx = Math.max(0, set.findIndex((q) => q.id === query.get('q')));
    let auto = true;

    page.classList.add('wide');
    const player = h('video.rv-video', { controls: true, playsInline: true, autoplay: true });
    const info = h('div.rv-info');
    const queue = h('div.rv-queue');
    const sugg = h('div.rv-sugg');
    const autoSw = h('label.row-switch', { style: { padding: '0' } }, h('span', 'تشغيل التالي تلقائيًّا'), h('span.switch', h('input', { type: 'checkbox', checked: true, onchange: (e) => { auto = e.target.checked; } }), h('span')));
    page.append(
      App.header(title, `${set.length} مقتبس — شاهدها متتابعة، وعلّم ما راجعته`, [h('a.btn.btn-ghost', { href: '#/quotes?view=series' }, 'رجوع')]),
      h('div.review', h('div.rv-main', h('div.rv-stage', player), info), h('aside.rv-side', h('div.card.pad', { style: { padding: '12px 14px' } }, autoSw), h('h3.rv-h', 'في هذه القائمة'), queue, h('h3.rv-h', 'مقترحة للمراجعة'), sugg)));

    const markReviewed = async (q) => {
      const n = await MQDB.patch('quotes', q.id, (cur) => ({ ...cur, reviews: (cur.reviews || 0) + 1, reviewedAt: Date.now() }));
      Object.assign(q, n);
    };
    const show = async (i) => {
      idx = i; const q = set[idx];
      const clip = await MQPub.publishClip(q);
      const url = clip ? await App.clipUrl(clip.id) : '';
      if (url) { player.src = url; player.poster = ''; player.play().catch(() => {}); } else { player.removeAttribute('src'); player.poster = App.thumbOf(q); }
      info.replaceChildren(
        h('div.rv-meta', h('span', `${idx + 1} / ${set.length}`), q.speaker ? h('span', q.speaker) : null, h('span', q.videoTitle || ''), h('span', `${MQ.fmtTime(q.start)}–${MQ.fmtTime(q.end)}`)),
        h('h2.rv-title', q.title || 'اقتباس'),
        q.desc ? h('p.rv-desc', q.desc) : null,
        (q.categories || []).length ? h('div.chips', q.categories.map((c) => h('span.chip.tag', c))) : null,
        h('div.rv-acts',
          h('button.btn', { type: 'button', disabled: idx === 0, onclick: () => show(idx - 1) }, icon('chevronL'), 'السابق'),
          h('button.btn.btn-primary', { type: 'button', onclick: async (e) => { await markReviewed(q); e.target.closest('button').classList.add('done'); App.toast('سُجّلت مراجعته ✓'); paintQueue(); if (idx < set.length - 1) show(idx + 1); } }, icon('check'), q.reviews ? `راجعته (${q.reviews})` : 'راجعته'),
          h('button.btn', { type: 'button', disabled: idx >= set.length - 1, onclick: () => show(idx + 1) }, 'التالي', icon('chevron')),
          h('a.btn.btn-ghost', { href: q.link, target: '_blank' }, icon('play'), 'في المحاضرة'),
          h('a.btn.btn-ghost', { href: '#/studio/' + q.id + '?tab=info' }, icon('wand'), 'الاستوديو')),
        !url ? h('p.hint', 'ملف هذا المقتبس غير محفوظ على جهازك؛ افتحه في المحاضرة.') : null);
      paintQueue(); paintSugg();
    };
    const paintQueue = () => queue.replaceChildren(...set.map((q, i) => h('button.rvq' + (i === idx ? '.on' : '') + (q.reviews ? '.rd' : ''), { type: 'button', onclick: () => show(i) },
      h('img', { src: App.thumbOf(q), alt: '' }), h('span', q.title || 'اقتباس'), q.reviews ? icon('check', 14) : null)));
    const paintSugg = () => {
      const cur = set[idx];
      const others = all.filter((q) => !set.includes(q));
      const score = (q) => (q.speaker && q.speaker === cur.speaker ? 3 : 0) + (q.categories || []).filter((c) => (cur.categories || []).includes(c)).length * 2 + (q.series && q.series === cur.series ? 2 : 0) - (q.reviews || 0) * 0.5;
      const top = others.map((q) => [q, score(q)]).filter((x) => x[1] > 0).sort((a, b) => b[1] - a[1]).slice(0, 6).map((x) => x[0]);
      const list = top.length ? top : App.pickForReview(others, 6);
      sugg.replaceChildren(...(list.length ? list.map((q) => h('a.rvq', { href: '#/quotes/review?' + new URLSearchParams({ g: groupKey(q), q: q.id }) },
        h('img', { src: App.thumbOf(q), alt: '' }), h('span', h('b', q.title || 'اقتباس'), h('small', q.speaker || q.videoTitle || '')))) : [h('p.hint', 'لا مقترحات أخرى.')]));
    };
    player.addEventListener('ended', async () => { const q = set[idx]; if (!q.reviews) await markReviewed(q); paintQueue(); if (auto && idx < set.length - 1) setTimeout(() => show(idx + 1), 900); });
    show(idx);
  }

  // اختيار مقتبسات للمراجعة: الأقل مراجعةً والأقدم عهدًا أولًا، مع شيء من التنويع
  App.pickForReview = (quotes, n) => {
    const now = Date.now();
    const scored = quotes.map((q) => {
      const since = (now - (q.reviewedAt || q.createdAt || now)) / 86400e3;
      return [q, since / ((q.reviews || 0) + 1) + Math.random() * 3];
    }).sort((a, b) => b[1] - a[1]);
    return scored.slice(0, n).map((x) => x[0]);
  };

  // فتح المقتبس: صفحته في الاستوديو (المعلومات والنشر والمشاركة)
  function openQuote(id) { App.go('#/studio/' + id + '?tab=info'); }
  App.openQuote = openQuote;

  function shareMenu(anchor, q) {
    const t = MQPub.shareTargets(q);
    const hasDrive = q.drive && q.drive.fileId;
    const text = [q.title, q.desc, q.speaker && ('— ' + q.speaker), t.link].filter(Boolean).join('\n\n');
    App.menu(anchor, [
      { title: 'مشاركة الاقتباس' },
      { icon: 'link', label: 'نسخ رابط اللحظة في يوتيوب', onClick: () => App.copy(q.link, 'نُسخ الرابط') },
      hasDrive ? { icon: 'drive', label: q.drive.shared ? 'نسخ رابط الملف في درايف' : 'مشاركة رابط درايف (لكل من لديه الرابط)', onClick: async () => { try { const u = await MQPub.shareDrive(q); App.copy(u, 'نُسخ رابط درايف'); } catch (e) { App.toast(e.message); } } }
        : { icon: 'drive', label: App.linked() ? 'ارفعه وشارك رابط درايف' : 'رابط درايف (بعد ربط جوجل)', disabled: !App.linked(), onClick: async () => { App.toast('جارٍ الرفع…'); try { await MQPub.ensureDrive(q); const fresh = await MQDB.get('quotes', q.id); const u = await MQPub.shareDrive(fresh); App.copy(u, 'رُفع ونُسخ رابط درايف'); } catch (e) { App.toast(e.message, 4000); } } },
      { icon: 'copy', label: 'نسخ النصّ مع الرابط', onClick: () => App.copy(text, 'نُسخ النصّ') },
      { icon: 'keep', label: 'إلى جوجل كيب', onClick: () => App.toKeep(text) },
      'hr',
      { icon: 'whatsapp', label: 'واتساب', href: t.whatsapp },
      { icon: 'telegram', label: 'تليجرام', href: t.telegram },
      { icon: 'xlogo', label: 'إكس', href: t.x },
      { icon: 'share', label: 'فيسبوك', href: t.facebook },
      { icon: 'mail', label: 'بريد', href: t.email, target: '_self' },
    ]);
  }
  App.shareMenu = shareMenu;

  // جوجل كيب لا يتيح واجهة برمجية للحسابات الشخصية؛ فننسخ النصّ ونفتح ملاحظة جديدة ليُلصق فيها
  App.toKeep = async (text) => {
    try { await navigator.clipboard.writeText(text); } catch (_) {}
    window.open('https://keep.google.com/#home', '_blank');
    App.toast('نُسخ النصّ — اضغط «إنشاء ملاحظة» في كيب ثم الصق (Ctrl+V)', 5200);
  };
})();
