// المقتبس — الإعدادات، والترحيب.
(() => {
  const { h, icon } = MQ;
  const SECS = [
    ['record', 'scissors', 'الاقتباس'],
    ['google', 'drive', 'حساب جوجل'],
    ['telegram', 'telegram', 'التليجرام'],
    ['tracking', 'history', 'السجلّ والدفتر'],
    ['home', 'home', 'الرئيسية'],
    ['logo', 'badge', 'الشعار'],
    ['data', 'layers', 'البيانات'],
    ['updates', 'refresh', 'التحديثات'],
    ['about', 'feedback', 'عن المقتبس'],
  ];
  const YT_KEYS = new Set(['KeyK', 'KeyJ', 'KeyL', 'KeyF', 'KeyM', 'KeyC', 'KeyT', 'KeyI', 'KeyN', 'KeyP', 'Space', 'Comma', 'Period', 'Slash', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Home', 'End', ...[...Array(10)].map((_, i) => 'Digit' + i)]);

  const save = async (patch, quiet) => { App.settings = await MQ.saveSettings(patch); if (!quiet) App.toast('حُفظ'); return App.settings; };
  const sw = (label, key, hint) => h('label.row-switch', h('span', label, hint ? h('div.hint', hint) : null),
    h('span.switch', h('input', { type: 'checkbox', checked: !!App.settings[key], onchange: (e) => save({ [key]: e.target.checked }) }), h('span')));

  App.views.settings = {
    title: 'الإعدادات',
    async render(page, parts) {
      const sec = SECS.some((s) => s[0] === parts[0]) ? parts[0] : 'record';
      page.appendChild(App.header('الإعدادات', 'اضبط المقتبس على طريقتك.'));
      const nav = h('nav.set-nav', SECS.map(([id, ic, l]) => h('a' + (id === sec ? '.on' : ''), { href: '#/settings/' + id }, icon(ic), l)));
      const body = h('div');
      page.appendChild(h('div.set', nav, body));
      await SECTIONS[sec](body);
    },
  };

  const card = (title, desc, ...kids) => h('div.set-sec.card.pad', title ? h('h2', title) : null, desc ? h('p', desc) : null, ...kids);

  const SECTIONS = {
    async record(body) {
      const s = App.settings;
      const keyBtn = h('button.btn', { type: 'button', style: { direction: 'ltr', fontFamily: 'ui-monospace, monospace', minWidth: '140px' } }, MQ.shortcutLabel(s.shortcut));
      const keyHint = h('div.hint', 'اضغط الزر ثم الاختصار. يُفضَّل معه Alt أو Ctrl حتى لا يتعارض مع اختصارات يوتيوب.');
      let listening = false;
      keyBtn.onclick = () => { listening = true; keyBtn.textContent = 'اضغط الآن… (Esc للإلغاء)'; };
      const onKey = async (e) => {
        if (!listening || ['Alt', 'Control', 'Shift', 'Meta', 'AltGraph', 'OS'].includes(e.key)) return;
        e.preventDefault(); e.stopPropagation(); listening = false;
        if (e.code === 'Escape') { keyBtn.textContent = MQ.shortcutLabel(App.settings.shortcut); return; }
        const sc = { code: e.code, alt: e.altKey, ctrl: e.ctrlKey, shift: e.shiftKey, meta: e.metaKey };
        await save({ shortcut: sc }, true);
        keyBtn.textContent = MQ.shortcutLabel(sc);
        keyHint.textContent = (!sc.alt && !sc.ctrl && !sc.meta && YT_KEYS.has(sc.code)) ? 'تنبيه: هذا المفتاح من اختصارات يوتيوب، وسيتعطّل عمله الأصلي.' : 'حُفظ الاختصار ✓';
      };
      window.addEventListener('keydown', onKey, true);
      App.onCleanup(() => window.removeEventListener('keydown', onKey, true));
      const sel = (key, opts, cast = String) => h('select.select', { onchange: (e) => save({ [key]: cast(e.target.value) }) }, opts.map(([v, l]) => h('option', { value: v, selected: String(App.settings[key]) === String(v) }, l)));
      body.append(
        card('الاقتباس من يوتيوب', 'كيف يبدأ التسجيل وينتهي.',
          h('div.grid2',
            h('div.field', h('label', 'اختصار البدء والإيقاف'), keyBtn, keyHint),
            h('div.field', h('label', 'العدّ التنازلي قبل التسجيل'), sel('countdown', [[0, 'بلا عدّ'], [3, '3 ثوانٍ'], [5, '5 ثوانٍ'], [7, '7 ثوانٍ'], [10, '10 ثوانٍ']], Number))),
          h('div.grid2',
            h('div.field', h('label', 'جودة الحفظ'), sel('bitrate', [[16000000, 'قصوى — نحو 120 ميغابايت للدقيقة'], [10000000, 'عالية — نحو 75 ميغابايت للدقيقة'], [6000000, 'متوسطة — نحو 45 ميغابايت للدقيقة'], [4000000, 'خفيفة — نحو 30 ميغابايت للدقيقة']], Number),
              h('div.hint', 'يُسجَّل بدقّة الفيديو نفسه. وحدّ التليجرام للبوتات 50 ميغابايت.')),
            h('div.field', h('label', 'صيغة التسجيل'), sel('recordCodec', [['auto', 'تلقائي (MP4 إن أمكن)'], ['mp4', 'MP4'], ['webm', 'WebM (أخفّ على المعالج في بعض الأجهزة)']]),
              h('div.hint', 'إن لاحظت تقطّعًا في التسجيل على جهازك فجرّب WebM.'))),
          sw('تثبيت جودة يوتيوب على أعلاها أثناء الاقتباس', 'lockQuality', 'يمنع تبديل الجودة في منتصف التسجيل، وهو من أسباب تعليق الصورة. تعود الجودة كما كانت بعده.'),
          sw('حفظ نسخة من كل مقتبس على جهازي', 'localCopy', 'إضافةً إلى حفظه داخل المنصّة — في المجلّد المختار أدناه.'),
          sw('تثبيت السرعة على 1× أثناء التسجيل', 'forceNormalSpeed', 'حتى لا يخرج صوت المحاضر مسرّعًا إن كنت تشاهد بسرعة أعلى.'),
          sw('إيقاف المحاضرة مؤقتًا عند فتح نافذة الحفظ', 'pauseWhileEditing'),
          h('div.field', { style: { marginTop: '12px' } }, h('label', 'لغة النص المفضّلة من يوتيوب'), sel('captionsLang', [['ar', 'العربية'], ['en', 'الإنجليزية'], ['tr', 'التركية'], ['fr', 'الفرنسية']]))),
        await saveCard(),
        card('التصدير من الاستوديو', null,
          h('div.field', h('label', 'الجودة المعتادة'), sel('exportPreset', Object.entries(MQEditor.QUALITY).map(([k, x]) => [k, `${x.label} — حتى ${x.short}p · ${x.hint}`])))),
      );
    },

    async google(body) {
      const s = App.settings;
      const linked = App.linked();
      const status = h('div.status');
      const services = h('div.svc',
        [['جدولة النشر في التليجرام في مواعيده ولو كان جهازك مطفأً', true], ['رفع المقتبسات إلى درايف ومشاركة روابطها', true], ['مزامنة الكناشة: مجلّد لكل دفتر، ومستند جوجل لكل تدوين', true], ['تصدير التدوين إلى مستندات جوجل', true], ['فهرس في درايف يقرؤه تطبيق الجوال والموقع لاحقًا', true],
          ['الاقتباس والتحرير والنشر الفوري والسجلّ والكناشة محليًّا', false]]
          .map(([t, needs]) => h('div', icon(needs ? (linked ? 'check' : 'lock') : 'check'), h('span', { class: needs ? (linked ? 'ok' : 'lk') : 'ok' }, t), needs && !linked ? h('span.hint', '— بعد الربط') : null)));
      services.querySelectorAll('div').forEach((d) => { const ic = d.querySelector('svg'); ic.classList.add(d.querySelector('.lk') ? 'lk' : 'ok'); });

      if (linked) {
        body.append(
          card('حساب جوجل', null,
            h('div.note-info', icon('check'), h('span', 'مربوط بحساب ', h('b', s.cloud.email || ''), ' منذ ', MQ.fmtDate(s.cloud.linkedAt))),
            h('div', { style: { display: 'flex', gap: '8px', margin: '12px 0', flexWrap: 'wrap' } },
              h('button.btn', { onclick: async () => { status.textContent = 'جارٍ الاختبار…'; try { const r = await MQCloud.call('ping'); status.textContent = `يعمل ✓ — الجدولة ${r.trigger ? 'مفعّلة' : 'غير مفعّلة: شغّل الدالة setup في السكربت'}`; status.className = 'status ' + (r.trigger ? 'ok' : 'err'); if (r.rootUrl) await save({ cloud: { ...App.settings.cloud, rootUrl: r.rootUrl } }, true); } catch (e) { status.textContent = e.message; status.className = 'status err'; } } }, icon('refresh'), 'اختبار الاتصال'),
              s.cloud.rootUrl ? h('a.btn', { href: s.cloud.rootUrl, target: '_blank' }, icon('folder'), 'مجلّد المقتبس في درايف') : null,
              h('button.btn.btn-ghost', { onclick: () => wizard(body, true) }, 'تحديث الكود أو الرابط'),
              h('button.btn.btn-ghost.btn-danger', { onclick: async () => { if (await App.confirm('فكّ الربط؟ تتوقّف الجدولة من هذه الإضافة، ويبقى ما في درايف كما هو.', 'فكّ الربط', true)) { await save({ cloud: { url: '', key: '', email: '', linkedAt: 0 } }); App.refresh(); } } }, 'فكّ الربط')),
            status),
          card('المزامنة', null,
            sw('رفع كل مقتبس جديد إلى درايف تلقائيًا', 'autoUploadClips', 'في مجلّد: المقتبس ← المقتطفات ← اسم المحاضر.'),
            sw('حفظ الكناشة في درايف تلقائيًا', 'autoSyncNotes', 'كل دفتر مجلّد بنفس اسمه، وكل تدوين مستند جوجل مرتّب من اليمين لليسار.'),
            sw('جعل الملفات المرفوعة قابلة للمشاركة بالرابط', 'shareUploads', 'لمشاركة رابط درايف للاقتباس مباشرة.'),
            h('div', { style: { marginTop: '10px' } }, h('button.btn.btn-sm', { onclick: async (e) => { e.target.disabled = true; App.toast('جارٍ المزامنة…'); try { const n = await MQSync.syncDirtyNotes(App.settings.cloud, 50); await MQSync.pushIndex(App.settings.cloud); App.toast(`زُومن ${n} تدوين ✓`); } catch (er) { App.toast(er.message, 4000); } e.target.disabled = false; } }, icon('refresh'), 'زامن الآن'))),
          card('ما يعمل بالربط', null, services));
        return;
      }
      body.append(card('اربط المقتبس بحساب جوجل', 'الربط يتمّ عبر سكربت صغير تضعه أنت في حسابك على جوجل، فيعمل على سحابتك وحدها، ولا تمرّ بياناتك بأي خادم آخر.', services));
      wizard(body, false);
    },

    async telegram(body) {
      const s = App.settings;
      const tok = h('input.input.ltr', { type: 'password', value: s.tgToken || '', placeholder: '123456789:AA…', onchange: (e) => save({ tgToken: e.target.value.trim() }) });
      const st = h('div.status');
      body.append(card('بوت التليجرام', 'بوت واحد يكفي لكل قنواتك، ما دام مشرفًا فيها.',
        h('div.steps',
          h('div.step', h('div', h('b', 'أنشئ البوت'), h('div.hint', 'افتح في التليجرام الحساب الرسمي لصناعة البوتات:'), h('div.code-line', '@BotFather'), h('div.hint', 'وأرسل له الأمر التالي، واتبع أسئلته، فيعطيك في آخرها رمز البوت:'), h('div.code-line', '/newbot'))),
          h('div.step', h('div', h('b', 'أضفه مشرفًا في قنواتك'), h('div.hint', 'من إعدادات القناة ← المشرفون ← إضافة مشرف، مع صلاحية نشر الرسائل.'))),
          h('div.step', h('div', h('b', 'الصق الرمز هنا'), tok, h('div.hint', 'يبقى في متصفحك، ولا يُرسل إلا إلى خوادم التليجرام — وإلى سكربتك في جوجل للمنشورات المجدولة.')))),
        h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } },
          h('button.btn', { onclick: async () => { st.textContent = 'جارٍ الاختبار…'; try { const me = await MQ.tgCall(tok.value.trim(), 'getMe'); st.textContent = `البوت يعمل ✓ — ${me.first_name}`; st.className = 'status ok'; await save({ tgToken: tok.value.trim() }, true); } catch (e) { st.textContent = e.message; st.className = 'status err'; } } }, 'اختبار الرمز'),
          h('a.btn.btn-soft', { href: '#/publish/channels' }, icon('send'), 'إدارة القنوات'), st)));
    },

    async tracking(body) {
      body.append(
        card('سجلّ الدراسة', 'يحفظ المقتبس ما تضيفه إلى سجلّ دراستك وأين توقّفت، في متصفحك وحده.',
          sw('تسجيل المشاهدة', 'tracking', 'إيقافه يوقف السجلّ كله.'),
          sw('إضافة كل محاضرة أفتحها إلى سجلّ الدراسة تلقائيًّا', 'autoTrack', 'الأصل أن تضيف المحاضرة بنفسك من زرّ «أضف إلى سجلّ الدراسة» تحت المقطع. ومحاضرات السلاسل المستوردة تُسجَّل وحدها.'),
          sw('تذكيري بموضع توقّفي عند فتح المقطع', 'remindResume'),
          sw('تذكيري بما كتبته في المقطع', 'remindNotes'),
          h('div.field', { style: { marginTop: '10px' } }, h('label', 'في الإضافة التلقائية: لا تسجّل المقاطع الأقصر من'),
            h('select.select', { onchange: (e) => save({ trackMinSeconds: Number(e.target.value) }) }, [[0, 'سجّل كل شيء'], [60, 'دقيقة'], [120, 'دقيقتين'], [300, '5 دقائق'], [600, '10 دقائق']].map(([v, l]) => h('option', { value: v, selected: App.settings.trackMinSeconds === v }, l))))),
        card('المقتبس في صفحة يوتيوب', 'أين تظهر أدوات المقتبس تحت المحاضرة.',
          h('div.seg.block', ['pill', 'bar'].map((k) => h('button' + ((App.settings.barMode || 'pill') === k ? '.on' : ''), { type: 'button', onclick: async () => { await save({ barMode: k }); App.refresh(); } }, k === 'pill' ? 'زرّ مختصر بجانب «أعجبني»' : 'شريط كامل تحت المقطع'))),
          h('div.hint', { style: { marginTop: '8px' } }, 'الزرّ المختصر يفتح لوحة فيها كل الأدوات، ولا يزاحم الإضافات الأخرى تحت المقطع. وفي وضع التركيز يظهر الشريط كاملًا دائمًا.')),
        card('الدفتر', null, sw('ختم وقت المقطع تلقائيًا في بداية كل فقرة', 'autoStamp')),
        card('التقويم', null, h('div.field', h('label', 'أول أيام الأسبوع'), h('select.select', { onchange: (e) => save({ weekStart: Number(e.target.value) }) },
          [[6, 'السبت'], [0, 'الأحد'], [1, 'الاثنين']].map(([v, l]) => h('option', { value: v, selected: (App.settings.weekStart ?? 6) === v }, l))))));
    },

    async home(body) {
      const list = h('div.mlist');
      const paint = () => list.replaceChildren(...(App.settings.motivation || []).map((m, i) => h('div.mrow', h('span', m.text), m.src ? h('small.muted', m.src) : null,
        h('button.btn.btn-icon.sm.btn-ghost', { type: 'button', title: 'حذف', onclick: async () => { const arr = [...App.settings.motivation]; arr.splice(i, 1); await save({ motivation: arr }, true); paint(); } }, icon('x')))),
        !(App.settings.motivation || []).length ? h('p.hint', 'لم تضف عبارات بعد — تظهر العبارات المختارة مع المقتبس.') : null);
      paint();
      const tx = h('input.input', { placeholder: 'العبارة' }), src = h('input.input', { placeholder: 'قائلها أو مصدرها (اختياري)' });
      body.append(
        card('عبارات الرئيسية', 'تتبدّل في الرئيسية عبارات في فضل العلم وطلبه. أضف عباراتك لتظهر معها.',
          list,
          h('div.grid2', { style: { marginTop: '10px' } }, tx, src),
          h('button.btn.btn-sm', { style: { marginTop: '8px' }, onclick: async () => { if (!tx.value.trim()) return; await save({ motivation: [...(App.settings.motivation || []), { text: tx.value.trim(), src: src.value.trim() }] }, true); tx.value = ''; src.value = ''; paint(); } }, icon('plus'), 'إضافة'),
          sw('إظهار عباراتي وحدها', 'motivationOnlyMine')),
        card('الجولة التعريفية', 'جولة قصيرة على أقسام المنصّة.', h('button.btn', { onclick: () => { App.go('#/home'); setTimeout(() => App.tour && App.tour(true), 400); } }, icon('play'), 'ابدأ الجولة')));
    },

    async updates(body) { await App.updateSection(body, card); },

    async about(body) {
      body.append(
        card('عن المقتبس', null,
          h('div', { style: { display: 'flex', gap: '16px', alignItems: 'center' } }, h('img', { src: '../assets/mark.svg', style: { width: '64px' } }),
            h('div', h('b', { style: { fontFamily: 'var(--font-title)', fontSize: '20px' } }, 'المقتبس ' + chrome.runtime.getManifest().version), h('div.hint', 'أداة تعين طلاب العلم وطلاب البرامج العلمية على الانتفاع بالمحاضرات: اقتباس، وتدوين، ومتابعة، ونشر.'),
              h('span.ptag.scheduled', { style: { marginTop: '6px', display: 'inline-block' } }, 'نسخة تجريبية')))),
        card('اقتراحاتك وملاحظاتك', 'نسخة تجريبية، وكل ملاحظة تحسّنها: خطأ لاحظته، أو ميزة تتمنّاها.',
          h('button.btn.btn-primary', { type: 'button', onclick: () => App.reportDialog() }, icon('feedback'), 'أبلغ عن مشكلة أو أرسل ملاحظة'),
          h('a.btn.btn-ghost', { href: 'https://ghamine23.github.io/almuqtabis/', target: '_blank', style: { marginInlineStart: '8px' } }, icon('link'), 'صفحة المقتبس')));
    },

    async logo(body) {
      const { customLogo } = await chrome.storage.local.get('customLogo');
      const prev = h('div', { style: { width: '120px', height: '90px', borderRadius: '12px', border: '1px solid var(--line)', display: 'grid', placeItems: 'center', background: 'repeating-conic-gradient(var(--line) 0 25%, transparent 0 50%) 50% / 14px 14px' } },
        customLogo ? h('img', { src: customLogo, style: { maxWidth: '86%', maxHeight: '80%' } }) : h('span.hint', 'لا شعار'));
      body.append(card('شعارك', 'يظهر خيارًا في الاستوديو ← الشعار. يُفضَّل ملف بخلفية شفافة.',
        h('div', { style: { display: 'flex', gap: '14px', alignItems: 'center' } }, prev,
          h('label.btn', icon('upload'), 'رفع شعار', h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml,image/jpeg', hidden: true, onchange: async (e) => {
            const f = e.target.files[0]; if (!f) return;
            if (f.size > 3 * 1024 * 1024) { App.toast('الحدّ 3 ميغابايت'); return; }
            const url = await new Promise((r) => { const fr = new FileReader(); fr.onload = () => r(fr.result); fr.readAsDataURL(f); });
            await chrome.storage.local.set({ customLogo: url }); App.toast('حُفظ الشعار'); App.refresh();
          } })),
          customLogo ? h('button.btn.btn-ghost.btn-danger', { onclick: async () => { await chrome.storage.local.remove('customLogo'); App.refresh(); } }, 'إزالة') : null)),
        card('شعار المقتبس', 'مشكاة فيها قبس: «لعلّي آتيكم منها بقبس».', h('div', { style: { display: 'flex', gap: '18px', alignItems: 'center' } },
          h('img', { src: '../assets/mark.svg', style: { width: '90px' } }), h('img', { src: '../icons/icon128.png', style: { width: '64px' } }),
          h('div', { style: { background: '#23261F', padding: '14px', borderRadius: '12px' } }, h('img', { src: '../assets/mark-white.svg', style: { width: '60px', display: 'block' } })))));
    },

    async data(body) {
      const est = await MQDB.estimate();
      const counts = await Promise.all(['quotes', 'clips', 'watch', 'notes', 'notebooks', 'posts'].map((s) => MQDB.count(s)));
      body.append(
        card('التخزين', null,
          h('div.svc',
            h('div', icon('quote'), `${counts[0]} مقتبس · ${counts[1]} ملف فيديو`),
            h('div', icon('book'), `${counts[4]} دفتر · ${counts[3]} تدوين`),
            h('div', icon('history'), `${counts[2]} مقطع في السجلّ · ${counts[5]} منشور`),
            est ? h('div', icon('layers'), `المستعمل في المتصفح: ${MQ.fmtSize(est.usage)}`) : null),
          h('div', { style: { display: 'flex', gap: '8px', marginTop: '14px', flexWrap: 'wrap' } },
            h('button.btn', { onclick: cleanup }, icon('trash'), 'حذف الملفات المحلية للمقتبسات المرفوعة إلى درايف'))),
        card('النسخ الاحتياطي', 'كل بياناتك عدا ملفات الفيديو: المقتبسات، الكناشة، السجلّ، المنشورات، القنوات، القوالب، والإعدادات.',
          h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap' } },
            h('button.btn.btn-primary', { onclick: exportAll }, icon('download'), 'تصدير نسخة احتياطية'),
            h('label.btn', icon('upload'), 'استيراد نسخة', h('input', { type: 'file', accept: 'application/json', hidden: true, onchange: (e) => importAll(e.target.files[0]) })))));
    },
  };

  // مكان الحفظ: مجلّد داخل التنزيلات (يُختار من القائمة) أو مجلّد من الجهاز
  async function saveCard() {
    const s = App.settings;
    const box = h('div');
    const paint = async () => {
      const cur = App.settings;
      // المجلّدات التي حفظ فيها المقتبس من قبل داخل التنزيلات
      let folders = [];
      try {
        const items = await chrome.downloads.search({ limit: 1000, orderBy: ['-startTime'] });
        const mine = items.filter((d) => d.byExtensionId === chrome.runtime.id && d.filename);
        const set = new Set();
        mine.forEach((d) => { const parts = d.filename.split(/[\\/]/); if (parts.length > 2) set.add(parts[parts.length - 2]); });
        folders = [...set];
      } catch (_) {}
      if (!folders.includes(cur.folder)) folders.unshift(cur.folder);
      const dir = await MQPub.saveDirHandle();
      let perm = 'none';
      if (dir) { try { perm = await dir.queryPermission({ mode: 'readwrite' }); } catch (_) { perm = 'prompt'; } }
      const pick = async () => {
        if (!window.showDirectoryPicker) { App.toast('متصفحك لا يدعم اختيار المجلّدات.'); return; }
        try {
          const handle = await window.showDirectoryPicker({ id: 'almuqtabis', mode: 'readwrite', startIn: 'downloads' });
          await MQDB.put('kv', { key: 'saveDir', value: handle });
          await MQDB.del('kv', 'saveDirNeedsGrant');
          App.settings = await MQ.saveSettings({ saveTarget: 'folder', folderLabel: handle.name });
          App.toast('اختير المجلّد: ' + handle.name); paint();
        } catch (e) { if (e.name !== 'AbortError') App.toast('تعذّر اختيار المجلّد: ' + e.message, 4500); }
      };
      box.replaceChildren(
        h('div.seg.block', { style: { marginBottom: '12px' } },
          h('button' + (cur.saveTarget !== 'folder' ? '.on' : ''), { type: 'button', onclick: async () => { App.settings = await MQ.saveSettings({ saveTarget: 'downloads' }); paint(); } }, 'مجلّد داخل التنزيلات'),
          h('button' + (cur.saveTarget === 'folder' ? '.on' : ''), { type: 'button', onclick: async () => { if (!dir) await pick(); else { App.settings = await MQ.saveSettings({ saveTarget: 'folder' }); paint(); } } }, 'مجلّد أختاره من جهازي')),
        cur.saveTarget !== 'folder'
          ? h('div.field', h('label', 'المجلّد'),
            h('div', { style: { display: 'flex', gap: '8px' } },
              h('select.select', { onchange: async (e) => { if (e.target.value === '__new') { const n = await App.prompt('اسم المجلّد الجديد داخل التنزيلات', ''); if (n) await save({ folder: MQ.safeFileName(n, 60) }); paint(); return; } await save({ folder: e.target.value }); } },
                folders.map((f) => h('option', { value: f, selected: f === cur.folder }, 'التنزيلات / ' + f)), h('option', { value: '__new' }, '＋ مجلّد جديد…'))),
            h('div.hint', 'المتصفح لا يسمح للإضافات بالحفظ خارج «التنزيلات» إلا بالخيار الثاني.'))
          : h('div',
            h('div.folderrow', icon('folder', 22), h('div', { style: { flex: 1, minWidth: 0 } }, h('b', cur.folderLabel || (dir && dir.name) || '—'),
              h('div.hint', perm === 'granted' ? 'الإذن قائم ✓ تُحفظ الملفات هنا مباشرة.' : 'يحتاج المتصفح إذنك من جديد بعد إعادة تشغيله — اضغط «منح الإذن»، واختر «السماح في كل زيارة» إن ظهر.')),
              perm !== 'granted' && dir ? h('button.btn.btn-sm.btn-primary', { type: 'button', onclick: async () => { try { const r = await dir.requestPermission({ mode: 'readwrite' }); if (r === 'granted') { await MQDB.del('kv', 'saveDirNeedsGrant'); App.toast('مُنح الإذن ✓'); } } catch (e) { App.toast(e.message); } paint(); } }, 'منح الإذن') : null,
              h('button.btn.btn-sm', { type: 'button', onclick: pick }, 'تغيير المجلّد')),
            h('div.note-info', { style: { marginTop: '10px' } }, icon('info'), h('span', 'إن تعذّر الحفظ في مجلّدك (لغياب الإذن) حُفظ الملف في «التنزيلات / ' + cur.folder + '» حتى لا يضيع، ونبّهتك المنصّة لتمنح الإذن.'))));
    };
    await paint();
    return card('مكان الحفظ على جهازك', 'حيث تُحفظ نسخ المقتبسات وأغلفتها والنسخ الاحتياطية.', box);
  }

  async function cleanup() {
    const quotes = await MQDB.all('quotes');
    const up = quotes.filter((q) => q.drive && q.drive.fileId);
    if (!up.length) { App.toast('لا مقتبسات مرفوعة إلى درايف'); return; }
    if (!(await App.confirm(`حذف ملفات الفيديو المحلية لـ ${up.length} مقتبس مرفوع إلى درايف؟\nتبقى بياناتها وروابطها، ويتعذّر تحريرها في الاستوديو حتى تعيد إرفاق الملف.`, 'حذف الملفات', true))) return;
    let freed = 0;
    for (const q of up) for (const c of await MQDB.byIndex('clips', 'quoteId', q.id)) { if (c.kind === 'cover') continue; freed += c.blob.size; await MQDB.del('clips', c.id); }
    for (const q of up) await MQDB.patch('quotes', q.id, { sourceClipId: null, finalClipId: null });
    App.toast('حُرّر ' + MQ.fmtSize(freed)); App.refresh();
  }
  async function exportAll() {
    const stores = ['quotes', 'watch', 'notebooks', 'notes', 'posts', 'transcripts'];
    const data = { app: 'almuqtabis', version: 2, exportedAt: new Date().toISOString() };
    for (const s of stores) data[s] = await MQDB.all(s);
    const local = await chrome.storage.local.get(null);
    data.storage = { ...local };
    const blob = new Blob([JSON.stringify(data)], { type: 'application/json' });
    const d = new Date().toISOString().slice(0, 10);
    const r = await MQPub.saveFile(blob, `نسخة المقتبس الاحتياطية ${d}.json`);
    App.toast('صُدّرت النسخة الاحتياطية إلى ' + r.filename);
  }
  async function importAll(file) {
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (data.app !== 'almuqtabis') throw new Error();
      if (!(await App.confirm('استيراد النسخة؟ يُضاف ما فيها إلى بياناتك الحالية، ولا يُحذف شيء.', 'استيراد'))) return;
      for (const s of ['quotes', 'watch', 'notebooks', 'notes', 'posts', 'transcripts']) if (Array.isArray(data[s])) await MQDB.putMany(s, data[s]);
      if (Array.isArray(data.quotes) && data.version === 1) await MQDB.putMany('quotes', data.quotes);
      if (data.storage) {
        const keep = await chrome.storage.local.get(null);
        const merged = { ...data.storage, ...keep };
        ['categories', 'noteTags'].forEach((k) => { merged[k] = [...new Set([...(data.storage[k] || []), ...(keep[k] || [])])]; });
        await chrome.storage.local.set(merged);
      }
      App.toast('استُوردت النسخة ✓'); App.refresh();
    } catch (_) { App.toast('الملف ليس نسخة من المقتبس'); }
  }

  // ---------------- معالج ربط جوجل ----------------
  async function wizard(body, isUpdate) {
    let s = App.settings;
    let key = s.cloud.key;
    if (!key) {
      key = [...crypto.getRandomValues(new Uint8Array(20))].map((b) => b.toString(16).padStart(2, '0')).join('');
      s = await save({ cloud: { ...s.cloud, key } }, true);
    }
    const code = (await (await fetch('../backend/Code.gs')).text()).replace('__MQ_SECRET__', key);
    const url = h('input.input.ltr', { value: s.cloud.url || '', placeholder: 'https://script.google.com/macros/s/…/exec' });
    const st = h('div.status');
    const copyBtn = h('button.btn.btn-primary', { onclick: () => App.copy(code, 'نُسخ الكود — الصقه في المحرّر') }, icon('copy'), 'نسخ الكود');
    body.appendChild(card(isUpdate ? 'تحديث الربط' : 'خطوات الربط (مرة واحدة)', 'تأخذ نحو خمس دقائق.',
      h('div.steps',
        h('div.step', h('div', h('b', 'افتح مشروع سكربت جديدًا في حسابك'), h('div.hint', 'سيفتح محرّر السكربتات من جوجل في تبويب جديد.'),
          h('a.btn.btn-sm', { href: 'https://script.google.com/home/projects/create', target: '_blank' }, icon('link'), 'فتح المحرّر'))),
        h('div.step', h('div', h('b', 'انسخ كود المقتبس والصقه مكان كل ما في المحرّر'), h('div.hint', 'الكود يحمل مفتاحًا سرّيًّا خاصًّا بك، فلا تشاركه.'), copyBtn)),
        h('div.step', h('div', h('b', 'شغّل دالة الإعداد مرة واحدة'), h('div.hint', 'اختر من القائمة أعلى المحرّر الدالة باسم:'), h('div.code-line', 'setup'),
          h('div.hint', 'ثم اضغط «تشغيل»، ووافق على الأذونات (درايف، المستندات، الاتصال بالتليجرام). إن ظهر تحذير «التطبيق غير موثّق» فاختر «متقدّم» ثم «الانتقال إلى المشروع»، لأنه سكربتك أنت.'))),
        h('div.step', h('div', h('b', 'انشره تطبيقَ ويب'), h('div.hint', 'من زرّ «نشر» ← «نشر جديد» ← اختر النوع «تطبيق ويب»، واجعل التنفيذ باسمك، والوصول لـ «أي شخص». ثم انسخ رابط تطبيق الويب.'))),
        h('div.step', h('div', h('b', 'الصق الرابط واربط'), url,
          h('div', { style: { display: 'flex', gap: '8px', marginTop: '8px', alignItems: 'center' } },
            h('button.btn.btn-primary', { onclick: async (e) => {
              const u = url.value.trim();
              if (!/^https:\/\/script\.google\.com\/macros\/s\/.+\/exec$/.test(u)) { st.textContent = 'الرابط يجب أن يبدأ بـ script.google.com/macros/s/ وينتهي بـ exec'; st.className = 'status err'; return; }
              e.target.disabled = true; st.textContent = 'جارٍ الاختبار…'; st.className = 'status';
              try {
                const r = await MQCloud.call('ping', {}, { cloud: { url: u, key } });
                await save({ cloud: { url: u, key, email: r.email || '', linkedAt: Date.now(), rootUrl: r.rootUrl || '' } }, true);
                if (!r.trigger) App.toast('رُبط، لكن الجدولة غير مفعّلة: شغّل الدالة setup في المحرّر', 6000); else App.toast('رُبط حساب جوجل ✓');
                App.refresh();
              } catch (er) { st.textContent = er.message; st.className = 'status err'; }
              e.target.disabled = false;
            } }, icon('check'), 'اختبار واربط'), st)))),
      h('details', h('summary', { style: { cursor: 'pointer', color: 'var(--accent)', fontSize: '13.5px', marginTop: '6px' } }, 'عرض الكود'), h('div.code-line', { style: { maxHeight: '260px', overflow: 'auto', whiteSpace: 'pre' } }, code))));
  }

  // ---------------- الترحيب ----------------
  App.views.welcome = {
    title: 'مرحبًا',
    async render(page) {
      const s = App.settings;
      const items = [
        ['scissors', 'الاقتباس', `زرّ في مشغّل يوتيوب، أو ${MQ.shortcutLabel(s.shortcut)}: عدّ تنازلي، تسجيل، ثم قصّ واختيار القناة.`],
        ['wand', 'الاستوديو', 'قصّ بالنص، ترجمة على المقطع، ريلز ومربّع، ألوان، صوت، شعار، وغلاف.'],
        ['calendar', 'النشر', 'قنوات متعدّدة بقوالبها، وتقويم تسحب إليه المقتبسات، وخطة نشر تلقائية.'],
        ['book', 'الكناشة', 'دفتر بجانب المحاضرة يختم كل فقرة بوقتها، ودفاتر تُحفظ في درايف مستندات مرتّبة.'],
        ['history', 'سجلّ الإنجاز', 'ما شاهدته وأين توقّفت، بالسلاسل والمتحدّثين، مع تذكير عند العودة.'],
        ['focus', 'وضع التركيز', 'يخفي كل شيء إلا المحاضرة والدفتر وسؤال الإتمام.'],
      ];
      page.appendChild(h('div.welcome',
        h('img.mark.rise', { src: '../assets/mark.svg', alt: '' }),
        h('h1.rise', { style: { '--i': 1 } }, 'المقتبس'),
        h('p.rise', { style: { '--i': 2 } }, 'رفيقك في طلب العلم من المحاضرات: تقتبس، وتدوّن، وتنشر، وتتابع إنجازك.'),
        h('div.wgrid', items.map(([ic, t, d], i) => h('div.wcard.rise', { style: { '--i': i + 3 } }, icon(ic), h('h3', t), h('p', d)))),
        h('div', { style: { display: 'flex', gap: '10px', justifyContent: 'center', flexWrap: 'wrap' } },
          h('a.btn.btn-primary.btn-lg', { href: 'https://www.youtube.com', target: '_blank' }, 'افتح محاضرة في يوتيوب'),
          h('a.btn.btn-lg', { href: '#/settings/telegram' }, 'اضبط التليجرام'),
          h('a.btn.btn-lg.btn-ghost', { href: '#/settings/google' }, 'اربط حساب جوجل'))));
    },
  };
})();
