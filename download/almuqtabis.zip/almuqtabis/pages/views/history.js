// المقتبس — سجلّ الإنجاز: ما أضفتَه إلى سجلّ دراستك، وأين توقّفت، وما أتممته، مرتّبًا بالأيام والسلاسل والمتحدّثين.
(() => {
  const { h, icon } = MQ;
  const TABS = [['progress', 'clock', 'قيد الدراسة'], ['done', 'check', 'المكتملة'], ['series', 'series', 'السلاسل'], ['speakers', 'user', 'المتحدّثون'], ['all', 'grid', 'الكل']];

  App.pctOf = (w) => {
    if (!w) return 0;
    if (w.completed) return 100;
    return w.duration ? Math.min(100, Math.round(((w.maxPosition || w.position || 0) / w.duration) * 100)) : 0;
  };

  App.views.history = {
    title: 'سجلّ الإنجاز',
    async render(page, parts, query) {
      const tab = TABS.some((t) => t[0] === parts[0]) ? parts[0] : 'progress';
      const [all0, notes0, seriesList] = await Promise.all([MQDB.all('watch'), MQDB.all('notes'), MQDB.all('series')]);
      const all = all0.sort((a, b) => b.lastAt - a.lastAt);
      const notesBy = new Map(); notes0.filter((n) => !n.trashed).forEach((n) => { if (n.videoId) notesBy.set(n.videoId, (notesBy.get(n.videoId) || 0) + 1); });

      const switcher = App.switcher(TABS, tab, (id) => App.go('#/history/' + id));
      const importBtn = h('button.btn.btn-soft', { type: 'button', onclick: () => importDialog() }, icon('playlist'), 'استورد سلسلة');
      page.appendChild(App.header('سجلّ الإنجاز', 'ما أضفته إلى سجلّ دراستك: أين توقّفت، وما أتممته، وتقدّمك في كل سلسلة.', [importBtn, switcher]));

      if (!all.length && !seriesList.length) {
        page.appendChild(App.empty('سجلّ الدراسة فارغ',
          App.settings.autoTrack ? 'افتح أي محاضرة في يوتيوب، وتُضاف إلى السجلّ تلقائيًّا.' : 'افتح محاضرة في يوتيوب، واضغط «أضف إلى سجلّ الدراسة» في الشريط تحت المقطع — أو استورد سلسلة كاملة من رابط قائمة التشغيل.',
          h('div', { style: { display: 'flex', gap: '8px', justifyContent: 'center', flexWrap: 'wrap' } },
            h('button.btn.btn-primary', { type: 'button', onclick: () => importDialog() }, icon('playlist'), 'استورد سلسلة'),
            h('a.btn', { href: 'https://www.youtube.com', target: '_blank' }, 'افتح يوتيوب'))));
        return;
      }
      page.appendChild(statsBlock(all));

      const seriesId = query.get('s'), speaker = query.get('p');
      if (tab === 'series' && seriesId) return seriesPage(page, seriesId, all, seriesList, notesBy);
      if (tab === 'series') return seriesGrid(page, all, seriesList);
      if (tab === 'speakers' && !speaker) return speakerGrid(page, all);

      let list = all;
      let label = '';
      if (tab === 'progress') list = all.filter((w) => !w.completed);
      if (tab === 'done') list = all.filter((w) => w.completed).sort((a, b) => (b.completedAt || b.lastAt) - (a.completedAt || a.lastAt));
      if (speaker) { list = all.filter((w) => (w.speaker || w.channel || 'بلا اسم') === speaker); label = 'المتحدّث: ' + speaker; }
      if (label) page.appendChild(h('div.filterbar', icon('user', 17), h('b', label), h('a.btn.btn-sm.btn-ghost', { href: '#/history/' + tab, style: { marginInlineStart: 'auto' } }, 'رجوع')));
      const search = h('input.input', { placeholder: 'ابحث في السجلّ…' });
      const box = h('div.daylist');
      page.append(h('div.toolbar', h('div.searchbox', icon('search'), search)), box);
      const paint = () => {
        const s = search.value.trim();
        const shown = list.filter((w) => !s || [w.title, w.series, w.speaker, w.channel].join(' ').includes(s));
        if (!shown.length) { box.replaceChildren(h('p.hint', tab === 'progress' ? 'لا محاضرات قيد الدراسة. أضف محاضرة من شريط المقتبس تحت أي مقطع في يوتيوب.' : 'لا عناصر هنا.')); return; }
        const timeOf = (w) => tab === 'done' ? (w.completedAt || w.lastAt) : w.lastAt;
        box.replaceChildren(...App.groupByDay(shown, timeOf, (w, i) => row(w, i, notesBy.get(w.videoId) || 0)));
      };
      search.addEventListener('input', MQ.debounce(paint, 150));
      paint();
    },
  };

  // مبدّل العروض بحبّة منزلقة — يُستعمل في أكثر من واجهة
  App.switcher = (items, cur, onPick) => {
    const pill = h('span.pill');
    const wrap = h('div.views', pill, items.map(([id, ic, l]) => h('button' + (id === cur ? '.on' : ''), { type: 'button', dataset: { v: id }, onclick: () => onPick(id) }, icon(ic), l)));
    requestAnimationFrame(() => { const b = wrap.querySelector('button.on'); if (b) { pill.style.left = '0px'; pill.style.width = b.offsetWidth + 'px'; pill.style.transform = `translateX(${b.offsetLeft}px)`; } });
    return wrap;
  };

  // تجميع بالأيام: اليوم، أمس، قبل أمس، ثم التواريخ
  App.groupByDay = (list, timeOf, render) => {
    const groups = new Map();
    list.forEach((x) => { const k = MQ.dayKey(timeOf(x)); if (!groups.has(k)) groups.set(k, { t: timeOf(x), items: [] }); groups.get(k).items.push(x); });
    let i = 0;
    return [...groups.values()].map((g) => h('section.dayg',
      h('div.dayh', h('span', MQ.dayLabel(g.t)), h('small', g.items.length > 1 ? `${g.items.length}` : '')),
      h('div.row-list', g.items.map((x) => render(x, i++)))));
  };

  function statsBlock(all) {
    const days = new Map();
    all.forEach((w) => Object.entries(w.days || {}).forEach(([d, s]) => days.set(d, (days.get(d) || 0) + s)));
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const last14 = [...Array(14)].map((_, i) => { const d = new Date(today); d.setDate(d.getDate() - (13 - i)); return { d, s: days.get(MQ.dayKey(d)) || 0 }; });
    const week = last14.slice(7).reduce((a, x) => a + x.s, 0);
    let streak = 0;
    for (let i = 13; i >= 0; i--) { if (last14[i].s >= 60) streak++; else if (i !== 13) break; }
    const max = Math.max(60, ...last14.map((x) => x.s));
    const chart = h('div.chart', last14.map((x, i) => h('div.b' + (i === 13 ? '.today' : ''), { title: `${MQ.dayLabel(x.d.getTime())}: ${MQ.fmtDur(x.s)}` },
      h('i', { style: { height: '0%' } }), h('span', x.d.toLocaleDateString('ar', { weekday: 'narrow' })))));
    requestAnimationFrame(() => chart.querySelectorAll('i').forEach((el, i) => { el.style.height = Math.max(last14[i].s ? 4 : 0, Math.round((last14[i].s / max) * 100)) + '%'; }));
    const done = all.filter((w) => w.completed).length;
    return h('div.hstats',
      h('div.card.hchart', h('div.hchart-t', h('span', 'المشاهدة في أسبوعين'), h('a', { href: '#/stats' }, 'كل الإحصاءات')), chart),
      h('div.hgrid',
        stat(MQ.fmtDur(week), 'هذا الأسبوع', true), stat(String(done), 'محاضرة أتممتها'),
        stat(String(all.filter((w) => !w.completed).length), 'قيد الدراسة'), stat(streak ? (streak >= 3 && streak <= 10 ? `${streak} أيام` : `${streak} يومًا`) : '—', 'أيام متتالية')));
  }
  const stat = (n, l, accent) => h('div.stat' + (accent ? '.accent' : ''), h('b', n), h('span', l));

  App.progressBar = (pct, opts = {}) => h('div.pbar' + (opts.sm ? '.sm' : '') + (pct >= 100 ? '.full' : ''),
    h('div.pbar-track', h('div.pbar-fill', { style: { width: '0%' }, dataset: { w: pct } })),
    opts.label === false ? null : h('span.pbar-l', pct >= 100 ? 'مكتمل' : pct + '٪'));
  // تحريك أشرطة التقدّم عند ظهورها
  new MutationObserver(() => requestAnimationFrame(() => document.querySelectorAll('.pbar-fill[data-w]').forEach((el) => { el.style.width = el.dataset.w + '%'; el.removeAttribute('data-w'); })))
    .observe(document.documentElement, { childList: true, subtree: true });

  function row(w, i, notesN) {
    const pct = App.pctOf(w);
    const more = h('button.btn.btn-icon.sm.btn-ghost', { title: 'المزيد' }, icon('more'));
    more.onclick = () => App.menu(more, [
      { icon: 'edit', label: 'تعديل المحاضر والسلسلة', onClick: () => editDialog(w) },
      notesN ? { icon: 'book', label: 'تدويناتي فيه', onClick: () => App.go('#/kanasha?video=' + w.videoId) } : null,
      { icon: 'quote', label: 'مقتبساتي منه', onClick: () => App.go('#/quotes?view=all&video=' + w.videoId) },
      'hr',
      { icon: 'trash', label: 'إزالته من سجلّ الدراسة', danger: true, onClick: async () => { await chrome.runtime.sendMessage({ type: 'watch:ignore', videoId: w.videoId }); App.toast('أُزيل من السجلّ'); App.refresh(); } },
    ]);
    const doneBtn = h('button.btn.btn-sm' + (w.completed ? '.btn-soft' : ''), { title: w.completed ? 'إلغاء الإتمام' : 'تعليم كمكتمل', onclick: async () => {
      await chrome.runtime.sendMessage({ type: 'watch:complete', videoId: w.videoId, done: !w.completed });
      App.toast(w.completed ? 'أُلغي الإتمام' : 'سُجّل في إنجازك ✓'); App.refresh();
    } }, icon('check'), w.completed ? 'مكتمل' : 'أتممته');
    return h('div.lrow.hrow.rise' + (w.completed ? '.done' : ''), { style: { '--i': Math.min(i, 20) } },
      h('a.th', { href: MQ.watchLink(w.videoId, w.completed ? 0 : w.position), target: '_blank' }, h('img', { src: MQ.thumbUrl(w.videoId), alt: '', loading: 'lazy' }), w.duration ? h('span.dur', MQ.fmtTime(w.duration)) : null),
      h('div.bd',
        h('div.tt', w.title || 'مقطع'),
        h('div.sb',
          h('span', w.speaker || w.channel || ''),
          w.series ? h('span', '· ' + w.series) : null,
          h('span', '· ' + MQ.fmtClock(w.completed ? (w.completedAt || w.lastAt) : w.lastAt)),
          w.watchedSec ? h('span', '· شاهدت ' + MQ.fmtDur(w.watchedSec)) : null,
          notesN ? h('span', { style: { color: 'var(--copper)' } }, `· ${notesN} تدوين`) : null),
        h('div.hprog', App.progressBar(pct), !w.completed && w.position > 30 ? h('span.hint', `توقّفتَ عند ${MQ.fmtTime(w.position)}${w.duration ? ' من ' + MQ.fmtTime(w.duration) : ''}`) : null)),
      h('div.ac',
        !w.completed ? h('a.btn.btn-sm.btn-primary', { href: MQ.watchLink(w.videoId, w.position), target: '_blank' }, icon('play'), 'متابعة') : null,
        doneBtn, more));
  }

  function editDialog(w) {
    const sp = h('input.input', { value: w.speaker || '' });
    const se = h('input.input', { value: w.series || '' });
    App.dialog({ title: 'تعديل', body: h('div', h('div.field', h('label', 'المحاضر'), sp), h('div.field', h('label', 'السلسلة'), se), h('p.hint', 'يُحفظ تعديلك ولا يُستبدل بما يقرؤه المقتبس من يوتيوب لاحقًا.')),
      actions: [{ label: 'حفظ', primary: true, onClick: async () => { await MQDB.patch('watch', w.videoId, { speaker: sp.value.trim(), series: se.value.trim(), speakerEdited: true, seriesEdited: true }); App.refresh(); } }, { label: 'إلغاء', ghost: true }] });
  }

  // ---------- السلاسل ----------
  // تجمع السلاسل المستوردة والسلاسل المعروفة من قوائم التشغيل أثناء المشاهدة، وترتّبها بآخر نشاط
  App.allSeries = (all, seriesList) => {
    const out = new Map();
    seriesList.forEach((s) => out.set(s.id, { id: s.id, title: s.title, channel: s.channel, imported: true, items: s.items || [], rec: s }));
    all.forEach((w) => {
      const id = w.playlistId || (w.series ? 'n:' + w.series : '');
      if (!id) return;
      if (!out.has(id)) {
        const imp = [...out.values()].find((x) => x.imported && x.items.some((it) => it.videoId === w.videoId));
        if (imp) return;
        out.set(id, { id, title: w.series || 'سلسلة', channel: w.speaker || w.channel || '', imported: false, items: [] });
      }
    });
    const byVid = new Map(all.map((w) => [w.videoId, w]));
    return [...out.values()].map((s) => {
      const members = s.imported ? s.items.map((it) => ({ ...it, w: byVid.get(it.videoId) })) :
        all.filter((w) => (w.playlistId || (w.series ? 'n:' + w.series : '')) === s.id).sort((a, b) => a.firstAt - b.firstAt).map((w, i) => ({ videoId: w.videoId, title: w.title, duration: w.duration, index: i + 1, w }));
      const watched = members.filter((m) => m.w);
      const done = members.filter((m) => m.w && m.w.completed).length;
      const lastAt = Math.max(0, ...watched.map((m) => m.w.lastAt), s.rec ? (s.rec.importedAt || 0) : 0);
      const totalDur = members.reduce((a, m) => a + (m.duration || (m.w && m.w.duration) || 0), 0);
      const pctSum = members.length ? Math.round(members.reduce((a, m) => a + App.pctOf(m.w), 0) / members.length) : 0;
      const next = members.find((m) => !(m.w && m.w.completed));
      return { ...s, members, done, started: watched.length, lastAt, totalDur, pct: pctSum, next };
    }).sort((a, b) => b.lastAt - a.lastAt);
  };

  function seriesGrid(page, all, seriesList) {
    const list = App.allSeries(all, seriesList);
    if (!list.length) {
      page.appendChild(h('div.note-info', icon('info'), h('span', 'استورد سلسلة من رابط قائمة التشغيل، أو من الشريط تحت أي محاضرة فيها قائمة تشغيل. وتُعرف السلسلة أيضًا من قائمة التشغيل حين تشاهد منها.')));
      return;
    }
    page.appendChild(h('div.series-grid', list.map((s, i) => {
      const thumbs = s.members.slice(0, 3);
      const stack = h('div.stack', thumbs.map((m, k) => h('img', { src: MQ.thumbUrl(m.videoId), alt: '', loading: 'lazy', style: { right: (24 + k * 46) + 'px', zIndex: 3 - k, transform: `rotate(${(k - 1) * 3}deg)` } })));
      return h('div.sercard.rise', { style: { '--i': i }, onclick: () => App.go('#/history/series?s=' + encodeURIComponent(s.id)) },
        stack,
        s.imported ? h('span.ser-imp', icon('playlist', 13), 'مستوردة') : null,
        h('div.bd', h('h3', s.title),
          h('div.hint', [s.channel, `${s.members.length} محاضرة`, s.totalDur ? MQ.fmtDur(s.totalDur) : ''].filter(Boolean).join(' · ')),
          h('div.ser-prog', h('b', `${s.done} من ${s.members.length}`), h('span', 'أتممتها')),
          App.progressBar(s.pct, { sm: true }),
          s.lastAt ? h('div.hint', { style: { marginTop: '6px' } }, 'آخر نشاط: ' + MQ.dayLabel(s.lastAt)) : null));
    })));
  }

  function seriesPage(page, id, all, seriesList, notesBy) {
    const s = App.allSeries(all, seriesList).find((x) => x.id === id);
    if (!s) { page.appendChild(h('p.hint', 'لم أجد هذه السلسلة.')); return; }
    const isList = !id.startsWith('n:');
    const watchUrl = (m, t) => MQ.watchLink(m.videoId, t) + (isList ? '&list=' + encodeURIComponent(id) : '');
    const more = h('button.btn.btn-icon.btn-ghost', { title: 'المزيد' }, icon('more'));
    more.onclick = () => App.menu(more, [
      s.imported ? { icon: 'edit', label: 'إعادة تسمية السلسلة', onClick: async () => { const v = await App.prompt('اسم السلسلة', s.title); if (v) { await MQDB.patch('series', id, { title: v, titleEdited: true }); App.refresh(); } } } : null,
      isList ? { icon: 'refresh', label: s.imported ? 'تحديث من يوتيوب' : 'استيرادها كاملة من يوتيوب', onClick: async () => { App.toast('جارٍ الاستيراد…'); const r = await chrome.runtime.sendMessage({ type: 'series:import', listId: id }); if (r && r.error) App.toast(r.error, 4500); else { App.toast('تمّ ✓'); App.refresh(); } } } : null,
      isList ? { icon: 'playlist', label: 'فتح القائمة في يوتيوب', href: 'https://www.youtube.com/playlist?list=' + encodeURIComponent(id) } : null,
      s.imported ? 'hr' : null,
      s.imported ? { icon: 'trash', label: 'حذف السلسلة المستوردة', danger: true, onClick: async () => { if (!(await App.confirm('حذف السلسلة من السجلّ؟ تبقى المحاضرات التي شاهدتها.', 'حذف', true))) return; await MQDB.del('series', id); App.go('#/history/series'); } } : null,
    ]);
    const ring = h('div.bigring', { style: { '--p': s.pct } }, h('b', s.pct + '٪'), h('span', 'التقدّم'));
    page.appendChild(h('div.serhead.card.rise',
      ring,
      h('div.serhead-b',
        h('div.crumb', h('a', { href: '#/history/series' }, 'السلاسل')),
        h('h2', s.title),
        h('div.hint', [s.channel, `${s.members.length} محاضرة`, s.totalDur ? 'مجموعها ' + MQ.fmtDur(s.totalDur) : ''].filter(Boolean).join(' · ')),
        h('div.serstats', h('span', h('b', s.done), ' أتممتها'), h('span', h('b', s.started - s.done), ' بدأتها'), h('span', h('b', s.members.length - s.started), ' لم تبدأ'))),
      h('div.serhead-a',
        s.next ? h('a.btn.btn-primary', { href: watchUrl(s.next, s.next.w && !s.next.w.completed ? s.next.w.position : 0), target: '_blank' }, icon('play'), s.next.w ? 'تابع السلسلة' : 'ابدأ التالية') : h('span.ptag.sent', 'أتممت السلسلة 🎉'),
        more)));
    const list = h('div.serlist');
    s.members.forEach((m, i) => {
      const w = m.w; const pct = App.pctOf(w);
      const st = !w ? 'none' : w.completed ? 'done' : 'prog';
      const isNext = s.next && s.next.videoId === m.videoId;
      const nN = notesBy.get(m.videoId) || 0;
      list.appendChild(h('div.serrow.rise.' + st + (isNext ? '.next' : ''), { style: { '--i': Math.min(i, 24) } },
        h('span.sernum', st === 'done' ? icon('check', 15) : String(m.index || i + 1)),
        h('a.th', { href: watchUrl(m, w && !w.completed ? w.position : 0), target: '_blank' }, h('img', { src: MQ.thumbUrl(m.videoId), alt: '', loading: 'lazy' })),
        h('div.bd',
          h('div.tt', m.title || (w && w.title) || 'محاضرة'),
          h('div.sb', (m.duration || (w && w.duration)) ? h('span', MQ.fmtTime(m.duration || w.duration)) : null,
            w && w.lastAt ? h('span', '· ' + MQ.dayLabel(w.lastAt)) : null, nN ? h('span', { style: { color: 'var(--copper)' } }, `· ${nN} تدوين`) : null,
            isNext ? h('span.nexttag', 'التالية') : null),
          w ? App.progressBar(pct, { sm: true }) : null),
        h('div.ac',
          w ? h('button.btn.btn-sm' + (w.completed ? '.btn-soft' : '.btn-ghost'), { onclick: async () => {
            await chrome.runtime.sendMessage({ type: 'watch:complete', videoId: m.videoId, done: !w.completed }); App.refresh();
          } }, icon('check'), w.completed ? 'مكتمل' : 'أتممته')
            : h('button.btn.btn-sm.btn-ghost', { title: 'علّمها مكتملة إن كنت شاهدتها من قبل', onclick: async () => {
              await chrome.runtime.sendMessage({ type: 'watch:add', data: { videoId: m.videoId, title: m.title, duration: m.duration, playlistId: isList ? id : '', playlistTitle: s.title, channel: s.channel } });
              await chrome.runtime.sendMessage({ type: 'watch:complete', videoId: m.videoId, done: true }); App.refresh();
            } }, icon('check'), 'شاهدتها'))));
    });
    page.appendChild(list);
  }

  function speakerGrid(page, all) {
    const map = new Map();
    all.forEach((w) => { const k = w.speaker || w.channel || 'بلا اسم'; if (!map.has(k)) map.set(k, []); map.get(k).push(w); });
    MQ.getSpeakerMeta().then((meta) => {
      page.appendChild(h('div.sgrid', [...map.entries()].sort((a, b) => b[1].length - a[1].length).map(([name, list], i) => {
        const img = (meta[name] && meta[name].avatar) || (list.find((w) => w.avatar) || {}).avatar;
        const done = list.filter((w) => w.completed).length;
        const secs = list.reduce((a, w) => a + (w.watchedSec || 0), 0);
        return h('div.scard.rise', { style: { '--i': i }, onclick: () => App.go('#/history/speakers?p=' + encodeURIComponent(name)) },
          App.avatar(name, img), h('h3', name), h('div.n', `${list.length} محاضرة · أتممت ${done} · ${MQ.fmtDur(secs)}`),
          h('div.strip', list.slice(0, 3).map((w) => h('img', { src: MQ.thumbUrl(w.videoId), alt: '', loading: 'lazy' }))));
      })));
    });
  }

  // ---------- استيراد سلسلة من رابط ----------
  function importDialog() {
    const inp = h('input.input', { placeholder: 'https://www.youtube.com/playlist?list=…', style: { direction: 'ltr' } });
    const msg = h('div');
    App.dialog({
      title: 'استيراد سلسلة',
      body: h('div', h('p', { style: { marginTop: 0 } }, 'الصق رابط قائمة التشغيل في يوتيوب (أو رابط أي محاضرة منها)، فتدخل محاضراتها كلها سجلّ دراستك سلسلةً واحدة، وترى تقدّمك فيها.'), inp, msg),
      actions: [{ label: 'استيراد', primary: true, icon: 'playlist', onClick: async (dlg, btn) => {
        const raw = inp.value.trim();
        let list = '';
        try { list = new URL(raw).searchParams.get('list') || ''; } catch (_) { if (/^[\w-]{12,}$/.test(raw)) list = raw; }
        if (!list) throw new Error('لم أجد معرّف قائمة التشغيل في الرابط (يبدأ بـ list=).');
        btn.textContent = 'جارٍ الاستيراد…';
        const r = await chrome.runtime.sendMessage({ type: 'series:import', listId: list });
        if (!r || r.error) throw new Error((r && r.error) || 'تعذّر الاستيراد.');
        App.toast(`استُوردت «${r.title}» — ${r.items.length} محاضرة ✓`, 3500);
        App.go('#/history/series?s=' + encodeURIComponent(list));
      } }, { label: 'إلغاء', ghost: true }],
    });
    setTimeout(() => inp.focus(), 40);
  }
  App.importSeriesDialog = importDialog;
})();
