// المقتبس — إدارة النشر: نظرة عامة، تقويم شهري وأسبوعي، طابور بتحكّم جماعي، القنوات بمواعيدها، القوالب، وخطة النشر.
(() => {
  const { h, icon } = MQ;
  const TABS = [['calendar', 'calendar', 'التقويم'], ['queue', 'series', 'الطابور'], ['channels', 'send', 'القنوات'], ['templates', 'text', 'القوالب']];
  const DOW = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const HOUR0 = 6, HOUR1 = 24, ROW = 44; // نطاق الساعات في العرض الأسبوعي

  App.views.publish = {
    title: 'النشر',
    wide: true,
    async render(page, parts) {
      const tab = parts[0] === 'plan' ? 'calendar' : TABS.some((t) => t[0] === parts[0]) ? parts[0] : 'calendar';
      const switcher = App.switcher(TABS, tab, (id) => App.go('#/publish/' + id));
      const planBtn = h('button.btn.btn-primary', { type: 'button', onclick: () => planWizard(() => App.refresh()) }, icon('sparkle'), 'خطة نشر');
      page.appendChild(App.header('إدارة النشر', 'قنواتك وقوالبها، ومواعيدك على التقويم.', [planBtn, switcher]));
      await overview(page);
      if (tab === 'calendar') await calendar(page);
      if (tab === 'queue') await queue(page);
      if (tab === 'channels') await channels(page);
      if (tab === 'templates') await templates(page);
      if (parts[0] === 'plan') planWizard(() => App.refresh());
    },
  };

  async function refreshFromCloud(silent) {
    if (!App.linked()) return;
    try { await MQSync.refreshQueue(App.settings.cloud); if (!silent) App.toast('حُدّثت حالة المنشورات'); }
    catch (e) { if (!silent) App.toast(e.message, 4000); }
  }

  // ================= الشريط العلوي: أرقام سريعة =================
  async function overview(page) {
    const [posts, quotes] = await Promise.all([MQDB.all('posts'), MQDB.all('quotes')]);
    const sched = posts.filter((p) => p.status === 'scheduled').sort((a, b) => a.at - b.at);
    const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
    const sentMonth = posts.filter((p) => p.status === 'sent' && (p.sentAt || p.at) >= monthStart.getTime()).length;
    const failed = posts.filter((p) => p.status === 'failed').length;
    const used = new Set(posts.map((p) => p.quoteId));
    const ready = quotes.filter((q) => !used.has(q.id)).length;
    const next = sched[0];
    const q = next && quotes.find((x) => x.id === next.quoteId);
    const cd = h('b');
    const tick = () => { if (!next) return; const d = next.at - Date.now(); cd.textContent = d <= 0 ? 'الآن' : d < 3600e3 ? `بعد ${Math.ceil(d / 60e3)} دقيقة` : d < 86400e3 ? `بعد ${Math.floor(d / 3600e3)} س ${Math.round((d % 3600e3) / 60e3)} د` : MQ.dayLabel(next.at) + ' ' + MQ.fmtClock(next.at); };
    tick(); const t = setInterval(tick, 30000); App.onCleanup(() => clearInterval(t));
    page.appendChild(h('div.pubstrip',
      h('div.ps-next', next ? [h('img', { src: App.thumbOf(q || {}), alt: '' }), h('div', h('span', 'المنشور القادم'), cd, h('small', (q && q.title) || '', ' · ', next.channelName))] : h('div', h('span', 'المنشور القادم'), h('b', 'لا شيء مجدول'), h('small', App.linked() ? 'اسحب مقتبسًا إلى التقويم، أو اعتمد خطة نشر.' : 'الجدولة تعمل بعد ربط حساب جوجل.'))),
      h('a.ps-k', { href: '#/publish/queue' }, h('b', String(sched.length)), h('span', 'مجدول')),
      h('a.ps-k', { href: '#/publish/queue' }, h('b', String(sentMonth)), h('span', 'نُشر هذا الشهر')),
      h('a.ps-k' + (failed ? '.bad' : ''), { href: '#/publish/queue' }, h('b', String(failed)), h('span', 'تعذّر')),
      h('div.ps-k', h('b', String(ready)), h('span', 'جاهز للنشر'))));
    if (!App.linked()) page.appendChild(h('div', { style: { marginBottom: '14px' } }, App.lockNote('الجدولة تُنفَّذ من سحابتك في جوجل، فتُنشر المقتبسات في مواعيدها ولو كان جهازك مطفأً. أما النشر الفوري فيعمل الآن.')));
  }

  // الموعد الثابت التالي الفارغ لقناة
  function nextSlot(ch, posts, after = Date.now() + 10 * 60e3) {
    const slots = (ch.slots && ch.slots.length ? ch.slots : ['20:00']).slice().sort();
    const taken = new Set(posts.filter((p) => p.channelId === ch.id && p.status === 'scheduled').map((p) => Math.round(p.at / 60e3)));
    const d = new Date(); d.setHours(0, 0, 0, 0);
    for (let i = 0; i < 120; i++) {
      for (const s of slots) {
        const [hh, mm] = s.split(':').map(Number);
        const at = new Date(d); at.setHours(hh, mm, 0, 0);
        if (at.getTime() > after && !taken.has(Math.round(at.getTime() / 60e3)) && (!ch.days || !ch.days.length || ch.days.includes(at.getDay()))) return at.getTime();
      }
      d.setDate(d.getDate() + 1);
    }
    return after + 86400e3;
  }
  App.nextSlot = nextSlot;

  // ================= التقويم =================
  async function calendar(page) {
    const [quotesAll, chans] = await Promise.all([MQDB.all('quotes'), MQ.getChannels()]);
    let posts = await MQDB.all('posts');
    const quoteMap = new Map(quotesAll.map((q) => [q.id, q]));
    let mode = App.settings.calMode || 'month';
    let cursor = new Date(); cursor.setHours(0, 0, 0, 0);
    let filter = null, statusF = '';
    const weekStart = App.settings.weekStart ?? 6;
    const today0 = () => { const t = new Date(); t.setHours(0, 0, 0, 0); return t; };

    const title = h('h2');
    const modeSeg = h('div.seg');
    const paintMode = () => modeSeg.replaceChildren(...[['month', 'شهر'], ['week', 'أسبوع']].map(([k, l]) => h('button' + (mode === k ? '.on' : ''), { type: 'button', onclick: async () => { mode = k; paintMode(); App.settings = await MQ.saveSettings({ calMode: k }); paint(); } }, l)));
    paintMode();
    const step = (dir) => { if (mode === 'month') { cursor.setDate(1); cursor.setMonth(cursor.getMonth() + dir); } else cursor.setDate(cursor.getDate() + 7 * dir); paint(); };
    const head = h('div.cal-h',
      h('button.btn.btn-icon.sm', { title: 'السابق', onclick: () => step(-1) }, icon('chevronL')),
      title,
      h('button.btn.btn-icon.sm', { title: 'التالي', onclick: () => step(1) }, icon('chevron')),
      h('button.btn.btn-sm', { onclick: () => { cursor = today0(); paint(); } }, 'اليوم'),
      h('span', { style: { flex: 1 } }),
      modeSeg,
      h('button.btn.btn-sm.btn-ghost', { disabled: !App.linked(), title: 'جلب حالة المنشورات من سحابتك', onclick: async () => { await refreshFromCloud(); paint(); } }, icon('refresh')));
    const body = h('div');
    const chFilter = h('div.chips');
    const stFilter = h('select.select', { style: { width: 'auto' }, onchange: (e) => { statusF = e.target.value; draw(); } },
      h('option', { value: '' }, 'كل الحالات'), h('option', { value: 'scheduled' }, 'المجدولة'), h('option', { value: 'sent' }, 'المنشورة'), h('option', { value: 'failed' }, 'المتعذّرة'));
    const cal = h('div.cal', head, body);
    const tray = h('aside.tray');
    page.append(h('div.toolbar', chFilter, h('span', { style: { flex: 1 } }), stFilter), h('div.pubwrap', cal, tray));

    function paintFilter() {
      chFilter.replaceChildren(h('button.chip' + (!filter ? '.on' : ''), { onclick: () => { filter = null; paintFilter(); draw(); } }, 'كل القنوات'),
        ...chans.map((c) => h('button.chip' + (filter === c.id ? '.on' : ''), { onclick: () => { filter = c.id; paintFilter(); draw(); } }, h('span.dot', { style: { background: c.color } }), c.name)));
    }
    paintFilter();
    function paint() { MQDB.all('posts').then((p) => { posts = p; draw(); }); }
    const visible = () => posts.filter((p) => p.at && (!filter || p.channelId === filter) && (!statusF || p.status === statusF));

    async function dropOn(e, d, timeFromY) {
      const postId = e.dataTransfer.getData('mq/post'), quoteId = e.dataTransfer.getData('mq/quote');
      const nd = new Date(d);
      if (postId) {
        const p = posts.find((x) => x.id === postId);
        if (!p || p.status !== 'scheduled') return;
        if (timeFromY != null) nd.setHours(Math.floor(timeFromY), Math.round((timeFromY % 1) * 60), 0, 0);
        else { const old = new Date(p.at); nd.setHours(old.getHours(), old.getMinutes(), 0, 0); }
        if (nd.getTime() < Date.now()) { App.toast('لا يمكن نقل منشور إلى وقت مضى'); return; }
        try { await MQPub.reschedule(p, nd.getTime()); App.toast('نُقل إلى ' + MQ.dayLabel(nd.getTime()) + ' ' + MQ.fmtClock(nd.getTime())); paint(); }
        catch (er) { App.toast(er.message, 4000); }
      } else if (quoteId) {
        const q = quoteMap.get(quoteId); if (!q) return;
        const ch = chans.find((c) => c.id === filter) || chans[0];
        if (timeFromY != null) nd.setHours(Math.floor(timeFromY), Math.round((timeFromY % 1) * 60), 0, 0);
        else { const s = (ch && ch.slots && ch.slots[0]) || '20:00'; const [hh, mm] = s.split(':').map(Number); nd.setHours(hh, mm, 0, 0); }
        App.publishDialog(q, { at: Math.max(nd.getTime(), Date.now() + 15 * 60e3), mode: 'later', channelId: ch && ch.id, onDone: paint });
      }
    }
    const canDrop = (d) => App.linked() && d >= today0();

    function draw() {
      if (mode === 'week') drawWeek(); else drawMonth();
      paintTray();
    }
    function drawMonth() {
      const m = new Date(cursor); m.setDate(1);
      title.textContent = m.toLocaleDateString('ar', { month: 'long', year: 'numeric' });
      const offset = (m.getDay() - weekStart + 7) % 7;
      const start = new Date(m); start.setDate(1 - offset);
      const today = today0();
      const dow = h('div.cal-dow', [...Array(7)].map((_, i) => h('div', DOW[(weekStart + i) % 7])));
      const grid = h('div.cal-grid');
      const vis = visible();
      for (let i = 0; i < 42; i++) {
        const d = new Date(start); d.setDate(start.getDate() + i);
        if (i >= 35 && d.getMonth() !== m.getMonth()) break;
        const dayEnd = new Date(d); dayEnd.setDate(d.getDate() + 1);
        const items = vis.filter((p) => p.at >= d.getTime() && p.at < dayEnd.getTime()).sort((a, b) => a.at - b.at);
        const cell = h('div.day' + (d.getMonth() !== m.getMonth() ? '.out' : '') + (d.getTime() === today.getTime() ? '.today' : '') + (d < today ? '.past' : ''),
          h('span.dn.num', String(d.getDate())),
          canDrop(d) ? h('button.add', { title: 'جدولة في هذا اليوم', onclick: () => pickAndSchedule(d) }, icon('plus', 15)) : null,
          items.slice(0, 4).map((p) => postChip(p)),
          items.length > 4 ? h('button.more', { type: 'button', onclick: () => { cursor = new Date(d); mode = 'week'; paintMode(); draw(); } }, `+${items.length - 4} أخرى`) : null);
        cell.addEventListener('dblclick', (e) => { if (e.target === cell && canDrop(d)) pickAndSchedule(d); });
        cell.addEventListener('dragover', (e) => { if (canDrop(d)) { e.preventDefault(); cell.classList.add('over'); } });
        cell.addEventListener('dragleave', () => cell.classList.remove('over'));
        cell.addEventListener('drop', (e) => { e.preventDefault(); cell.classList.remove('over'); dropOn(e, d, null); });
        grid.appendChild(cell);
      }
      body.replaceChildren(dow, grid);
    }
    function drawWeek() {
      const start = new Date(cursor); start.setDate(start.getDate() - ((start.getDay() - weekStart + 7) % 7)); start.setHours(0, 0, 0, 0);
      const end = new Date(start); end.setDate(start.getDate() + 6);
      title.textContent = `${start.toLocaleDateString('ar', { day: 'numeric', month: 'long' })} — ${end.toLocaleDateString('ar', { day: 'numeric', month: 'long', year: 'numeric' })}`;
      const today = today0();
      const vis = visible();
      const headRow = h('div.wk-head', h('div'), [...Array(7)].map((_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return h('div' + (d.getTime() === today.getTime() ? '.today' : ''), h('span', DOW[d.getDay()]), h('b', String(d.getDate()))); }));
      const hours = h('div.wk-hours', [...Array(HOUR1 - HOUR0)].map((_, i) => h('div', { style: { height: ROW + 'px' } }, h('span', `${HOUR0 + i}:00`))));
      const cols = [...Array(7)].map((_, i) => {
        const d = new Date(start); d.setDate(start.getDate() + i);
        const dayEnd = new Date(d); dayEnd.setDate(d.getDate() + 1);
        const col = h('div.wk-col' + (d < today ? '.past' : ''), { style: { height: (HOUR1 - HOUR0) * ROW + 'px' } });
        // خطّ «الآن»
        if (d.getTime() === today.getTime()) { const n = new Date(); const y = (n.getHours() + n.getMinutes() / 60 - HOUR0) * ROW; if (y > 0) col.appendChild(h('div.wk-now', { style: { top: y + 'px' } })); }
        // المواعيد الثابتة للقناة المختارة
        const ch = chans.find((c) => c.id === filter);
        if (ch && ch.slots) ch.slots.forEach((s) => { const [hh, mm] = s.split(':').map(Number); if (hh >= HOUR0) col.appendChild(h('div.wk-slot', { style: { top: (hh + mm / 60 - HOUR0) * ROW + 'px' } })); });
        vis.filter((p) => p.at >= d.getTime() && p.at < dayEnd.getTime()).forEach((p) => {
          const t = new Date(p.at); const y = Math.max(0, (t.getHours() + t.getMinutes() / 60 - HOUR0) * ROW);
          const chip = postChip(p, true); chip.style.top = y + 'px';
          col.appendChild(chip);
        });
        const yToTime = (e) => { const r = col.getBoundingClientRect(); const hrs = HOUR0 + (e.clientY - r.top) / ROW; return Math.max(HOUR0, Math.min(23.75, Math.round(hrs * 4) / 4)); };
        col.addEventListener('dragover', (e) => { if (canDrop(d)) { e.preventDefault(); col.classList.add('over'); const g = col.querySelector('.wk-ghost') || col.appendChild(h('div.wk-ghost')); const tm = yToTime(e); g.style.top = (tm - HOUR0) * ROW + 'px'; g.textContent = `${Math.floor(tm)}:${String(Math.round((tm % 1) * 60)).padStart(2, '0')}`; } });
        col.addEventListener('dragleave', () => { col.classList.remove('over'); col.querySelector('.wk-ghost')?.remove(); });
        col.addEventListener('drop', (e) => { e.preventDefault(); col.classList.remove('over'); col.querySelector('.wk-ghost')?.remove(); dropOn(e, d, yToTime(e)); });
        col.addEventListener('dblclick', (e) => { if (e.target !== col || !canDrop(d)) return; const tm = yToTime(e); const at = new Date(d); at.setHours(Math.floor(tm), Math.round((tm % 1) * 60), 0, 0); pickAndSchedule(d, at.getTime()); });
        return col;
      });
      const grid = h('div.wk-grid', hours, cols);
      const scroller = h('div.wk-scroll', grid);
      body.replaceChildren(headRow, scroller);
      requestAnimationFrame(() => { scroller.scrollTop = (Math.max(HOUR0, new Date().getHours() - 2) - HOUR0) * ROW; });
    }
    function postChip(p, week) {
      const q = quoteMap.get(p.quoteId) || {};
      const chip = h('div.pchip.' + p.status + (week ? '.wk' : ''), { style: { '--c': p.color || 'var(--accent)' }, draggable: p.status === 'scheduled', title: `${p.channelName} — ${q.title || ''}`,
        onclick: () => postDialog(p, q, paint) },
        h('span.tm', MQ.fmtClock(p.at)), h('span.tx', q.title || 'اقتباس'));
      chip.addEventListener('dragstart', (e) => { e.dataTransfer.setData('mq/post', p.id); e.dataTransfer.effectAllowed = 'move'; });
      return chip;
    }
    let traySearch = '';
    function paintTray() {
      const used = new Set(posts.map((p) => p.quoteId));
      const ready = quotesAll.filter((q) => !used.has(q.id) && (!traySearch || [q.title, q.speaker, q.series, ...(q.categories || [])].join(' ').includes(traySearch))).sort((a, b) => b.createdAt - a.createdAt);
      const search = h('input.input', { placeholder: 'ابحث…', value: traySearch, oninput: MQ.debounce((e) => { traySearch = e.target.value.trim(); paintTray(); setTimeout(() => { const i = tray.querySelector('input'); if (i) { i.focus(); i.setSelectionRange(i.value.length, i.value.length); } }, 0); }, 250) });
      tray.replaceChildren(h('h3', 'جاهزة للنشر'), h('p.hint', App.linked() ? 'اسحبها إلى يوم أو ساعة في التقويم، أو اضغط ⚡ لموعد قناتها التالي.' : 'بعد ربط جوجل تسحبها إلى التقويم.'), search);
      if (!ready.length) tray.appendChild(h('p.hint', traySearch ? 'لا نتائج.' : 'كل مقتبساتك نُشرت أو جُدولت.'));
      ready.slice(0, 60).forEach((q) => {
        const quick = App.linked() && chans.length ? h('button.qk', { type: 'button', title: 'جدولة في الموعد التالي للقناة', onclick: async (e) => {
          e.stopPropagation();
          const ch = chans.find((c) => c.id === filter) || chans[0];
          App.publishDialog(q, { at: nextSlot(ch, posts), mode: 'later', channelId: ch.id, onDone: paint });
        } }, '⚡') : null;
        const it = h('div.tq', { draggable: App.linked(), title: q.title, onclick: () => App.publishDialog(q, { onDone: paint }) }, h('img', { src: App.thumbOf(q), alt: '' }), h('span', q.title || 'اقتباس'), quick);
        it.addEventListener('dragstart', (e) => { e.dataTransfer.setData('mq/quote', q.id); e.dataTransfer.effectAllowed = 'copy'; });
        tray.appendChild(it);
      });
    }
    async function pickAndSchedule(d, atTs) {
      const used = new Set(posts.map((p) => p.quoteId));
      const list = quotesAll.filter((q) => !used.has(q.id)).sort((a, b) => b.createdAt - a.createdAt);
      if (!list.length) { App.toast('لا مقتبسات جاهزة للنشر'); return; }
      const ch = chans.find((c) => c.id === filter) || chans[0];
      const at = atTs || (() => { const x = new Date(d); const s = (ch && ch.slots && ch.slots[0]) || '20:00'; const [hh, mm] = s.split(':').map(Number); x.setHours(hh, mm, 0, 0); return x.getTime(); })();
      const body = h('div.pick-grid', list.slice(0, 40).map((q) => h('div.tq', { onclick: () => { dlg.close(); App.publishDialog(q, { at: Math.max(at, Date.now() + 15 * 60e3), mode: 'later', channelId: ch && ch.id, onDone: paint }); } },
        h('img', { src: App.thumbOf(q), alt: '' }), h('span', q.title || 'اقتباس'))));
      const dlg = App.dialog({ title: 'اختر مقتبسًا لـ ' + MQ.dayLabel(at) + ' ' + MQ.fmtClock(at), body, wide: true });
    }
    draw();
    refreshFromCloud(true).then(() => paint());
  }

  // ================= الطابور: تحكّم جماعي =================
  async function queue(page) {
    await refreshFromCloud(true);
    const [posts, quotes, chans] = await Promise.all([MQDB.all('posts'), MQDB.all('quotes'), MQ.getChannels()]);
    const qm = new Map(quotes.map((q) => [q.id, q]));
    let filter = '', statusF = 'scheduled', search = '';
    const sel = new Set();
    const bar = h('div.bulk');
    const box = h('div');
    const chSel = h('select.select', { style: { width: 'auto' }, onchange: (e) => { filter = e.target.value; paint(); } }, h('option', { value: '' }, 'كل القنوات'), chans.map((c) => h('option', { value: c.id }, c.name)));
    const stSeg = h('div.seg');
    const paintSt = () => stSeg.replaceChildren(...[['scheduled', 'القادم'], ['failed', 'المتعذّر'], ['sent', 'المنشور'], ['', 'الكل']].map(([k, l]) => h('button' + (statusF === k ? '.on' : ''), { type: 'button', onclick: () => { statusF = k; sel.clear(); paintSt(); paint(); } }, l, k ? h('small', ` ${posts.filter((p) => p.status === k).length}`) : null)));
    paintSt();
    page.append(h('div.toolbar', stSeg, chSel, h('div.searchbox', icon('search'), h('input.input', { placeholder: 'ابحث في العناوين…', oninput: MQ.debounce((e) => { search = e.target.value.trim(); paint(); }, 200) }))), bar, box);
    const list = () => posts.filter((p) => (!statusF || p.status === statusF) && (!filter || p.channelId === filter) && (!search || ((qm.get(p.quoteId) || {}).title || '').includes(search)))
      .sort((a, b) => statusF === 'sent' ? (b.sentAt || b.at) - (a.sentAt || a.at) : a.at - b.at);
    function paintBar() {
      const n = sel.size;
      const chosen = posts.filter((p) => sel.has(p.id));
      const sched = chosen.filter((p) => p.status === 'scheduled');
      bar.replaceChildren(...(n ? [
        h('b', `حدّدت ${n}`),
        sched.length ? h('button.btn.btn-sm', { type: 'button', onclick: () => shiftDays(sched, 1) }, 'أخّرها يومًا') : null,
        sched.length ? h('button.btn.btn-sm', { type: 'button', onclick: () => shiftDays(sched, -1) }, 'قدّمها يومًا') : null,
        sched.length ? h('button.btn.btn-sm', { type: 'button', onclick: () => spread(sched) }, 'وزّعها على مواعيد القناة') : null,
        h('button.btn.btn-sm', { type: 'button', onclick: () => sendNowMany(chosen.filter((p) => p.status !== 'sent')) }, icon('send'), 'انشرها الآن'),
        sched.length ? h('button.btn.btn-sm.btn-ghost.btn-danger', { type: 'button', onclick: () => cancelMany(sched) }, 'إلغاء المحدّد') : null,
        h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { sel.clear(); paint(); } }, 'إلغاء التحديد'),
      ] : [h('span.hint', 'حدّد منشورات لتتحكّم فيها معًا: تقديم وتأخير، توزيع على المواعيد، نشر فوري، أو إلغاء.')]));
    }
    const run = async (items, fn, okMsg) => {
      let n = 0, err = 0;
      for (const p of items) { try { await fn(p); n++; } catch (e) { err++; console.warn(e); } App.toast(`جارٍ… ${n + err} من ${items.length}`); }
      App.toast(err ? `${okMsg} ${n}، وتعذّر ${err}` : `${okMsg} ${n} ✓`, 3500);
      sel.clear(); App.refresh();
    };
    const shiftDays = (items, k) => run(items, (p) => { const at = p.at + k * 86400e3; if (at < Date.now()) throw new Error('past'); return MQPub.reschedule(p, at); }, k > 0 ? 'أُخّر' : 'قُدّم');
    const cancelMany = async (items) => { if (!(await App.confirm(`إلغاء ${items.length} منشورات مجدولة؟`, 'إلغاء', true))) return; run(items, (p) => MQPub.cancelPost(p), 'أُلغي'); };
    const sendNowMany = async (items) => {
      if (!(await App.confirm(`نشر ${items.length} منشورات الآن، واحدًا بعد الآخر؟`, 'انشر'))) return;
      run(items, async (p) => { const ch = chans.find((c) => c.id === p.channelId); if (!ch) throw new Error('no channel'); await MQPub.sendNow(await MQDB.get('quotes', p.quoteId), ch, p.caption, { post: p, silent: p.silent }); }, 'نُشر');
    };
    const spread = async (items) => {
      const byCh = new Map(); items.sort((a, b) => a.at - b.at).forEach((p) => { if (!byCh.has(p.channelId)) byCh.set(p.channelId, []); byCh.get(p.channelId).push(p); });
      const all = await MQDB.all('posts');
      const plan = [];
      for (const [cid, list] of byCh) {
        const ch = chans.find((c) => c.id === cid); if (!ch) continue;
        const others = all.filter((p) => !list.includes(p));
        let after = Date.now() + 10 * 60e3;
        for (const p of list) { const at = nextSlot(ch, [...others, ...plan.map((x) => ({ ...x.p, at: x.at }))], after); plan.push({ p, at }); after = at; }
      }
      run(plan, (x) => MQPub.reschedule(x.p, x.at), 'وُزّع');
    };
    function paint() {
      const l = list();
      paintBar();
      if (!l.length) { box.replaceChildren(h('p.hint', statusF === 'scheduled' ? 'لا منشورات مجدولة. اسحب مقتبسًا إلى التقويم، أو اعتمد «خطة نشر».' : 'لا شيء هنا.')); return; }
      const allBox = h('input', { type: 'checkbox', checked: l.every((p) => sel.has(p.id)), onchange: (e) => { l.forEach((p) => e.target.checked ? sel.add(p.id) : sel.delete(p.id)); paint(); } });
      box.replaceChildren(h('label.check.selall', allBox, h('span', 'تحديد الكل')),
        ...App.groupByDay(l, (p) => p.sentAt || p.at, (p, i) => {
          const q = qm.get(p.quoteId) || {};
          return h('div.lrow.qrow.rise' + (sel.has(p.id) ? '.sel' : ''), { style: { '--i': Math.min(i, 15) } },
            h('input', { type: 'checkbox', checked: sel.has(p.id), onchange: (e) => { e.target.checked ? sel.add(p.id) : sel.delete(p.id); paint(); } }),
            h('div.th', h('img', { src: App.thumbOf(q), alt: '' })),
            h('div.bd', h('div.tt', q.title || 'اقتباس'), h('div.sb', h('span', h('span.dot', { style: { background: p.color } }), ' ', p.channelName), h('span.num', MQ.fmtClock(p.sentAt || p.at)), p.silent ? h('span', 'بلا إشعار') : null, p.error ? h('span', { style: { color: 'var(--danger)' } }, p.error) : null)),
            h('div.ac', App.statusTag(p.status), h('button.btn.btn-sm', { onclick: () => postDialog(p, q, () => App.refresh()) }, 'تفاصيل')));
        }));
    }
    paint();
  }

  // حوار منشور واحد
  function postDialog(p, q, after) {
    const ta = MQ.captionBox(p.caption || '');
    const localInput = (ts) => { const d = new Date(ts); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
    const when = h('input.input', { type: 'datetime-local', value: localInput(p.at), style: { width: 'auto', direction: 'ltr' }, disabled: p.status !== 'scheduled' });
    const body = h('div',
      h('div.lrow', h('div.th', h('img', { src: App.thumbOf(q), alt: '' })), h('div.bd', h('div.tt', q.title || 'اقتباس'), h('div.sb', h('span', h('span.dot', { style: { background: p.color } }), ' ', p.channelName), App.statusTag(p.status)))),
      p.error ? h('div.lock-note', { style: { marginTop: '10px' } }, icon('info'), h('span', p.error)) : null,
      h('div.field', { style: { marginTop: '14px' } }, h('span.label', 'الموعد'), when),
      h('div.field', h('span.label', 'نصّ المنشور'), ta.el, h('div.hint', 'التليجرام لا يسمح بتعديل منشور بعد إرساله.')));
    const actions = [];
    if (p.status === 'scheduled' || p.status === 'failed') {
      actions.push({ label: 'حفظ', primary: true, onClick: async () => {
        let cur = p;
        const at = new Date(when.value).getTime();
        if (p.status === 'failed') { await MQPub.schedule(await MQDB.get('quotes', p.quoteId), (await MQ.getChannels()).find((c) => c.id === p.channelId) || { id: p.channelId, name: p.channelName, chatId: '' }, ta.value, at, { post: p }); }
        else {
          if (at && at !== p.at) cur = await MQPub.reschedule(cur, at);
          if (ta.value !== p.caption) cur = await MQPub.updateCaption(cur, ta.value);
        }
        App.toast('حُفظ'); after && after();
      } });
      actions.push({ label: 'انشر الآن', icon: 'send', onClick: async () => {
        const ch = (await MQ.getChannels()).find((c) => c.id === p.channelId);
        if (!ch) throw new Error('القناة لم تعد موجودة.');
        await MQPub.sendNow(await MQDB.get('quotes', p.quoteId), ch, ta.value, { post: p, silent: p.silent });
        App.toast('نُشر ✓'); after && after();
      } });
      actions.push({ label: 'إلغاء المنشور', danger: true, ghost: true, onClick: async () => { if (!(await App.confirm('إلغاء هذا المنشور المجدول؟', 'إلغاء المنشور', true))) return false; await MQPub.cancelPost(p); App.toast('أُلغي'); after && after(); } });
    } else actions.push({ label: 'إغلاق', ghost: true });
    App.dialog({ title: 'منشور في «' + p.channelName + '»', body, actions });
  }

  // ================= القنوات =================
  async function channels(page) {
    const list = await MQ.getChannels();
    const tplList = await MQ.getTemplates();
    page.appendChild(h('div.toolbar', h('button.btn.btn-primary', { onclick: () => channelDialog(null, tplList) }, icon('plus'), 'قناة جديدة'),
      h('span.hint', App.settings.tgToken ? 'رمز البوت العام مضبوط ✓ — تستعمله القنوات ما لم يكن لها رمز خاص.' : 'ابدأ بضبط رمز البوت من الإعدادات ← التليجرام، أو أدخله لكل قناة.')));
    if (!list.length) { page.appendChild(App.empty('لا قنوات بعد', 'أضف قنواتك مرة واحدة، ثم تختار منها بنقرة عند كل اقتباس.', h('button.btn.btn-primary', { onclick: () => channelDialog(null, tplList) }, 'أضف أول قناة'))); return; }
    const posts = await MQDB.all('posts');
    page.appendChild(h('div.chgrid', list.map((c, i) => {
      const t = tplList.find((x) => x.id === c.templateId);
      const n = posts.filter((p) => p.channelId === c.id && p.status === 'sent').length;
      return h('div.chcard.rise', { style: { '--c': c.color, '--i': i } },
        h('h3', c.name), h('div.id', c.chatId),
        h('div.hint', { style: { marginTop: '8px' } }, `القالب: ${t ? t.name : '—'} · ${n} منشور`),
        h('div.chslots', icon('clock', 14), (c.slots && c.slots.length ? c.slots : ['20:00']).join(' · '), c.days && c.days.length ? h('span', ' — ' + c.days.map((d) => DOW[d]).join('، ')) : null),
        h('div.acts',
          h('button.btn.btn-sm', { onclick: () => channelDialog(c, tplList) }, icon('edit'), 'تعديل'),
          h('button.btn.btn-sm.btn-ghost', { onclick: async (e) => { e.target.disabled = true; try { await MQ.tgCall(MQ.channelToken(c, App.settings), 'sendMessage', { chat_id: c.chatId, text: '✓ تجربة من «المقتبس»: الاتصال بالقناة يعمل. يمكنك حذف هذه الرسالة.' }); App.toast('وصلت رسالة التجربة ✓'); } catch (er) { App.toast(er.message, 5000); } e.target.disabled = false; } }, 'تجربة'),
          h('button.btn.btn-sm.btn-ghost.btn-danger', { onclick: async () => { if (await App.confirm(`حذف قناة «${c.name}» من القائمة؟`, 'حذف', true)) { await MQ.deleteChannel(c.id); App.refresh(); } } }, 'حذف')));
    })));
  }
  function channelDialog(c, tplList) {
    const isNew = !c;
    c = c ? { ...c } : { id: MQ.uid(), name: '', chatId: '', token: '', color: MQ.CHANNEL_COLORS[0], templateId: 'tpl-default', slots: ['20:00'], days: [] };
    let slots = [...(c.slots && c.slots.length ? c.slots : ['20:00'])];
    const days = new Set(c.days || []);
    const slotBox = h('div.chips');
    const paintSlots = () => slotBox.replaceChildren(...slots.map((t, i) => h('span.chip', h('input', { type: 'time', value: t, style: { border: 0, background: 'transparent', direction: 'ltr' }, onchange: (e) => { slots[i] = e.target.value; } }),
      slots.length > 1 ? h('span', { style: { cursor: 'pointer' }, onclick: () => { slots.splice(i, 1); paintSlots(); } }, '×') : null)),
      h('button.chip', { type: 'button', onclick: () => { slots.push('12:00'); paintSlots(); } }, '＋ موعد'));
    paintSlots();
    const dayBox = h('div.chips');
    const paintDays = () => dayBox.replaceChildren(...[...Array(7)].map((_, i) => { const d = ((App.settings.weekStart ?? 6) + i) % 7; return h('button.chip' + (!days.size || days.has(d) ? '.on' : ''), { type: 'button', onclick: () => { if (!days.size) [0, 1, 2, 3, 4, 5, 6].forEach((x) => days.add(x)); days.has(d) ? days.delete(d) : days.add(d); if (days.size === 7) days.clear(); paintDays(); } }, DOW[d]); }));
    paintDays();
    const name = h('input.input', { value: c.name, placeholder: 'مثلًا: قناتي، قناة الأكاديمية' });
    const chat = h('input.input.ltr', { value: c.chatId, placeholder: '@channel أو -100…' });
    const token = h('input.input.ltr', { value: c.token || '', type: 'password', placeholder: App.settings.tgToken ? 'يُستعمل الرمز العام' : '123456789:AA…' });
    const colors = h('div.swatches');
    const paintColors = () => colors.replaceChildren(...MQ.CHANNEL_COLORS.map((col) => h('button' + (c.color === col ? '.on' : ''), { type: 'button', style: { background: col }, onclick: () => { c.color = col; paintColors(); } })));
    paintColors();
    const tpl = h('select.select', tplList.map((t) => h('option', { value: t.id, selected: t.id === c.templateId }, t.name)));
    const found = h('div.chips', { style: { marginTop: '8px' } });
    const detect = h('button.btn.btn-sm', { type: 'button', onclick: async () => {
      const tk = token.value.trim() || App.settings.tgToken;
      if (!tk) { App.toast('أدخل رمز البوت أولًا'); return; }
      detect.disabled = true; found.replaceChildren(h('span.hint', 'جارٍ البحث…'));
      try {
        const chats = await MQ.tgDetectChats(tk);
        found.replaceChildren(...(chats.length ? chats.map((x) => h('button.chip', { type: 'button', onclick: () => { chat.value = String(x.id); if (!name.value) name.value = x.title || ''; found.replaceChildren(h('span.hint', '✓ اخترت «' + (x.title || '') + '»')); } }, x.title || x.id))
          : [h('span.hint', 'لم أجد قناة. أضف البوت مشرفًا، وانشر في القناة رسالة جديدة، ثم أعد البحث.')]));
      } catch (e) { found.replaceChildren(h('span.hint', { style: { color: 'var(--danger)' } }, e.message)); }
      detect.disabled = false;
    } }, icon('search'), 'اكتشاف القناة');
    const body = h('div',
      h('div.field', h('label', 'اسم القناة (يظهر لك فقط)'), name),
      h('div.field', h('label', 'معرّف القناة'), h('div', { style: { display: 'flex', gap: '8px' } }, chat, detect), found,
        h('div.hint', 'للقناة العامة: اسمها مسبوقًا بـ @. وللخاصة: أضف البوت مشرفًا، وانشر فيها رسالة، ثم اضغط «اكتشاف القناة».')),
      h('div.field', h('label', 'القالب الافتراضي'), tpl),
      h('div.field', h('label', 'اللون'), colors),
      h('div.field', h('span.label', 'مواعيد النشر الثابتة'), slotBox, h('div.hint', 'تُستعمل في «⚡ الموعد التالي» وفي توزيع المنشورات وخطة النشر.')),
      h('div.field', h('span.label', 'أيام النشر'), dayBox),
      h('details', h('summary', { style: { cursor: 'pointer', color: 'var(--accent)', fontSize: '13.5px' } }, 'رمز بوت خاص بهذه القناة (اختياري)'), h('div.field', { style: { marginTop: '8px' } }, token)));
    App.dialog({ title: isNew ? 'قناة جديدة' : 'تعديل القناة', body, actions: [{ label: 'حفظ', primary: true, onClick: async () => {
      let id = chat.value.trim();
      const m = id.match(/(?:t\.me\/|telegram\.me\/)([A-Za-z0-9_]+)/); if (m && !id.includes('/+')) id = '@' + m[1];
      if (/t\.me\/\+/.test(id)) throw new Error('رابط الدعوة للقناة الخاصة لا يصلح معرّفًا؛ استعمل «اكتشاف القناة».');
      if (id && !id.startsWith('@') && !/^-?\d+$/.test(id)) id = '@' + id;
      if (!name.value.trim() || !id) throw new Error('أدخل اسم القناة ومعرّفها.');
      await MQ.saveChannel({ ...c, name: name.value.trim(), chatId: id, token: token.value.trim(), templateId: tpl.value, slots: slots.filter(Boolean).sort(), days: [...days] });
      App.toast('حُفظت القناة'); App.refresh();
    } }, { label: 'إلغاء', ghost: true }] });
  }

  // ================= القوالب =================
  const SEPS = ['━━━━━━━━━━', '✦ ✦ ✦', '۞', '❖ ────── ❖', '•••', '﴿ ﴾'];
  async function templates(page) {
    const list = await MQ.getTemplates();
    const quotes = (await MQDB.all('quotes')).sort((a, b) => b.createdAt - a.createdAt);
    const sample = quotes[0] || { title: 'لماذا يتأخّر الإصلاح؟', desc: 'كلمة قصيرة في معنى الصبر على الطريق.', videoTitle: 'محاضرة: مركزيات الإصلاح', speaker: 'المحاضر', categories: ['منهج الإصلاح'], link: 'https://youtu.be/xyz?t=754', duration: 75, createdAt: Date.now() };
    let cur = list.find((t) => !t.builtin) || list[0];
    let dark = false;
    const listBox = h('div.tpl-list');
    const ed = h('div.tpl-ed.card.pad');
    const prev = h('div');
    page.appendChild(h('div.tpl', h('div', listBox, h('button.btn.btn-sm', { style: { marginTop: '10px' }, onclick: () => { cur = { id: MQ.uid(), name: 'قالب جديد', body: MQ.DEFAULT_TEMPLATE_BODY, isNew: true }; paintEditor(); paintList(); } }, icon('plus'), 'قالب جديد')), ed, prev));

    function paintList() {
      listBox.replaceChildren(...[...list, ...(cur && cur.isNew ? [cur] : [])].map((t) => h('button' + (cur && t.id === cur.id ? '.on' : ''), { onclick: () => { cur = t; paintEditor(); paintList(); } }, icon('text', 16), t.name, t.builtin ? h('span.lock', 'أصلي') : null)));
    }
    function paintEditor() {
      const name = h('input.input', { value: cur.name, disabled: cur.builtin && cur.id === 'none' });
      const ta = h('textarea.textarea', { rows: 12, disabled: cur.id === 'none' }); ta.value = cur.body;
      const wrapSel = (open, close) => {
        const a = ta.selectionStart, b = ta.selectionEnd, v = ta.value;
        ta.value = v.slice(0, a) + open + v.slice(a, b) + close + v.slice(b);
        ta.focus(); ta.selectionStart = a + open.length; ta.selectionEnd = b + open.length; paintPrev();
      };
      const insert = (txt) => { const a = ta.selectionStart; ta.value = ta.value.slice(0, a) + txt + ta.value.slice(ta.selectionEnd); ta.focus(); ta.selectionStart = ta.selectionEnd = a + txt.length; paintPrev(); };
      const sepBtn = h('button.btn', { type: 'button', onclick: () => App.menu(sepBtn, SEPS.map((s) => ({ label: s, onClick: () => insert('\n' + s + '\n') }))) }, 'فاصل ▾');
      const bar = h('div.tbar',
        h('button.btn', { type: 'button', title: 'عريض', onclick: () => wrapSel('<b>', '</b>') }, h('b', 'ع')),
        h('button.btn', { type: 'button', title: 'مائل', onclick: () => wrapSel('<i>', '</i>') }, h('i', 'م')),
        h('button.btn', { type: 'button', title: 'تسطير', onclick: () => wrapSel('<u>', '</u>') }, h('u', 'س')),
        h('button.btn', { type: 'button', title: 'مخفيّ حتى يُضغط', onclick: () => wrapSel('<tg-spoiler>', '</tg-spoiler>') }, 'مخفيّ'),
        h('button.btn', { type: 'button', title: 'اقتباس', onclick: () => wrapSel('<blockquote>', '</blockquote>') }, 'اقتباس'),
        h('button.btn', { type: 'button', title: 'اقتباس قابل للطيّ', onclick: () => wrapSel('<blockquote expandable>', '</blockquote>') }, 'اقتباس مطويّ'),
        h('button.btn', { type: 'button', title: 'رابط', onclick: async () => { const u = await App.prompt('الرابط', 'https://'); if (u) wrapSel(`<a href="${u.replace(/"/g, '')}">`, '</a>'); } }, 'رابط'),
        sepBtn);
      const vars = h('div.varchips', MQ.VARS.map((k) => h('button', { type: 'button', onclick: () => insert('{' + k + '}') }, '{' + k + '}')));
      ta.addEventListener('input', paintPrev);
      function paintPrev() {
        const cap = MQ.buildCaption(ta.value, sample);
        prev.replaceChildren(
          h('div', { style: { display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '8px' } }, h('b', 'المعاينة'), h('span.hint', `${cap.length} / 1024`),
            h('button.btn.btn-sm.btn-ghost', { style: { marginInlineStart: 'auto' }, onclick: () => { dark = !dark; paintPrev(); } }, dark ? 'فاتح' : 'داكن')),
          h('div.tg-phone' + (dark ? '.dark' : ''), h('div.tg-bubble',
            h('div.tg-media', { style: { backgroundImage: `url("${App.thumbOf(sample)}")` } }),
            cap.text ? (() => { const d = h('div.tg-cap'); d.innerHTML = MQ.telegramPreviewHtml(cap.text); return d; })() : null,
            h('div.tg-meta', MQ.fmtClock(Date.now())))),
          h('p.hint', { style: { marginTop: '8px' } }, quotes[0] ? 'المعاينة على آخر مقتبساتك.' : 'المعاينة على مثال.'));
      }
      ed.replaceChildren(
        h('div.field', h('label', 'اسم القالب'), name),
        cur.id === 'none' ? h('div.note-info', icon('info'), h('span', 'هذا القالب يرسل المقطع بلا أي نصّ.')) : h('div', bar, ta, vars,
          h('div.hint', 'تُحذف تلقائيًا الأسطر التي متغيّراتها فارغة. ويُقصّ الوصف إن تجاوز النصّ 1024 حرفًا.')),
        h('div', { style: { display: 'flex', gap: '8px', marginTop: '12px' } },
          cur.id !== 'none' ? h('button.btn.btn-primary', { onclick: async () => {
            const t = { id: cur.builtin ? MQ.uid() : cur.id, name: name.value.trim() || 'قالب', body: ta.value };
            await MQ.saveTemplate(t); App.toast(cur.builtin ? 'حُفظ نسخةً جديدة' : 'حُفظ القالب'); App.refresh();
          } }, cur.builtin ? 'حفظ نسخة باسمي' : 'حفظ') : null,
          !cur.builtin && !cur.isNew ? h('button.btn.btn-ghost', { onclick: async () => { await MQ.saveTemplate({ id: MQ.uid(), name: cur.name + ' (نسخة)', body: ta.value }); App.refresh(); } }, 'تكرار') : null,
          !cur.builtin && !cur.isNew ? h('button.btn.btn-ghost.btn-danger', { onclick: async () => { if (await App.confirm('حذف القالب؟', 'حذف', true)) { await MQ.deleteTemplate(cur.id); App.refresh(); } } }, 'حذف') : null));
      paintPrev();
    }
    paintList(); paintEditor();
  }

  // ================= خطة النشر =================
  async function planWizard(done) {
    if (!App.linked()) { App.dialog({ title: 'خطة نشر', body: App.lockNote('خطة النشر توزّع مقتبساتك على مواعيد قادمة، وتُنشر من سحابتك في جوجل في وقتها ولو كان جهازك مطفأً.'), actions: [{ label: 'حسنًا', ghost: true }] }); return; }
    const [quotes, posts, chans, tpls, cats] = await Promise.all([MQDB.all('quotes'), MQDB.all('posts'), MQ.getChannels(), MQ.getTemplates(), MQ.getCategories()]);
    if (!chans.length) { App.toast('أضف قناة أولًا'); App.go('#/publish/channels'); return; }
    const used = new Set(posts.map((p) => p.quoteId));
    let pool = quotes.filter((q) => !used.has(q.id));
    const picked = new Set(pool.map((q) => q.id));
    let ch = chans[0], tplId = ch.templateId || 'tpl-default';
    const days = new Set(ch.days && ch.days.length ? ch.days : [0, 1, 2, 3, 4, 5, 6]);
    let times = [...(ch.slots && ch.slots.length ? ch.slots : ['08:00', '20:00'])];
    let order = 'old';
    const startD = new Date(); startD.setDate(startD.getDate() + 1);
    const startIn = h('input.input', { type: 'date', value: startD.toISOString().slice(0, 10), style: { width: 'auto', direction: 'ltr' } });
    const body = h('div');
    const listBox = h('div', { style: { maxHeight: '240px', overflow: 'auto', display: 'flex', flexDirection: 'column', gap: '4px', margin: '8px 0' } });
    const catSel = h('select.select', { style: { width: 'auto' }, onchange: () => { const c = catSel.value; pool = quotes.filter((q) => !used.has(q.id) && (!c || (q.categories || []).includes(c))); picked.clear(); pool.forEach((q) => picked.add(q.id)); paintList(); paintPreview(); } },
      h('option', { value: '' }, 'كل التصنيفات'), cats.map((c) => h('option', { value: c }, c)));
    function paintList() {
      listBox.replaceChildren(...(pool.length ? pool.map((q) => h('label.check', { style: { margin: '0', alignItems: 'center' } }, h('input', { type: 'checkbox', checked: picked.has(q.id), onchange: (e) => { e.target.checked ? picked.add(q.id) : picked.delete(q.id); paintPreview(); } }),
        h('img', { src: App.thumbOf(q), style: { width: '56px', borderRadius: '6px', aspectRatio: '16/9', objectFit: 'cover' } }), h('span', q.title || 'اقتباس'))) : [h('p.hint', 'لا مقتبسات غير مجدولة.')]));
    }
    const chBox = h('div.chips');
    const paintCh = () => chBox.replaceChildren(...chans.map((c) => h('button.chip' + (c.id === ch.id ? '.on' : ''), { type: 'button', onclick: () => { ch = c; tplId = c.templateId || tplId; if (c.slots && c.slots.length) { times = [...c.slots]; paintTimes(); } paintCh(); tplSel.value = tplId; paintPreview(); } }, h('span.dot', { style: { background: c.color } }), c.name)));
    const tplSel = h('select.select', { style: { width: 'auto' }, onchange: (e) => { tplId = e.target.value; } }, tpls.map((t) => h('option', { value: t.id, selected: t.id === tplId }, t.name)));
    const dayBox = h('div.chips');
    const paintDays = () => dayBox.replaceChildren(...[...Array(7)].map((_, i) => { const d = ((App.settings.weekStart ?? 6) + i) % 7; return h('button.chip' + (days.has(d) ? '.on' : ''), { type: 'button', onclick: () => { days.has(d) ? days.delete(d) : days.add(d); paintDays(); paintPreview(); } }, DOW[d]); }));
    const timeBox = h('div.chips');
    const paintTimes = () => timeBox.replaceChildren(...times.map((t, i) => h('span.chip', h('input', { type: 'time', value: t, style: { border: 0, background: 'transparent', direction: 'ltr' }, onchange: (e) => { times[i] = e.target.value; paintPreview(); } }),
      h('span', { style: { cursor: 'pointer' }, onclick: () => { times.splice(i, 1); paintTimes(); paintPreview(); } }, '×'))),
      h('button.chip', { type: 'button', onclick: () => { times.push('12:00'); paintTimes(); paintPreview(); } }, '＋ وقت'));
    const orderSel = h('select.select', { style: { width: 'auto' }, onchange: (e) => { order = e.target.value; paintPreview(); } },
      h('option', { value: 'old' }, 'الأقدم اقتباسًا أولًا'), h('option', { value: 'lecture' }, 'بترتيب المحاضرة'), h('option', { value: 'random' }, 'عشوائي'));
    const prevBox = h('div.row-list', { style: { maxHeight: '220px', overflow: 'auto' } });
    let slots = [];
    function computeSlots() {
      let list = quotes.filter((q) => picked.has(q.id));
      if (order === 'old') list.sort((a, b) => a.createdAt - b.createdAt);
      else if (order === 'lecture') list.sort((a, b) => (a.videoTitle || '').localeCompare(b.videoTitle || '', 'ar') || a.start - b.start);
      else list.sort(() => Math.random() - 0.5);
      const out = []; const d = new Date(startIn.value + 'T00:00');
      const tms = [...times].filter(Boolean).sort();
      let guard = 0;
      while (out.length < list.length && guard++ < 800 && tms.length && days.size) {
        if (days.has(d.getDay())) for (const t of tms) {
          if (out.length >= list.length) break;
          const [hh, mm] = t.split(':').map(Number); const at = new Date(d); at.setHours(hh, mm, 0, 0);
          if (at.getTime() > Date.now() + 10 * 60e3) out.push({ q: list[out.length], at: at.getTime() });
        }
        d.setDate(d.getDate() + 1);
      }
      return out;
    }
    function paintPreview() {
      slots = computeSlots();
      prevBox.replaceChildren(...slots.map((s) => h('div.qd-post', h('span.num', MQ.fmtDateTime(s.at)), h('span', s.q.title || 'اقتباس'))));
      if (!slots.length) prevBox.appendChild(h('p.hint', 'اختر مقتبسات وأيامًا وأوقاتًا.'));
    }
    startIn.onchange = paintPreview;
    body.append(
      h('div.field', h('span.label', '١. المقتبسات'), h('div', { style: { display: 'flex', gap: '8px', alignItems: 'center' } }, catSel,
        h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { pool.forEach((q) => picked.add(q.id)); paintList(); paintPreview(); } }, 'تحديد الكل'),
        h('button.btn.btn-sm.btn-ghost', { type: 'button', onclick: () => { picked.clear(); paintList(); paintPreview(); } }, 'إلغاء التحديد')), listBox),
      h('div.field', h('span.label', '٢. القناة والقالب'), chBox, h('div', { style: { marginTop: '8px' } }, tplSel)),
      h('div.grid2', h('div.field', h('span.label', '٣. البداية'), startIn), h('div.field', h('span.label', 'الترتيب'), orderSel)),
      h('div.field', h('span.label', 'الأيام'), dayBox),
      h('div.field', h('span.label', 'أوقات النشر في اليوم'), timeBox),
      h('div.field', h('span.label', 'المعاينة'), prevBox));
    paintList(); paintCh(); paintDays(); paintTimes(); paintPreview();
    const prog = h('div.progress', { hidden: true }, h('div'));
    body.appendChild(prog);
    App.dialog({ title: 'خطة نشر', wide: true, body, actions: [{ label: 'اعتماد الخطة', primary: true, icon: 'calendar', onClick: async (dlg, btn) => {
      if (!slots.length) throw new Error('لا مواعيد في الخطة.');
      const tpl = tpls.find((t) => t.id === tplId);
      prog.hidden = false;
      let n = 0, errors = 0;
      for (const s of slots) {
        btn.textContent = `جارٍ الجدولة ${n + 1} من ${slots.length}…`;
        try {
          const fresh = await MQDB.get('quotes', s.q.id);
          await MQPub.schedule(fresh, ch, MQ.buildCaption(tpl ? tpl.body : '', fresh).text, s.at, { onUpload: (p) => { prog.firstElementChild.style.width = Math.round(((n + p) / slots.length) * 100) + '%'; } });
        } catch (e) { errors++; console.warn(e); }
        n++;
        prog.firstElementChild.style.width = Math.round((n / slots.length) * 100) + '%';
      }
      App.toast(errors ? `جُدول ${n - errors} وتعذّر ${errors}` : `جُدولت ${n} منشورات ✓`, 4000);
      done && done();
    } }, { label: 'إلغاء', ghost: true }] });
  }
})();
