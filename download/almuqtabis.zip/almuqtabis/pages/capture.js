// المقتبس — نافذة الالتقاط السريعة: المقطع وقصّه، العنوان، القنوات بقوالبها، ثم الحفظ أو النشر.
(() => {
  const { h, icon } = MQ;
  const $ = (id) => document.getElementById(id);
  let clip = null, meta = null, settings = null, cats = [], chosen = new Set();
  let channels = [], templates = [], picks = new Map(); // channelId -> {templateId, caption, edited, when:'now'|'later', at}
  let trimUI = null, dur = 0, busy = false, quote = null;
  const v = $('vid');

  $('closeX').appendChild(icon('x', 18));
  $('studio').append(icon('wand', 17), 'افتح في الاستوديو');

  const status = (msg, kind) => { const s = $('status'); s.textContent = msg || ''; s.className = 'status' + (kind ? ' ' + kind : ''); $('miniStatus').textContent = msg || ''; $('miniStatus').className = 'mini-st' + (kind ? ' ' + kind : ''); };
  const progress = (p) => {
    const b = $('prog'), m = $('miniProg');
    if (p == null) { b.hidden = true; m.style.setProperty('--p', 0); return; }
    b.hidden = false; b.firstElementChild.style.width = Math.round(p * 100) + '%';
    m.style.setProperty('--p', Math.round(p * 100));
  };
  const close = (toast, kind) => window.parent.postMessage({ type: 'mq:close', toast, kind }, '*');
  // الوضع المصغّر: تتقلّص النافذة إلى بطاقة صغيرة في الزاوية، فتكمل مشاهدة المحاضرة حتى ينتهي التصدير والنشر
  let mini = false;
  function setMini(on) {
    if (mini === on) return;
    mini = on;
    document.body.classList.toggle('mini', on);
    window.parent.postMessage({ type: 'mq:mini', on }, '*');
    if (on) { $('miniTitle').textContent = $('title').value.trim() || 'اقتباس'; if (v && !v.paused) v.pause(); }
  }
  $('miniExpand').append(icon('expand', 16));
  $('miniExpand').addEventListener('click', () => setMini(false));
  $('miniBtn').append(icon('minimize', 16), 'صغّر النافذة وتابع المشاهدة');
  $('miniBtn').addEventListener('click', () => setMini(true));

  window.addEventListener('message', async (e) => {
    if (e.source !== window.parent || (e.origin !== 'https://www.youtube.com' && location.protocol === 'chrome-extension:')) return;
    if (!e.data || e.data.type !== 'mq:clip' || clip) return;
    clip = e.data.blob; meta = e.data.meta;
    await init();
  });

  async function init() {
    [settings, cats, channels, templates] = await Promise.all([MQ.getSettings(), MQ.getCategories(), MQ.getChannels(), MQ.getTemplates()]);
    $('lec').textContent = [meta.videoTitle, meta.channel].filter(Boolean).join(' · ');
    $('speaker').value = meta.speaker || meta.channel || '';
    $('series').value = meta.series || '';
    v.src = URL.createObjectURL(clip);
    try { await MQEditor.prepareVideo(v); } catch (_) {}
    dur = isFinite(v.duration) && v.duration > 0 ? v.duration : meta.duration;
    trimUI = MQTrim.create($('trim'), { video: v, duration: dur, trim: { start: 0, end: dur }, onChange: () => { paintMeta(); refreshCaptions(); } });
    MQEditor.peaks(clip, 500).then((p) => p && trimUI.setPeaks(p.data));
    paintMeta(); renderCats(); renderChannels();
    $('title').focus();
  }

  function paintMeta() {
    const t = trimUI ? trimUI.trim : { start: 0, end: dur };
    $('metaLine').replaceChildren(
      h('span', 'من ', h('b.num', MQ.fmtTime(meta.start + t.start)), ' إلى ', h('b.num', MQ.fmtTime(meta.start + t.end)), ' في المحاضرة'),
      h('span', MQ.fmtSize(clip.size)),
      meta.height ? h('span.num', meta.height + 'p') : null,
    );
  }

  // ---------- التصنيفات ----------
  function renderCats() {
    const box = $('cats'); box.replaceChildren();
    if (!cats.length) box.appendChild(h('span.hint', 'لا تصنيفات بعد.'));
    cats.forEach((c) => box.appendChild(h('button.chip' + (chosen.has(c) ? '.on' : ''), { type: 'button', onclick: () => { chosen.has(c) ? chosen.delete(c) : chosen.add(c); renderCats(); refreshCaptions(); } }, c)));
  }
  $('newCat').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const val = e.target.value.trim(); if (!val) return;
    if (!cats.includes(val)) cats.push(val);
    chosen.add(val); e.target.value = ''; renderCats(); refreshCaptions();
  });

  // ---------- القنوات ----------
  function renderChannels() {
    const box = $('channels'); box.replaceChildren();
    const linked = MQ.cloudReady(settings);
    $('pubHint').textContent = channels.length ? 'اختر قناة أو أكثر، أو احفظ دون نشر' : '';
    if (!channels.length) {
      box.appendChild(h('div.note-info', icon('info'), h('span', 'لم تُضف قنوات بعد. أضفها من المنصّة ← النشر ← القنوات، ثم تظهر هنا للاختيار السريع.'),
        h('button.btn.btn-sm', { type: 'button', onclick: () => window.parent.postMessage({ type: 'mq:openApp', hash: '#/publish/channels' }, '*') }, 'إضافة قناة')));
      return;
    }
    channels.forEach((c) => {
      const on = picks.has(c.id);
      box.appendChild(h('button.chip' + (on ? '.on' : ''), { type: 'button', onclick: () => togglePick(c) },
        h('span.dot', { style: { background: c.color || MQ.CHANNEL_COLORS[0] } }), c.name));
    });
    renderPanels(linked);
  }
  function togglePick(c) {
    if (picks.has(c.id)) picks.delete(c.id);
    else picks.set(c.id, { templateId: c.templateId || 'tpl-default', caption: '', edited: false, when: 'now', at: defaultAt() });
    settings.lastChannels = [...picks.keys()];
    renderChannels();
  }
  function defaultAt() { const d = new Date(Date.now() + 3600e3); d.setMinutes(0, 0, 0); return d.getTime(); }
  const localInput = (ts) => { const d = new Date(ts); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

  function currentQuote() {
    const t = trimUI ? trimUI.trim : { start: 0, end: dur };
    return {
      title: $('title').value.trim(), desc: $('desc').value.trim(), categories: [...chosen],
      speaker: $('speaker').value.trim(), series: $('series').value.trim(),
      videoTitle: meta.videoTitle, channel: meta.channel, link: MQ.timeLink(meta.videoId, meta.start + t.start),
      duration: t.end - t.start, createdAt: Date.now(), drive: quote && quote.drive,
    };
  }
  function captionFor(pick) {
    const tpl = templates.find((x) => x.id === pick.templateId) || templates[0];
    return MQ.buildCaption(tpl ? tpl.body : '', currentQuote());
  }
  const boxes = new Map();
  function refreshCaptions() {
    for (const [id, p] of picks) {
      if (p.edited) continue;
      const b = boxes.get(id);
      if (b) b.set(captionFor(p).text);
    }
  }
  function renderPanels(linked) {
    const host = $('pubPanels'); host.replaceChildren(); boxes.clear();
    for (const [id, p] of picks) {
      const c = channels.find((x) => x.id === id); if (!c) continue;
      const sel = h('select.select', { onchange: (e) => { p.templateId = e.target.value; p.edited = false; refreshCaptions(); } },
        templates.map((t) => h('option', { value: t.id, selected: t.id === p.templateId }, t.name)));
      const box = MQ.captionBox(p.edited ? p.caption : captionFor(p).text, (val) => { p.edited = true; p.caption = val; });
      boxes.set(id, box);
      const seg = h('div.seg',
        h('button' + (p.when === 'now' ? '.on' : ''), { type: 'button', onclick: () => { p.when = 'now'; renderPanels(linked); } }, 'انشر الآن'),
        h('button' + (p.when === 'later' ? '.on' : ''), { type: 'button', onclick: () => { p.when = 'later'; renderPanels(linked); } }, 'جدولة'),
      );
      const when = h('div.pp-when', seg);
      if (p.when === 'later') {
        if (!linked) when.appendChild(h('div.lock-note', icon('lock'), h('span', 'الجدولة تعمل بعد ربط الإضافة بحساب جوجل، لأن النشر يتمّ من سحابتك ولو كان جهازك مطفأً.')));
        else when.appendChild(h('input.input', { type: 'datetime-local', value: localInput(p.at), oninput: (e) => { p.at = new Date(e.target.value).getTime() || p.at; } }));
      }
      host.appendChild(h('div.pp',
        h('div.pp-h', h('span.dot', { style: { background: c.color } }), h('b', c.name), sel),
        h('div.pp-b', box.el, when)));
    }
    paintSaveLabel();
  }
  function paintSaveLabel() {
    const now = [...picks.values()].filter((p) => p.when === 'now').length;
    const later = [...picks.values()].filter((p) => p.when === 'later').length;
    $('save').textContent = now && later ? 'حفظ ونشر وجدولة' : now ? 'حفظ ونشر' : later ? 'حفظ وجدولة' : 'حفظ';
  }
  ['title', 'desc', 'speaker', 'series'].forEach((id) => $(id).addEventListener('input', refreshCaptions));

  // ---------- الحفظ ----------
  function setBusy(on) { busy = on; $('cap').classList.toggle('busy', on); $('save').disabled = on; $('studio').disabled = on; }

  async function persist() {
    if (quote) return quote;
    const t = trimUI.trim, full = t.start < 0.05 && t.end > dur - 0.05;
    const q = {
      id: MQ.uid(), ...currentQuote(),
      videoId: meta.videoId, avatar: meta.avatar || '', playlistId: meta.playlistId || '',
      start: meta.start + t.start, end: meta.start + t.end, duration: t.end - t.start,
      createdAt: Date.now(), thumb: meta.thumb || null, captureStart: meta.start,
      edits: null, trim: { start: t.start, end: t.end }, width: meta.width, height: meta.height,
    };
    const src = { id: MQ.uid(), quoteId: q.id, kind: 'source', blob: clip, mime: clip.type, ext: meta.ext, w: meta.width, h: meta.height, duration: dur, createdAt: Date.now() };
    await MQPub.putClip(src);
    q.sourceClipId = src.id;
    if (!full) {
      status('جارٍ قصّ المقطع… (يستغرق قدر مدّته)'); progress(0);
      const url = URL.createObjectURL(clip);
      const out = await MQEditor.render({ url, edits: MQEditor.EDIT_DEFAULTS, trim: t, quality: 'max', bitrate: Number(settings.bitrate) || 10000000, onProgress: progress });
      URL.revokeObjectURL(url); progress(null);
      const fin = { id: MQ.uid(), quoteId: q.id, kind: 'final', blob: out.blob, mime: out.blob.type, ext: out.ext, w: out.W, h: out.H, duration: out.duration, createdAt: Date.now() };
      await MQPub.putClip(fin);
      q.finalClipId = fin.id;
    }
    await MQPub.saveQuote(q);
    await MQ.mergeCategories(q.categories);
    await MQ.saveSettings({ lastChannels: [...picks.keys()] });
    quote = q;
    if (settings.localCopy) {
      status('جارٍ حفظ نسخة في مجلّد التنزيلات…');
      try { await MQPub.saveLocalCopy(q, await MQPub.publishClip(q)); } catch (_) {}
    }
    if (settings.autoUploadClips && MQ.cloudReady(settings)) {
      status('جارٍ الرفع إلى درايف…'); progress(0);
      try { await MQPub.ensureDrive(await MQDB.get('quotes', q.id), progress); } catch (e) { status('حُفظ محليًّا، وتعذّر الرفع إلى درايف: ' + e.message, 'err'); }
      progress(null);
    }
    return quote;
  }

  async function doSave() {
    if (busy || !clip) return;
    setBusy(true);
    const errors = [];
    // ما يستغرق وقتًا (القصّ أو النشر) يجري في بطاقة صغيرة، وتعود أنت إلى المحاضرة
    const t0 = trimUI.trim, needsWork = picks.size || !(t0.start < 0.05 && t0.end > dur - 0.05) || settings.autoUploadClips;
    if (needsWork) setMini(true);
    try {
      const q = await persist();
      for (const [id, p] of picks) {
        if (p.done) continue;
        const c = channels.find((x) => x.id === id); if (!c) continue;
        const caption = boxes.get(id) ? boxes.get(id).value : (p.edited ? p.caption : captionFor(p).text);
        try {
          if (p.when === 'now') {
            status(`جارٍ النشر في «${c.name}»…`); progress(0);
            try {
              await MQPub.sendNow(await MQDB.get('quotes', q.id), c, caption, { onProgress: progress });
            } catch (e) {
              if (e.code !== 'TOO_BIG') throw e;
              setMini(false);
              if (!confirm(`المقطع ${MQ.fmtSize(e.size)}، وحدّ التليجرام للبوتات 50 ميغابايت.\n\nأجهّز نسخة أخفّ للإرسال فقط؟ (المحفوظ عندك يبقى بجودته)`)) throw new Error('لم يُرسل: المقطع أكبر من الحدّ.');
              await MQPub.sendNow(await MQDB.get('quotes', q.id), c, caption, { allowLight: true, onLightProgress: (x) => { progress(x); status(`جارٍ تجهيز نسخة أخفّ… ${Math.round(x * 100)}%`); }, onProgress: (x) => { progress(x); status(`جارٍ الرفع إلى «${c.name}»… ${Math.round(x * 100)}%`); } });
            }
          } else {
            if (!MQ.cloudReady(settings)) throw new Error(MQCloud.NEEDS);
            status(`جارٍ جدولة المنشور في «${c.name}»…`); progress(0);
            await MQPub.schedule(await MQDB.get('quotes', q.id), c, caption, p.at, { onUpload: (x) => { progress(x); status(`جارٍ الرفع إلى درايف للجدولة… ${Math.round(x * 100)}%`); } });
          }
          p.done = true;
        } catch (e) { errors.push(`«${c.name}»: ${e.message}`); }
        progress(null);
      }
      if (errors.length) {
        setMini(false);
        status('حُفظ الاقتباس، لكن: ' + errors.join(' — '), 'err');
        $('save').textContent = 'إعادة المحاولة';
        setBusy(false);
        return;
      }
      const n = [...picks.values()];
      const msg = n.length ? (n.some((p) => p.when === 'later') ? 'حُفظ الاقتباس وجُدول ✓' : 'حُفظ الاقتباس ونُشر ✓') : 'حُفظ الاقتباس ✓';
      status(msg, 'ok');
      setTimeout(() => close(msg, 'ok'), mini ? 1200 : 500);
    } catch (e) {
      progress(null);
      setMini(false);
      status('تعذّر الحفظ: ' + e.message, 'err');
      setBusy(false);
    }
  }
  $('save').addEventListener('click', doSave);
  $('studio').addEventListener('click', async () => {
    if (busy) return;
    setBusy(true);
    try {
      const q = await persist();
      window.parent.postMessage({ type: 'mq:openApp', hash: '#/studio/' + q.id }, '*');
      close('حُفظ الاقتباس وفُتح في الاستوديو', 'ok');
    } catch (e) { status('تعذّر الحفظ: ' + e.message, 'err'); setBusy(false); }
  });
  function onDiscard() {
    if (busy) { setMini(true); return; }
    if (quote) { close('حُفظ الاقتباس.'); return; }
    if (confirm('تجاهل هذا المقطع؟ لن يُحفظ شيء.')) close('تُجوهِل المقطع.');
  }
  $('closeX').addEventListener('click', onDiscard);
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); doSave(); return; }
    if (e.key === 'Escape') { e.preventDefault(); onDiscard(); return; }
    if (!busy && trimUI && trimUI.key(e)) e.preventDefault();
  });
})();
