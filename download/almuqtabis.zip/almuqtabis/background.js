// المقتبس — الخلفية: فتح المنصّة، خدمة البيانات لصفحة يوتيوب، والمزامنة الدورية.
importScripts('lib/common.js', 'lib/db.js', 'lib/playlist.js', 'lib/updater.js');

const APP = (hash = '') => chrome.runtime.getURL('pages/app.html') + hash;

chrome.action.onClicked.addListener(() => openApp(''));
function openApp(hash) { chrome.tabs.create({ url: APP(hash) }); }

chrome.runtime.onInstalled.addListener(async (d) => {
  await MQ.migrateV1().catch(() => {});
  await migrateQuotesV1().catch(() => {});
  chrome.alarms.create('sync', { periodInMinutes: 5 });
  if (d.reason === 'install') openApp('#/welcome');
  if (d.reason === 'update' && d.previousVersion && d.previousVersion.startsWith('1.')) openApp('#/welcome');
  else if (d.reason === 'update') {
    const { mqJustUpdated } = await chrome.storage.local.get('mqJustUpdated');
    if (mqJustUpdated) openApp('#/home');
  }
  chrome.alarms.create('update', { delayInMinutes: 1, periodInMinutes: 360 });
  checkUpdate();
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create('sync', { periodInMinutes: 5 });
  chrome.alarms.create('update', { delayInMinutes: 1, periodInMinutes: 360 });
  MQUpdate.status().then(MQUpdate.paintBadge).catch(() => {});
});

// ---------------- التحقّق من الإصدارات الجديدة ----------------
async function checkUpdate() { try { await MQUpdate.check(); } catch (_) {} }
chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'update') checkUpdate(); });

// نقل مقتبسات الإصدار الأول من التخزين البسيط إلى قاعدة البيانات
async function migrateQuotesV1() {
  const { quotes, quotesMigrated } = await chrome.storage.local.get(['quotes', 'quotesMigrated']);
  if (quotesMigrated || !Array.isArray(quotes) || !quotes.length) { await chrome.storage.local.set({ quotesMigrated: true }); return; }
  for (const q of quotes) {
    await MQDB.put('quotes', { ...q, speaker: q.speaker || q.channel || '', series: q.series || '', source: 'v1' });
  }
  await chrome.storage.local.set({ quotesMigrated: true });
}

// ---------------- سجلّ المشاهدة ----------------
async function watchGet(videoId) {
  const rec = await MQDB.get('watch', videoId);
  const notes = (await MQDB.byIndex('notes', 'videoId', videoId)).filter((n) => !n.trashed);
  const quotes = await MQDB.byIndex('quotes', 'videoId', videoId);
  const excerpt = (html) => String(html || '').replace(/<span class="ts"[^>]*>.*?<\/span>/g, '').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120);
  const series = (await MQDB.all('series')).filter((x) => (x.items || []).some((it) => it.videoId === videoId)).map((x) => ({ id: x.id, title: x.title }));
  return {
    series,
    record: rec || null,
    notes: notes.sort((a, b) => b.updatedAt - a.updatedAt).map((n) => ({ id: n.id, title: n.title, excerpt: excerpt(n.html), updatedAt: n.updatedAt, notebookId: n.notebookId })),
    quotes: quotes.length,
  };
}
async function watchPut(u) {
  const now = Date.now();
  const cur = (await MQDB.get('watch', u.videoId)) || { videoId: u.videoId, firstAt: now, watchedSec: 0, sessions: 0, completed: false, days: {} };
  const day = MQ.dayKey(now);
  const delta = Math.max(0, Math.min(60, u.delta || 0));
  const next = {
    ...cur,
    title: u.title || cur.title || '',
    channel: u.channel || cur.channel || '',
    channelUrl: u.channelUrl || cur.channelUrl || '',
    avatar: u.avatar || cur.avatar || '',
    speaker: cur.speakerEdited ? cur.speaker : (u.channel || cur.speaker || ''),
    playlistId: cur.seriesEdited ? (cur.playlistId || '') : (u.playlistId || cur.playlistId || ''),
    series: cur.seriesEdited ? cur.series : (u.playlistTitle || cur.series || ''),
    duration: u.duration || cur.duration || 0,
    position: u.position != null ? u.position : cur.position || 0,
    maxPosition: Math.max(cur.maxPosition || 0, u.position || 0),
    watchedSec: (cur.watchedSec || 0) + delta,
    lastAt: now,
    sessions: (cur.sessions || 0) + (u.newSession ? 1 : 0),
    days: { ...(cur.days || {}), [day]: ((cur.days || {})[day] || 0) + delta },
    hours: { ...(cur.hours || {}), [new Date(now).getHours()]: ((cur.hours || {})[new Date(now).getHours()] || 0) + delta },
  };
  if (u.ended) next.position = 0;
  // تنظيف الأيام الأقدم من 120 يومًا
  const keys = Object.keys(next.days).sort();
  if (keys.length > 120) keys.slice(0, keys.length - 120).forEach((k) => delete next.days[k]);
  await MQDB.put('watch', next);
  return next;
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (!msg || !msg.type) return;
  (async () => {
    switch (msg.type) {
      case 'mq:openApp': openApp(msg.hash || ''); return { ok: true };
      case 'watch:get': return watchGet(msg.videoId);
      case 'watch:put': return watchPut(msg.data);
      case 'watch:add': {
        const { ignored = [] } = await chrome.storage.local.get('ignored');
        if (ignored.includes(msg.data.videoId)) await chrome.storage.local.set({ ignored: ignored.filter((x) => x !== msg.data.videoId) });
        return watchPut({ ...msg.data, delta: 0, newSession: true });
      }
      case 'watch:remove': await MQDB.del('watch', msg.videoId); return { ok: true };
      case 'watch:complete': {
        const r = (await MQDB.get('watch', msg.videoId)) || { videoId: msg.videoId, firstAt: Date.now(), watchedSec: 0, days: {} };
        r.completed = !!msg.done; r.completedAt = msg.done ? Date.now() : 0; if (msg.done) r.position = 0;
        if (msg.meta) Object.assign(r, { title: r.title || msg.meta.title, channel: r.channel || msg.meta.channel, duration: r.duration || msg.meta.duration });
        await MQDB.put('watch', r);
        return r;
      }
      case 'watch:ignore': {
        await MQDB.del('watch', msg.videoId);
        const { ignored = [] } = await chrome.storage.local.get('ignored');
        if (!ignored.includes(msg.videoId)) ignored.push(msg.videoId);
        await chrome.storage.local.set({ ignored: ignored.slice(-500) });
        return { ok: true };
      }
      case 'transcript:put': {
        const cur = await MQDB.get('transcripts', msg.videoId);
        if (cur && cur.kind === 'manual' && msg.kind === 'asr') return { ok: true, kept: true };
        await MQDB.put('transcripts', { videoId: msg.videoId, lang: msg.lang || '', kind: msg.kind || 'asr', events: msg.events, at: Date.now() });
        return { ok: true };
      }
      case 'series:get': return (await MQDB.get('series', msg.id)) || null;
      case 'series:import': return importSeries(msg.listId, msg.fallback);
      case 'transcript:has': return { has: !!(await MQDB.get('transcripts', msg.videoId)) };
      default: return null;
    }
  })().then(reply, (e) => reply({ error: String(e && e.message || e) }));
  return true;
});

// ---------------- استيراد السلاسل ----------------
async function importSeries(listId, fallback) {
  let pl = null, err = null;
  try { pl = await MQPlaylist.fetchPlaylist(listId); } catch (e) { err = e; }
  if ((!pl || !pl.items.length) && fallback && fallback.items && fallback.items.length) pl = { id: listId, ...fallback };
  if (!pl || !pl.items.length) throw err || new Error('لم أجد محاضرات في هذه القائمة.');
  const old = await MQDB.get('series', listId);
  const rec = { ...(old || {}), id: listId, title: (old && old.titleEdited) ? old.title : pl.title, channel: pl.channel || (old && old.channel) || '',
    items: pl.items, importedAt: (old && old.importedAt) || Date.now(), updatedAt: Date.now(), lastAt: Date.now() };
  await MQDB.put('series', rec);
  MQDB.notify('series', listId);
  return rec;
}

// ---------------- المزامنة الدورية ----------------
chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name !== 'sync') return;
  const s = await MQ.getSettings();
  if (!MQ.cloudReady(s)) return;
  try {
    if (!(await chrome.offscreen.hasDocument())) {
      await chrome.offscreen.createDocument({ url: 'pages/worker.html', reasons: ['DOM_PARSER'], justification: 'تحويل التدوينات إلى مستندات ومزامنتها مع درايف' });
    }
    await chrome.runtime.sendMessage({ type: 'worker:sync', cloud: s.cloud, notes: s.autoSyncNotes });
  } catch (_) {}
});
