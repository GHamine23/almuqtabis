// المقتبس — عامل المزامنة الخفي (مستند خارج الشاشة).
let running = false;
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'worker:sync' || running) return;
  running = true;
  (async () => {
    try { if (msg.notes) await MQSync.syncDirtyNotes(msg.cloud); } catch (_) {}
    try { await MQSync.refreshQueue(msg.cloud); } catch (_) {}
    try {
      const k = await MQDB.get('kv', 'indexDirty');
      if (k && k.value) { await MQSync.pushIndex(msg.cloud); await MQDB.put('kv', { key: 'indexDirty', value: false }); }
    } catch (_) {}
  })().finally(() => { running = false; });
});
