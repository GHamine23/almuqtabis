// المقتبس — الدفتر الجانبي في يوتيوب: تدوين الملخّص والفوائد مع ختم وقت المقطع.
(() => {
  const { h, icon } = MQ;
  const $ = (id) => document.getElementById(id);
  const videoId = new URLSearchParams(location.search).get('v') || '';
  let note = null, editor = null, meta = {}, notebooks = [], settings = null, others = [];
  let lastTime = 0;

  $('close').appendChild(icon('x', 16));
  $('exportBtn').append(icon('download', 16), 'تصدير');
  $('openApp').append(icon('book', 16), 'في الكناشة');

  // ---------- التواصل مع صفحة يوتيوب ----------
  let rid = 0; const waits = new Map();
  window.addEventListener('message', (e) => {
    if (e.source !== window.parent || (e.origin !== 'https://www.youtube.com' && location.protocol === 'chrome-extension:') || !e.data) return;
    if (e.data.type === 'mq:reply' && waits.has(e.data.id)) { waits.get(e.data.id)(e.data); waits.delete(e.data.id); }
  });
  const ask = (type, payload = {}) => new Promise((r) => {
    const id = ++rid; waits.set(id, r);
    window.parent.postMessage({ type, id, ...payload }, '*');
    setTimeout(() => { if (waits.has(id)) { waits.delete(id); r(null); } }, 1500);
  });
  const post = (type, payload = {}) => window.parent.postMessage({ type, ...payload }, '*');
  // الوقت الحالي يُحدَّث دوريًّا ليكون الختم فوريًّا
  setInterval(async () => { const r = await ask('mq:getTime'); if (r) lastTime = r.t; }, 1000);

  const status = (msg, kind) => { const s = $('status'); s.textContent = msg; s.className = 'status' + (kind ? ' ' + kind : ''); };

  async function init() {
    settings = await MQ.getSettings();
    notebooks = await MQNotes.ensureDefault();
    const m = await ask('mq:meta');
    meta = (m && m.meta) || {};
    const t0 = await ask('mq:getTime'); if (t0) lastTime = t0.t;
    $('lec').replaceChildren(icon('studio'), h('span', [meta.videoTitle, meta.speaker].filter(Boolean).join(' · ')));
    others = videoId ? (await MQDB.byIndex('notes', 'videoId', videoId)).filter((n) => !n.trashed).sort((a, b) => b.updatedAt - a.updatedAt) : [];
    open(others[0] || null);
  }

  function renderNbSelect() {
    const sel = $('nb'); sel.replaceChildren();
    notebooks.forEach((nb) => sel.appendChild(h('option', { value: nb.id, selected: note && note.notebookId === nb.id }, nb.title)));
    sel.appendChild(h('option', { value: '__new' }, '＋ دفتر جديد…'));
  }
  $('nb').addEventListener('change', async (e) => {
    if (e.target.value === '__new') {
      const t = prompt('اسم الدفتر الجديد:');
      if (t && t.trim()) { const nb = await MQNotes.createNotebook(t.trim()); notebooks = await MQNotes.notebooks(); note.notebookId = nb.id; }
      renderNbSelect();
    } else note.notebookId = e.target.value;
    await MQ.saveSettings({ lastNotebook: note.notebookId });
    if (note.saved) save();
  });

  function blank() {
    const nbId = (settings.lastNotebook && notebooks.find((n) => n.id === settings.lastNotebook)) ? settings.lastNotebook : notebooks[0].id;
    return {
      id: MQ.uid(), notebookId: nbId, title: meta.videoTitle || 'تدوين', html: '', tags: [],
      videoId, videoTitle: meta.videoTitle || '', speaker: meta.speaker || meta.channel || '', series: meta.series || '',
      channel: meta.channel || '', createdAt: Date.now(), saved: false,
    };
  }

  function open(n) {
    note = n ? { ...n, saved: true } : blank();
    $('title').value = note.title || '';
    renderNbSelect(); renderTags(); renderOthers();
    $('editor').replaceChildren();
    editor = MQRich.create($('editor'), {
      html: note.html,
      autoStamp: settings.autoStamp,
      getTime: () => lastTime,
      onTimeClick: (t) => post('mq:seek', { t, play: true }),
      onChange: (html, now) => { note.html = html; save(); },
      placeholder: 'اكتب ما تستفيده… كل فقرة جديدة تُختم بوقتها في المقطع.',
    });
    $('auto').checked = settings.autoStamp;
    status(note.saved ? 'محفوظ' + (note.syncedAt ? ' · في درايف ✓' : '') : 'يُحفظ تلقائيًا عند الكتابة');
    setTimeout(() => editor.focus(), 50);
  }
  function renderOthers() {
    const box = $('others'); box.replaceChildren();
    if (others.length < 1) return;
    others.forEach((n) => box.appendChild(h('button.chip' + (note && n.id === note.id ? '.on' : ''), { type: 'button', onclick: () => open(n) }, n.title || 'تدوين')));
    box.appendChild(h('button.chip', { type: 'button', onclick: () => open(null) }, '＋ تدوين جديد'));
  }
  function renderTags() {
    const box = $('tags'); box.replaceChildren();
    (note.tags || []).forEach((t) => box.appendChild(h('span.chip.tag', '#' + t, h('span.x', { onclick: () => { note.tags = note.tags.filter((x) => x !== t); renderTags(); save(); } }, '×'))));
    const inp = h('input', { placeholder: '＋ وسم', onkeydown: (e) => {
      if (e.key !== 'Enter' && e.key !== ',') return;
      e.preventDefault();
      const v = inp.value.replace(/^#/, '').trim(); if (!v) return;
      note.tags = [...new Set([...(note.tags || []), v])]; MQ.mergeNoteTags([v]); renderTags(); save();
      setTimeout(() => box.querySelector('input').focus(), 0);
    } });
    box.appendChild(inp);
  }
  $('title').addEventListener('input', MQ.debounce(() => { note.title = $('title').value.trim(); if (note.saved || (note.html || '').trim()) save(); }, 500));
  $('auto').addEventListener('change', async (e) => { settings = await MQ.saveSettings({ autoStamp: e.target.checked }); editor.setAutoStamp(e.target.checked); });

  async function save() {
    if (!note.saved && !(note.html || '').replace(/<[^>]+>/g, '').trim()) return;
    note.title = $('title').value.trim() || note.title;
    const { saved, ...rec } = note;
    const r = await MQNotes.saveNote(rec);
    const firstSave = !note.saved;
    note = { ...r, saved: true };
    if (firstSave) { others = [note, ...others.filter((x) => x.id !== note.id)]; renderOthers(); }
    else others = others.map((x) => (x.id === note.id ? note : x));
    status('حُفظ ' + MQ.fmtClock(Date.now()) + (MQ.cloudReady(settings) && settings.autoSyncNotes ? ' · يُزامَن مع درايف' : ''), 'ok');
    post('mq:notesChanged');
  }

  $('close').onclick = () => post('mq:closeDrawer');
  $('openApp').onclick = async () => { if (note.saved) post('mq:openApp', { hash: '#/kanasha/note/' + note.id }); else post('mq:openApp', { hash: '#/kanasha' }); };
  $('exportBtn').onclick = (e) => {
    const linked = MQ.cloudReady(settings);
    const m = h('div.menu',
      h('div.menu-t', 'تصدير التدوين'),
      h('button', { disabled: !linked, onclick: async () => { m.remove(); if (!note.saved) await save(); status('جارٍ التصدير إلى مستندات جوجل…'); try { const r = await MQNotes.exportDocs(note); status('صُدّر ✓', 'ok'); window.open(r.url, '_blank'); } catch (er) { status(er.message, 'err'); } } },
        icon('doc'), linked ? 'مستندات جوجل' : 'مستندات جوجل (بعد ربط حساب جوجل)'),
      h('button', { onclick: async () => { m.remove(); if (!note.saved) await save(); await MQNotes.exportWord(note); status('نُزّل ملف وورد في مجلّد المقتطفات ✓', 'ok'); } }, icon('download'), 'ملف وورد'),
    );
    document.body.appendChild(m);
    const r = e.currentTarget.getBoundingClientRect();
    m.style.bottom = (innerHeight - r.top + 6) + 'px'; m.style.left = Math.max(8, r.left) + 'px';
    setTimeout(() => document.addEventListener('click', function off(ev) { if (!m.contains(ev.target)) { m.remove(); document.removeEventListener('click', off); } }), 0);
  };
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') post('mq:closeDrawer'); });
  init();
})();
