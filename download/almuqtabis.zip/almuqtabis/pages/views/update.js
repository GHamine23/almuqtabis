// المقتبس — واجهة التحديث: تنبيه الإصدار الجديد، والتحديث بضغطة، وما الجديد بعده.
(() => {
  const { h, icon } = MQ;
  const U = self.MQUpdate;

  const notesList = (notes) => (notes && notes.length ? h('ul.upd-notes', notes.map((n) => h('li', n))) : null);

  // نافذة التحديث
  App.updateDialog = async (rec) => {
    rec = rec || (await U.status());
    if (!rec || !rec.available) { App.toast('لديك آخر إصدار'); return; }
    const hasDir = !!(await U.savedDir());
    const bar = h('div.upd-bar', h('span'));
    const stepTx = h('div.hint', '');
    const prog = h('div.upd-prog', { hidden: true }, stepTx, bar);
    const body = h('div.upd',
      h('div.upd-ver', h('img', { src: '../assets/mark.svg', alt: '' }), h('div', h('b', 'المقتبس ' + rec.version), h('div.hint', 'لديك الآن ' + chrome.runtime.getManifest().version))),
      notesList(rec.notes),
      h('p.upd-how', 'يكتب المقتبس ملفات الإصدار الجديد في مجلّده على جهازك، ثم يعيد تشغيل نفسه. بياناتك ومقتبساتك تبقى كما هي.'),
      hasDir ? null : h('div.lock-note', icon('folder'), h('span', h('b', 'أول مرة فقط: '), 'سيطلب منك المتصفح اختيار مجلّد المقتبس — المجلّد الذي اخترته عند التثبيت، وفي داخله ملف manifest.json — ثم إذن الكتابة فيه. بعدها يكون التحديث بضغطة.')),
      prog);
    const run = async (dlg, btn) => {
      const { dir, state } = await U.ensureDir();
      if (state === 'nomanifest') throw new Error('هذا المجلّد ليس فيه ملف manifest.json؛ اختر مجلّد المقتبس نفسه.');
      if (state === 'other') throw new Error('هذا مجلّد إضافة أخرى؛ اختر مجلّد المقتبس.');
      if (state === 'differs' && !(await App.confirm('في هذا المجلّد نسخة من المقتبس غير التي تعمل الآن.\nإن كان هو المجلّد الذي ثبّتّ منه المقتبس فتابع، وإلا فاختر المجلّد الصحيح من «الإعدادات ← التحديثات».', 'تابع التحديث'))) return false;
      dlg.querySelectorAll('.dlg-foot button').forEach((b) => { b.disabled = true; });
      prog.hidden = false;
      await U.apply(dir, rec, (t, p) => { stepTx.textContent = t + '…'; bar.firstChild.style.width = Math.round(p * 100) + '%'; });
      stepTx.textContent = 'اكتمل التحديث — يُعاد تشغيل المقتبس الآن.';
      U.restart();
      return false;
    };
    App.dialog({
      title: 'إصدار جديد من المقتبس', body,
      actions: [
        { label: 'حدّث الآن', icon: 'refresh', primary: true, onClick: run },
        { label: 'نزّل الملف يدويًّا', ghost: true, onClick: () => { chrome.downloads.download({ url: U.BASE + (rec.zip || 'download/almuqtabis.zip'), filename: `almuqtabis-${rec.version}.zip` }); App.toast('بدأ التنزيل — فكّ ضغطه مكان المجلّد القديم ثم حدّث الإضافة من صفحة الإضافات.', 6000); } },
        { label: 'لاحقًا', ghost: true },
      ],
    });
  };

  // شريط في الرئيسية: إصدار جديد، أو ما الجديد بعد التحديث
  App.updateCards = async () => {
    const out = [];
    const { mqJustUpdated: j } = await chrome.storage.local.get('mqJustUpdated');
    if (j && j.to === chrome.runtime.getManifest().version) {
      const card = h('div.upd-card.done.rise', icon('check'),
        h('div', h('b', 'حُدّث المقتبس إلى ' + j.to), notesList(j.notes) || h('div.hint', 'تحديث تحسينات وإصلاحات.')),
        h('button.btn.btn-icon.sm.btn-ghost', { 'aria-label': 'إخفاء', onclick: async () => { await chrome.storage.local.remove('mqJustUpdated'); card.remove(); } }, icon('x')));
      out.push(card);
    } else if (j) await chrome.storage.local.remove('mqJustUpdated');
    const rec = await U.status();
    if (rec && rec.available && rec.skipped !== rec.version) {
      const card = h('div.upd-card.rise', icon('refresh'),
        h('div', h('b', 'إصدار جديد من المقتبس: ' + rec.version), h('div.hint', (rec.notes && rec.notes[0]) || 'تحسينات وإصلاحات.')),
        h('div.upd-a',
          h('button.btn.btn-primary.btn-sm', { onclick: () => App.updateDialog(rec) }, 'حدّث الآن'),
          h('button.btn.btn-ghost.btn-sm', { onclick: async () => { await chrome.storage.local.set({ mqUpdate: { ...rec, skipped: rec.version } }); card.remove(); } }, 'لاحقًا')));
      out.push(card);
    }
    return out;
  };

  // قسم «التحديثات» في الإعدادات
  App.updateSection = async (body, card) => {
    const v = chrome.runtime.getManifest().version;
    const st = h('div.hint');
    const act = h('div', { style: { display: 'flex', gap: '8px', flexWrap: 'wrap', marginTop: '10px' } });
    const paint = (rec) => {
      act.replaceChildren();
      if (rec && rec.available) {
        st.replaceChildren(h('b', { style: { color: 'var(--copper)' } }, 'إصدار جديد متاح: ' + rec.version), rec.checkedAt ? ' — آخر تحقّق ' + new Date(rec.checkedAt).toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' }) : '');
        act.append(h('button.btn.btn-primary', { onclick: () => App.updateDialog(rec) }, icon('refresh'), 'حدّث الآن'));
      } else st.textContent = 'لديك آخر إصدار' + (rec && rec.checkedAt ? ' — آخر تحقّق ' + new Date(rec.checkedAt).toLocaleString('ar', { dateStyle: 'medium', timeStyle: 'short' }) : '') + '.';
      act.append(h('button.btn', { onclick: async (e) => { e.target.disabled = true; try { paint(await U.check()); App.toast('تمّ التحقّق'); } catch (err) { App.toast(err.message); } finally { e.target.disabled = false; } } }, icon('search'), 'تحقّق الآن'));
    };
    paint(await U.status());
    const dir = await U.savedDir();
    const dirTx = h('span', dir ? h('b', dir.name) : 'لم يُختر بعد — يُطلب عند أول تحديث.');
    body.append(
      card('التحديثات', 'يتحقّق المقتبس من صفحته كل بضع ساعات، فإن صدر إصدار جديد ظهر تنبيه في الرئيسية وسهم على أيقونته، ويُحدَّث بضغطة.',
        h('div', h('b', { style: { fontFamily: 'var(--font-title)', fontSize: '18px' } }, 'الإصدار الحالي ' + v)), st, act),
      card('مجلّد المقتبس على جهازك', 'المجلّد الذي ثبّتّ منه المقتبس (وفيه ملف manifest.json). يكتب فيه المقتبس ملفات الإصدار الجديد.',
        h('div.upd-dir', icon('folder'), dirTx,
          h('button.btn.btn-sm', { onclick: async () => {
            try {
              const { dir: d, state } = await U.ensureDir({ pick: true });
              if (state === 'ok' || state === 'differs') { dirTx.replaceChildren(h('b', d.name)); App.toast(state === 'ok' ? 'هذا هو مجلّد المقتبس — حُفظ' : 'حُفظ، لكنه لا يطابق النسخة التي تعمل الآن تمامًا'); }
              else App.toast(state === 'other' ? 'هذا مجلّد إضافة أخرى' : 'ليس في هذا المجلّد ملف manifest.json');
            } catch (e) { if (e.name !== 'AbortError') App.toast(e.message); }
          } }, dir ? 'غيّر المجلّد' : 'اختر المجلّد'))));
  };
})();
