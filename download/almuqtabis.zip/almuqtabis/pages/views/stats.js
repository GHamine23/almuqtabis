// المقتبس — الإحصاءات: تقارير الدراسة والنشر، قابلة للتخصيص، مع نصائح وتوصيات.
(() => {
  const { h, icon } = MQ;
  const RANGES = [[7, 'أسبوع'], [30, 'شهر'], [90, 'ثلاثة أشهر'], [365, 'سنة'], [0, 'الكل']];
  const WIDGETS = [
    ['tips', 'النصائح والتوصيات'], ['study', 'الدراسة يومًا بيوم'], ['rhythm', 'إيقاعك (الأيام والساعات)'],
    ['series', 'السلاسل'], ['speakers', 'المتحدّثون'], ['quotes', 'المقتبسات والتصنيفات'], ['notes', 'الكنّاشة'], ['publish', 'النشر'],
  ];
  const WD = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

  App.views.stats = {
    title: 'الإحصاءات',
    async render(page) {
      const s = App.settings;
      const range = s.statsRange ?? 30;
      const hidden = new Set(s.statsHidden || []);
      const [watch, quotes, notes0, posts, series] = await Promise.all([MQDB.all('watch'), MQDB.all('quotes'), MQDB.all('notes'), MQDB.all('posts'), MQDB.all('series')]);
      const notes = notes0.filter((n) => !n.trashed);
      const from = range ? MQ.dayStart() - (range - 1) * 86400e3 : 0;
      const inR = (ts) => ts && ts >= from;

      const rangeSeg = h('div.seg', RANGES.map(([d, l]) => h('button' + (d === range ? '.on' : ''), { type: 'button', onclick: async () => { App.settings = await MQ.saveSettings({ statsRange: d }); App.refresh(); } }, l)));
      const custom = h('button.btn.btn-ghost', { type: 'button' }, icon('sliders'), 'تخصيص');
      custom.onclick = () => App.menu(custom, [{ title: 'الأقسام الظاهرة' }, ...WIDGETS.map(([id, l]) => ({ icon: hidden.has(id) ? 'x' : 'check', label: l, onClick: async () => {
        hidden.has(id) ? hidden.delete(id) : hidden.add(id);
        App.settings = await MQ.saveSettings({ statsHidden: [...hidden] }); App.refresh();
      } }))]);
      const printBtn = h('button.btn.btn-ghost', { type: 'button', onclick: () => window.print(), title: 'اطبع التقرير أو احفظه PDF' }, icon('download'), 'حفظ التقرير');
      page.appendChild(App.header('الإحصاءات', 'تقارير دراستك ونشرك، ونصائح بحسب ما تفعل.', [rangeSeg, custom, printBtn]));

      // ---------- الأرقام ----------
      const days = new Map(), hours = new Array(24).fill(0);
      watch.forEach((w) => {
        Object.entries(w.days || {}).forEach(([d, sec]) => { const t = new Date(d + 'T00:00').getTime(); if (!range || t >= from) days.set(d, (days.get(d) || 0) + sec); });
        Object.entries(w.hours || {}).forEach(([hr, sec]) => { hours[Number(hr)] += sec; });
      });
      const totalSec = [...days.values()].reduce((a, x) => a + x, 0);
      const activeDays = [...days.values()].filter((x) => x >= 60).length;
      const span = range || Math.max(1, Math.ceil((Date.now() - Math.min(Date.now(), ...watch.map((w) => w.firstAt || Date.now()))) / 86400e3));
      const completed = watch.filter((w) => w.completed && inR(w.completedAt));
      const started = watch.filter((w) => inR(w.firstAt));
      const qIn = quotes.filter((q) => inR(q.createdAt));
      const nIn = notes.filter((n) => inR(n.createdAt || n.updatedAt));
      const sent = posts.filter((p) => p.status === 'sent' && inR(p.sentAt || p.at));
      const streaks = streakInfo(watch);

      page.appendChild(h('div.kpis',
        kpi(MQ.fmtDur(totalSec), 'وقت الدراسة', activeDays ? `معدّل ${MQ.fmtDur(totalSec / Math.max(1, activeDays))} في يوم الدراسة` : '', true),
        kpi(`${activeDays} / ${span}`, 'أيام دراسة', `${Math.round((activeDays / span) * 100)}٪ من الأيام`),
        kpi(String(completed.length), 'محاضرة أتممتها', `بدأت ${started.length}`),
        kpi(streaks.cur ? `${streaks.cur} يوم` : '—', 'المداومة الحالية', `أطولها ${streaks.best} يوم`),
        kpi(String(qIn.length), 'مقتبسًا', `${nIn.length} تدوين`),
        kpi(String(sent.length), 'منشورًا', `${posts.filter((p) => p.status === 'scheduled').length} مجدول`)));

      const allSer = App.allSeries ? App.allSeries(watch, series) : [];
      const grid = h('div.statgrid');

      // نصائح
      if (!hidden.has('tips')) page.appendChild(h('section.tips.rise', h('h3', icon('bulb', 20), 'نصائح وتوصيات'), h('ul', tips({ watch, quotes, notes, posts, allSer, activeDays, span, totalSec, completed, streaks, hours, range }).map((t) => h('li.' + t.k, h('span', t.text), t.href ? h('a', { href: t.href }, t.cta || 'افعل') : null)))));
      page.appendChild(grid);
      const add = (id, title, body, wide) => { if (hidden.has(id) || !body) return; grid.appendChild(h('section.wcard2.rise' + (wide ? '.wide' : ''), h('h3', title), body)); };

      // الدراسة يومًا بيوم
      const nDays = Math.min(range || 90, 90);
      const series1 = [...Array(nDays)].map((_, i) => { const d = new Date(MQ.dayStart() - (nDays - 1 - i) * 86400e3); return { d, s: days.get(MQ.dayKey(d)) || 0 }; });
      add('study', `الدراسة يومًا بيوم${range > 90 || !range ? ' (آخر 90 يومًا)' : ''}`, barChart(series1.map((x) => ({ v: x.s, label: nDays <= 14 ? x.d.toLocaleDateString('ar', { weekday: 'narrow' }) : (x.d.getDate() === 1 || x.d.getDay() === 6 && nDays <= 31 ? String(x.d.getDate()) : ''), title: `${MQ.dayLabel(x.d.getTime())}: ${MQ.fmtDur(x.s)}`, today: MQ.dayKey(x.d) === MQ.dayKey() }))), true);

      // الإيقاع
      const wd = new Array(7).fill(0);
      days.forEach((sec, d) => { wd[new Date(d + 'T00:00').getDay()] += sec; });
      const wdOrder = [6, 0, 1, 2, 3, 4, 5];
      const hrsTotal = hours.reduce((a, x) => a + x, 0);
      add('rhythm', 'إيقاعك', h('div',
        h('div.subt', 'أيام الأسبوع'), hbars(wdOrder.map((i) => ({ label: WD[i], v: wd[i], text: MQ.fmtDur(wd[i]) }))),
        hrsTotal ? h('div', h('div.subt', 'ساعات اليوم'), heatHours(hours)) : h('p.hint', 'تظهر ساعات دراستك هنا بعد أيام من المشاهدة.')));

      // السلاسل
      add('series', 'السلاسل', allSer.length ? h('div.slist', allSer.slice(0, 8).map((s) => h('a.sline', { href: '#/history/series?s=' + encodeURIComponent(s.id) },
        h('span.tt', s.title), App.progressBar(s.pct, { sm: true }), h('span.hint', `${s.done}/${s.members.length}`)))) : h('p.hint', 'لا سلاسل بعد.'));

      // المتحدّثون
      const sp = new Map();
      watch.forEach((w) => { const k = w.speaker || w.channel || 'بلا اسم'; const sec = Object.entries(w.days || {}).filter(([d]) => !range || new Date(d + 'T00:00').getTime() >= from).reduce((a, [, x]) => a + x, 0); if (sec) sp.set(k, (sp.get(k) || 0) + sec); });
      add('speakers', 'من تسمع لهم أكثر', sp.size ? hbars([...sp.entries()].sort((a, b) => b[1] - a[1]).slice(0, 7).map(([k, v]) => ({ label: k, v, text: MQ.fmtDur(v) }))) : h('p.hint', 'لا مشاهدات في هذه المدّة.'));

      // المقتبسات
      const cats = new Map(); qIn.forEach((q) => (q.categories || []).forEach((c) => cats.set(c, (cats.get(c) || 0) + 1)));
      const reviewed = quotes.filter((q) => q.reviews).length;
      add('quotes', 'المقتبسات', h('div',
        h('div.mini3', mini(qIn.length, 'في المدّة'), mini(`${quotes.length ? Math.round((reviewed / quotes.length) * 100) : 0}٪`, 'راجعتَها'), mini(MQ.fmtDur(qIn.reduce((a, q) => a + (q.duration || 0), 0)), 'مجموع المدّة')),
        cats.size ? h('div', h('div.subt', 'أكثر التصنيفات'), hbars([...cats.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, v]) => ({ label: k, v, text: String(v) })))) : null));

      // الكناشة
      const words = nIn.reduce((a, n) => a + MQRich.htmlToText(n.html || '').split(/\s+/).filter(Boolean).length, 0);
      const lecturesWithNotes = new Set(notes.map((n) => n.videoId).filter(Boolean));
      const watchedIn = watch.filter((w) => inR(w.lastAt));
      add('notes', 'الكنّاشة', h('div.mini3', mini(nIn.length, 'تدوين'), mini(words.toLocaleString('ar'), 'كلمة'),
        mini(`${watchedIn.length ? Math.round((watchedIn.filter((w) => lecturesWithNotes.has(w.videoId)).length / watchedIn.length) * 100) : 0}٪`, 'محاضرات دوّنت فيها')));

      // النشر
      const byCh = new Map(); sent.forEach((p) => byCh.set(p.channelName || 'قناة', (byCh.get(p.channelName || 'قناة') || 0) + 1));
      const failed = posts.filter((p) => p.status === 'failed').length;
      const unpublished = quotes.filter((q) => !posts.some((p) => p.quoteId === q.id)).length;
      add('publish', 'النشر', h('div',
        h('div.mini3', mini(sent.length, 'نُشر'), mini(posts.filter((p) => p.status === 'scheduled').length, 'مجدول'), mini(unpublished, 'لم يُنشر بعد')),
        failed ? h('div.lock-note', { style: { marginTop: '10px' } }, icon('info'), h('span', `${failed} منشور تعذّر إرساله.`), h('a.btn.btn-sm', { href: '#/publish/queue' }, 'راجعها')) : null,
        byCh.size ? h('div', h('div.subt', 'حسب القناة'), hbars([...byCh.entries()].map(([k, v]) => ({ label: k, v, text: String(v) })))) : null));
    },
  };

  function streakInfo(watch) {
    const set = new Set();
    watch.forEach((w) => Object.entries(w.days || {}).forEach(([d, s]) => { if (s >= 60) set.add(d); }));
    let cur = 0, best = 0, run = 0;
    const today = MQ.dayStart();
    for (let i = 0; i < 400; i++) { if (set.has(MQ.dayKey(today - i * 86400e3))) cur++; else if (i) break; }
    const sorted = [...set].sort();
    let prev = null;
    sorted.forEach((d) => { const t = new Date(d + 'T00:00').getTime(); run = prev != null && Math.round((t - prev) / 86400e3) === 1 ? run + 1 : 1; best = Math.max(best, run); prev = t; });
    return { cur, best };
  }

  function tips(c) {
    const out = [];
    const inprog = c.watch.filter((w) => !w.completed && (w.maxPosition || w.position) > 60);
    if (!c.watch.length) out.push({ k: 'go', text: 'ابدأ سجلّ دراستك: افتح محاضرة واضغط «أضف إلى سجلّ الدراسة»، أو استورد سلسلة كاملة.', href: '#/history/series', cta: 'السلاسل' });
    if (c.span >= 7 && c.activeDays / c.span < 0.4) out.push({ k: 'warn', text: `درستَ ${c.activeDays} يومًا من ${c.span}. ورد يومي ثابت — ولو عشرين دقيقة — أنفع من جلسات طويلة متباعدة.` });
    if (c.streaks.cur >= 3) out.push({ k: 'ok', text: `ما شاء الله، داومتَ ${c.streaks.cur} أيام متتالية. حافظ على السلسلة اليوم.` });
    if (inprog.length >= 5) out.push({ k: 'warn', text: `عندك ${inprog.length} محاضرات بدأتها ولم تتمّها. أتمم واحدة قبل أن تبدأ جديدة.`, href: '#/history/progress', cta: 'قيد الدراسة' });
    const near = c.allSer.filter((s) => s.members.length > 2 && s.pct >= 60 && s.done < s.members.length).sort((a, b) => b.pct - a.pct)[0];
    if (near) out.push({ k: 'go', text: `بقيت لك ${near.members.length - near.done} محاضرات لتتمّ «${near.title}».`, href: '#/history/series?s=' + encodeURIComponent(near.id), cta: 'تابعها' });
    const unrev = c.quotes.filter((q) => !q.reviews).length;
    if (unrev >= 8) out.push({ k: 'go', text: `${unrev} مقتبسًا لم تراجعه بعد. المراجعة تثبّت الفائدة — جرّب خمس دقائق.`, href: '#/quotes/review', cta: 'راجع الآن' });
    const watchedRecent = c.watch.filter((w) => w.lastAt > Date.now() - 14 * 86400e3);
    const noted = new Set(c.notes.map((n) => n.videoId));
    if (watchedRecent.length >= 3 && watchedRecent.filter((w) => noted.has(w.videoId)).length / watchedRecent.length < 0.3) out.push({ k: 'tip', text: 'أغلب ما شاهدته مؤخرًا بلا تدوين. خلاصة من ثلاثة أسطر بعد كل محاضرة تحفظ لك أضعاف ما تحفظه المشاهدة وحدها.' });
    const hrsTotal = c.hours.reduce((a, x) => a + x, 0);
    if (hrsTotal > 3600) { const best = c.hours.indexOf(Math.max(...c.hours)); out.push({ k: 'tip', text: `أكثر دراستك حول الساعة ${best}:00. اجعل أثقل المواد في هذا الوقت.` }); }
    const unpub = c.quotes.filter((q) => !c.posts.some((p) => p.quoteId === q.id)).length;
    if (unpub >= 5) out.push({ k: 'tip', text: `${unpub} مقتبسًا لم يُنشر. وزّعها على الأيام القادمة بخطة نشر.`, href: '#/publish/plan', cta: 'خطة النشر' });
    if (c.posts.some((p) => p.status === 'failed')) out.push({ k: 'warn', text: 'في النشر منشورات تعذّر إرسالها.', href: '#/publish/queue', cta: 'راجعها' });
    if (!out.length) out.push({ k: 'ok', text: 'كل شيء على ما يرام. واصل — «من سلك طريقًا يلتمس فيه علمًا سهّل الله له به طريقًا إلى الجنة» (رواه مسلم).' });
    return out;
  }

  const kpi = (n, l, sub, accent) => h('div.kpi' + (accent ? '.accent' : ''), h('b', n), h('span', l), sub ? h('small', sub) : null);
  const mini = (n, l) => h('div.mini', h('b', String(n)), h('span', l));
  function barChart(items) {
    const max = Math.max(60, ...items.map((x) => x.v));
    const el = h('div.bchart', items.map((x) => h('div.b' + (x.today ? '.today' : ''), { title: x.title }, h('i', { style: { height: '0%' } }), h('span', x.label))));
    requestAnimationFrame(() => el.querySelectorAll('i').forEach((n, i) => { n.style.height = (items[i].v ? Math.max(3, (items[i].v / max) * 100) : 0) + '%'; }));
    return el;
  }
  function hbars(items) {
    const max = Math.max(1, ...items.map((x) => x.v));
    return h('div.hbars', items.map((x) => h('div.hb', h('span.l', x.label), h('div.t', h('div', { style: { width: Math.round((x.v / max) * 100) + '%' } })), h('span.v', x.text))));
  }
  function heatHours(hours) {
    const max = Math.max(1, ...hours);
    return h('div.heat', hours.map((v, i) => h('div', { title: `${i}:00 — ${MQ.fmtDur(v)}`, style: { '--a': (v / max).toFixed(2) } }, i % 3 === 0 ? h('span', String(i)) : null)));
  }
})();
