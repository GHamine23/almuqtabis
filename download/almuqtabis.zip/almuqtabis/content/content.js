// المقتبس — داخل يوتيوب: زر الاقتباس، شريط الإنجاز تحت المقطع، التذكير، الدفتر الجانبي، وضع التركيز، وسجلّ المشاهدة.
(() => {
  if (window.__mqLoaded) return;
  window.__mqLoaded = true;

  const MQ = window.MQ;
  const EXT = new URL(chrome.runtime.getURL('')).origin;
  const URLX = (p) => chrome.runtime.getURL(p);
  const SVGNS = 'http://www.w3.org/2000/svg';
  const send = (msg) => new Promise((r) => { try { chrome.runtime.sendMessage(msg, (res) => { void chrome.runtime.lastError; r(res); }); } catch (_) { r(null); } });

  let settings = { ...MQ.DEFAULTS };
  let ignored = [];
  MQ.getSettings().then((s) => { settings = s; paint(); });
  chrome.storage.local.get('ignored').then((o) => (ignored = o.ignored || []));
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.settings) MQ.getSettings().then((s) => { settings = s; paint(); });
    if (ch.ignored) ignored = ch.ignored.newValue || [];
  });

  // ================= قراءة الصفحة =================
  const isWatch = () => location.pathname === '/watch';
  const player = () => document.querySelector('#movie_player');
  const video = () => document.querySelector('#movie_player video.html5-main-video') || document.querySelector('#movie_player video');
  const vid = () => new URLSearchParams(location.search).get('v');
  const listId = () => new URLSearchParams(location.search).get('list') || '';
  const pageTitle = () => (document.querySelector('ytd-watch-metadata h1 yt-formatted-string')?.textContent || document.title.replace(/\s*-\s*YouTube\s*$/, '')).trim();
  const channelEl = () => document.querySelector('ytd-watch-metadata ytd-channel-name a') || document.querySelector('#owner ytd-channel-name a');
  const channelName = () => (channelEl()?.textContent || '').trim();
  const channelUrl = () => channelEl()?.href || '';
  const avatar = () => document.querySelector('ytd-watch-metadata #owner #avatar img, #owner yt-img-shadow img')?.src || '';
  const playlistTitle = () => {
    if (!listId()) return '';
    const el = document.querySelector('ytd-playlist-panel-renderer #header-description h3 a, ytd-playlist-panel-renderer #header-description h3 yt-formatted-string, ytd-playlist-panel-renderer .title');
    return (el?.textContent || '').trim();
  };
  const isAd = () => !!player()?.classList.contains('ad-showing');
  const meta = () => ({
    videoId: vid(), videoTitle: pageTitle(), channel: channelName(), channelUrl: channelUrl(), avatar: avatar(),
    playlistId: listId(), series: playlistTitle(),
  });

  // ================= أدوات واجهة =================
  function el(tag, cls, text) { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function ico(name, size = 18) { return MQ.icon(name, size); }
  function markImg(cls = 'mq-mark') { const i = el('img', cls); i.src = URLX('assets/mark.svg'); i.alt = ''; return i; }
  function quoteIcon() {
    const svg = document.createElementNS(SVGNS, 'svg');
    svg.setAttribute('viewBox', '0 0 36 36'); svg.setAttribute('width', '100%'); svg.setAttribute('height', '100%');
    const p = document.createElementNS(SVGNS, 'path');
    // مشكاة صغيرة فيها قبس
    p.setAttribute('d', 'M11 27V16.5c0-3.4 3.3-6.2 7-8.5 3.7 2.3 7 5.1 7 8.5V27h-2.2V16.9c0-2.2-2.1-4.3-4.8-6-2.7 1.7-4.8 3.8-4.8 6V27z');
    p.setAttribute('fill', 'currentColor');
    const f = document.createElementNS(SVGNS, 'path');
    f.setAttribute('d', 'M18 25.6c-1.9 0-3.1-1.2-3.1-2.9 0-1.8 1.4-2.7 1.9-4.5.3.9.8 1.4 1.3 1.7.3-1.3.8-2.5 1.7-3.3.1 1.7 1.4 3 1.4 5.2 0 2.5-1.3 3.8-3.2 3.8z');
    f.setAttribute('fill', '#D9A65A'); f.setAttribute('class', 'mq-flame');
    const dot = document.createElementNS(SVGNS, 'circle');
    dot.setAttribute('cx', '27.5'); dot.setAttribute('cy', '10'); dot.setAttribute('r', '3'); dot.setAttribute('class', 'mq-dot');
    svg.append(p, f, dot);
    return svg;
  }
  function toast(msg, kind, ms = 3200) {
    const host = player() || document.body;
    const t = el('div', 'mq-toast' + (kind ? ' mq-toast-' + kind : ''), msg);
    host.appendChild(t);
    requestAnimationFrame(() => t.classList.add('mq-show'));
    setTimeout(() => { t.classList.remove('mq-show'); setTimeout(() => t.remove(), 300); }, ms);
  }

  // ================= الحالة =================
  const st = {
    phase: 'idle', cdTimer: null, cdEl: null,
    recorder: null, chunks: [], mime: '', ext: 'webm', video: null, stream: null,
    start: 0, end: 0, activeMs: 0, lastResume: 0, paused: false, prevRate: null, thumb: null, meta: null,
    recEl: null, tick: null, onPause: null, onPlay: null, onEnded: null,
    modal: null, wasPlaying: false,
    // سجل المشاهدة
    cur: null, info: null, delta: 0, lastTick: 0, lastSend: 0, newSession: false, reminded: false,
    drawer: null, focus: false, focusTheater: false,
  };

  // ================= زر المشغّل =================
  function ensurePlayerButton() {
    const p = player(); if (!p) return;
    const ctrls = p.querySelector('.ytp-right-controls');
    if (ctrls && !ctrls.querySelector('.mq-btn')) {
      const b = el('button', 'ytp-button mq-btn');
      b.setAttribute('aria-label', 'المقتبس');
      b.appendChild(quoteIcon());
      b.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); toggleCapture(); });
      ctrls.prepend(b);
    }
    paintButton();
  }
  function paintButton() {
    const label = MQ.shortcutLabel(settings.shortcut);
    const titles = { idle: `المقتبس: ابدأ الاقتباس (${label})`, countdown: 'إلغاء العدّ', recording: `إيقاف التسجيل (${label})`, saving: 'جارٍ التجهيز…', editing: 'نافذة الحفظ مفتوحة' };
    document.querySelectorAll('.mq-btn').forEach((b) => { b.dataset.phase = st.phase; b.title = titles[st.phase] || ''; });
    const q = document.querySelector('.mq-bar [data-act="quote"]');
    if (q) { q.dataset.phase = st.phase; q.querySelector('span').textContent = st.phase === 'recording' ? 'إيقاف التسجيل' : st.phase === 'countdown' ? 'إلغاء' : 'اقتباس'; }
  }
  function setPhase(p) { st.phase = p; paintButton(); const b = document.querySelector('.mq-bar'); if (b) paintBarTail(b); }

  // ================= شريط المقتبس تحت المقطع =================
  // الأصل: زرّ مختصر بجانب «أعجبني» يفتح لوحة المقتبس؛ ويصير شريطًا كاملًا تحت المقطع إن اختير ذلك أو في وضع التركيز
  const barInline = () => st.focus || settings.barMode === 'bar';
  function actionsHost() {
    return document.querySelector('ytd-watch-metadata #top-level-buttons-computed') ||
      document.querySelector('ytd-watch-metadata #actions-inner #menu') || document.querySelector('ytd-watch-metadata #actions');
  }
  function ensurePill() {
    const host = actionsHost();
    let pill = document.querySelector('.mq-pill');
    if (!host) return pill;
    if (!pill) {
      pill = el('button', 'mq-pill'); pill.type = 'button'; pill.dir = 'rtl';
      const ring = el('span', 'mq-pill-ring'); ring.appendChild(markImg('mq-pill-mark'));
      pill.append(ring, el('span', 'mq-pill-txt', 'المقتبس'), el('em', 'mq-pill-dot'));
      pill.title = 'المقتبس: الاقتباس، الدفتر، سجلّ الدراسة';
      pill.addEventListener('click', (e) => { e.preventDefault(); e.stopPropagation(); togglePop(); });
    }
    if (pill.parentElement !== host) host.prepend(pill);
    return pill;
  }
  function togglePop(force) {
    const bar = document.querySelector('.mq-bar'); if (!bar || barInline()) return;
    const open = force != null ? force : !st.popOpen;
    st.popOpen = open;
    bar.classList.toggle('mq-open', open);
    document.querySelector('.mq-pill')?.classList.toggle('mq-on', open);
    if (open) { placePop(); document.querySelector('.mq-pill')?.classList.remove('mq-attn'); }
  }
  function placePop() {
    const bar = document.querySelector('.mq-bar.mq-pop'), pill = document.querySelector('.mq-pill');
    if (!bar || !pill || !st.popOpen) return;
    const r = pill.getBoundingClientRect();
    const w = Math.min(460, innerWidth - 24);
    bar.style.width = w + 'px';
    let left = r.right - w; if (left < 12) left = 12; if (left + w > innerWidth - 12) left = innerWidth - 12 - w;
    bar.style.left = (left + scrollX) + 'px';
    bar.style.top = (r.bottom + scrollY + 8) + 'px';
  }
  window.addEventListener('resize', placePop);
  document.addEventListener('pointerdown', (e) => {
    if (!st.popOpen) return;
    if (e.target.closest && (e.target.closest('.mq-bar') || e.target.closest('.mq-pill'))) return;
    togglePop(false);
  }, true);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && st.popOpen) togglePop(false); }, true);
  function placeBar(bar) {
    const below = document.querySelector('ytd-watch-flexy #below');
    const pill = barInline() ? null : ensurePill();
    if (barInline() || !pill) {
      bar.classList.remove('mq-pop', 'mq-open'); st.popOpen = false;
      document.querySelector('.mq-pill')?.remove();
      if (below && bar.parentElement !== below) below.prepend(bar);
    } else {
      bar.classList.add('mq-pop');
      if (bar.parentElement !== document.documentElement) document.documentElement.appendChild(bar);
    }
  }
  function ensureBar() {
    if (!isWatch()) { document.querySelector('.mq-bar')?.remove(); document.querySelector('.mq-pill')?.remove(); st.popOpen = false; return; }
    const below = document.querySelector('ytd-watch-flexy #below');
    if (!below) return;
    let bar = document.querySelector('.mq-bar');
    if (!bar) {
      bar = el('div', 'mq-bar');
      bar.dir = 'rtl';
      const brand = el('a', 'mq-bar-brand'); brand.title = 'افتح منصّة المقتبس'; brand.href = '#';
      brand.appendChild(markImg());
      brand.addEventListener('click', (e) => { e.preventDefault(); send({ type: 'mq:openApp', hash: '#/history' }); });
      const prog = el('div', 'mq-bar-prog');
      const ring = el('div', 'mq-ring'); ring.appendChild(el('span'));
      const txt = el('div', 'mq-bar-txt');
      prog.append(ring, txt);
      const ask = el('div', 'mq-ask');
      const add = el('div', 'mq-add');
      const actions = el('div', 'mq-bar-actions');
      const mk = (act, icon, label, extra) => {
        const b = el('button', 'mq-chipbtn'); b.dataset.act = act; b.type = 'button';
        b.append(ico(icon, 17), el('span', '', label));
        if (extra) b.appendChild(extra);
        b.addEventListener('click', () => onBarAction(act));
        return b;
      };
      actions.append(
        mk('notes', 'notebook', 'الدفتر', el('em', 'mq-count')),
        mk('quote', 'scissors', 'اقتباس'),
        mk('focus', 'focus', 'وضع التركيز'),
      );
      bar.append(brand, prog, add, ask, actions);
    }
    placeBar(bar);
    paintBar();
  }

  function paintBar() {
    const bar = document.querySelector('.mq-bar'); if (!bar) return;
    const rec = st.cur && st.cur.record;
    const v = video();
    const dur = (v && isFinite(v.duration) && v.duration) || (rec && rec.duration) || 0;
    const pos = v ? v.currentTime : 0;
    const watched = rec ? Math.max(rec.maxPosition || 0, pos) : pos;
    const pct = dur ? Math.min(100, Math.round((watched / dur) * 100)) : 0;
    const done = !!(rec && rec.completed);
    bar.classList.toggle('mq-done', done);
    const ring = bar.querySelector('.mq-ring');
    ring.style.setProperty('--p', done ? 100 : pct);
    const txt = bar.querySelector('.mq-bar-txt');
    txt.replaceChildren();
    if (done) txt.append(el('b', '', 'أتممتَ مشاهدته'), el('small', '', rec.completedAt ? MQ.relTime(rec.completedAt) : ''));
    else {
      if (!isAdded()) { txt.append(el('b', '', 'خارج سجلّ الدراسة'), el('small', '', 'لا تُحفظ مشاهدته')); }
      else txt.append(el('b', '', dur ? `شاهدتَ ${pct}٪` : 'سجلّ المشاهدة'));
      if (!isAdded()) { /* لا شيء */ } else
      if (rec && rec.position > 30 && Math.abs(rec.position - pos) > 20 && !st.resumedFrom) {
        const r = el('button', 'mq-link', `توقّفتَ عند ${MQ.fmtTime(rec.position)}`);
        r.addEventListener('click', () => { const vv = video(); if (vv) { vv.currentTime = rec.position; vv.play().catch(() => {}); st.resumedFrom = true; paintBar(); } });
        txt.appendChild(r);
      } else if (rec && rec.series) txt.appendChild(el('small', '', rec.series));
      else txt.appendChild(el('small', '', dur ? `من ${MQ.fmtTime(dur)}` : ''));
    }
    const ask = bar.querySelector('.mq-ask');
    ask.replaceChildren();
    const add = bar.querySelector('.mq-add');
    add.replaceChildren();
    const added = isAdded();
    bar.classList.toggle('mq-untracked', !added);
    if (!added) {
      const b = el('button', 'mq-addbtn'); b.type = 'button';
      b.append(ico('plus', 15), el('span', '', 'أضف إلى سجلّ الدراسة'));
      b.title = 'تُحفظ مشاهدتك وموضع توقّفك، وتظهر في سجلّ الإنجاز والإحصاءات';
      b.addEventListener('click', () => addToRecord(true));
      add.appendChild(b);
    }
    if (listId() && !st.listImported) {
      const b = el('button', 'mq-link mq-import'); b.type = 'button';
      b.append(ico('playlist', 15), el('span', '', 'استورد السلسلة كاملة'));
      b.title = 'تُضاف محاضرات قائمة التشغيل كلها إلى سجلّ الدراسة، وترى تقدّمك فيها';
      b.addEventListener('click', importSeries);
      add.appendChild(b);
    }
    if (!added) { paintButton(); return paintBarTail(bar); }
    if (done) {
      const u = el('button', 'mq-link mq-muted', 'تراجع');
      u.addEventListener('click', () => setComplete(false));
      ask.append(el('span', 'mq-ok', '✓'), u);
    } else {
      const near = pct >= 85;
      ask.classList.toggle('mq-near', near);
      ask.append(el('span', '', 'هل أتممتَ المشاهدة؟'));
      const y = el('button', 'mq-yes'); y.append(ico('check', 15), el('span', '', 'نعم'));
      y.addEventListener('click', () => setComplete(true));
      ask.appendChild(y);
    }
    paintBarTail(bar);
  }
  function paintBarTail(bar) {
    const pill = document.querySelector('.mq-pill');
    if (pill) {
      const rec = st.cur && st.cur.record;
      const v = video();
      const dur = (v && isFinite(v.duration) && v.duration) || (rec && rec.duration) || 0;
      const pct = rec ? (rec.completed ? 100 : dur ? Math.min(100, Math.round((Math.max(rec.maxPosition || 0, v ? v.currentTime : 0) / dur) * 100)) : 0) : 0;
      pill.style.setProperty('--p', pct);
      pill.classList.toggle('mq-tracked', !!rec || !!settings.autoTrack);
      pill.classList.toggle('mq-done', !!(rec && rec.completed));
      pill.dataset.phase = st.phase;
      pill.querySelector('.mq-pill-txt').textContent = st.phase === 'recording' ? 'يسجّل…' : st.phase === 'countdown' ? 'استعدّ…' : 'المقتبس';
      pill.querySelector('.mq-pill-dot').textContent = st.cur && st.cur.notes.length ? String(st.cur.notes.length) : '';
    }
    const count = bar.querySelector('.mq-count');
    const n = st.cur ? st.cur.notes.length : 0;
    count.textContent = n ? String(n) : '';
    bar.querySelector('[data-act="notes"]').classList.toggle('mq-on', !!st.drawer);
    bar.querySelector('[data-act="focus"]').classList.toggle('mq-on', st.focus);
    paintButton();
  }

  async function setComplete(done) {
    const id = vid(); if (!id) return;
    const r = await send({ type: 'watch:complete', videoId: id, done, meta: { title: pageTitle(), channel: channelName(), duration: video()?.duration || 0 } });
    if (st.cur) st.cur.record = r; else st.cur = { record: r, notes: [], quotes: 0 };
    paintBar();
    if (done) toast('سُجّلت المحاضرة في إنجازك ✓', 'ok');
  }

  function onBarAction(act) {
    if (act === 'notes') toggleDrawer();
    if (act === 'quote') toggleCapture();
    if (act === 'focus') toggleFocus();
  }

  // ================= التذكير عند الفتح =================
  function remind() {
    if (st.reminded || !st.cur) return;
    st.reminded = true;
    const rec = st.cur.record, notes = st.cur.notes;
    const v = video();
    const items = [];
    if (settings.remindResume && rec && !rec.completed && rec.position > 30 && (!rec.duration || rec.position < rec.duration - 20) && v && Math.abs(v.currentTime - rec.position) > 20) {
      items.push({ icon: 'clock', text: `آخر مرة توقّفتَ عند ${MQ.fmtTime(rec.position)}`, btn: 'تابع من هنا', act: () => { v.currentTime = rec.position; v.play().catch(() => {}); st.resumedFrom = true; paintBar(); } });
    }
    if (settings.remindNotes && notes.length) {
      const n = notes[0];
      items.push({ icon: 'notebook', text: notes.length > 1 ? `لك ${notes.length} تدوينات في هذا المقطع` : `كتبتَ فيه: «${(n.excerpt || n.title || '').slice(0, 70)}${(n.excerpt || '').length > 70 ? '…' : ''}»`, btn: 'افتح الدفتر', act: () => openDrawer() });
    }
    if (rec && rec.completed) items.push({ icon: 'check', text: 'أتممتَ مشاهدة هذا المقطع من قبل', btn: null });
    if (!items.length) return;
    const host = player(); if (!host) return;
    const card = el('div', 'mq-remind');
    card.dir = 'rtl';
    const head = el('div', 'mq-remind-h'); head.append(markImg('mq-mark sm'), el('span', '', 'المقتبس يذكّرك'));
    const x = el('button', 'mq-x'); x.appendChild(ico('x', 14)); x.addEventListener('click', () => close());
    head.appendChild(x);
    card.appendChild(head);
    items.forEach((it) => {
      const row = el('div', 'mq-remind-row');
      row.append(ico(it.icon, 16), el('span', '', it.text));
      if (it.btn) { const b = el('button', 'mq-remind-btn', it.btn); b.addEventListener('click', () => { it.act(); close(); }); row.appendChild(b); }
      card.appendChild(row);
    });
    host.appendChild(card);
    requestAnimationFrame(() => card.classList.add('mq-show'));
    const timer = setTimeout(close, 14000);
    function close() { clearTimeout(timer); card.classList.remove('mq-show'); setTimeout(() => card.remove(), 350); }
  }

  // ================= سجلّ المشاهدة =================
  async function loadVideoState(keep) {
    const id = vid();
    if (!id) return;
    if (!keep) { st.info = id; st.reminded = false; st.resumedFrom = false; st.newSession = true; st.delta = 0; st.lastTick = 0; }
    st.cur = (await send({ type: 'watch:get', videoId: id })) || { record: null, notes: [], quotes: 0, series: [] };
    if (!st.cur.series) st.cur.series = [];
    if (listId()) { const r = await send({ type: 'series:get', id: listId() }); st.listImported = !!(r && r.id); } else st.listImported = false;
    if (st.info !== id) return;
    paintBar();
    setTimeout(remind, 1800);
  }
  function trackable() {
    const v = video();
    if (!settings.tracking || !isWatch() || !v || isAd()) return false;
    if (ignored.includes(vid())) return false;
    if (!isAdded()) return false;
    if (settings.autoTrack && !(st.cur && st.cur.record) && isFinite(v.duration) && v.duration < (settings.trackMinSeconds || 0)) return false;
    return true;
  }
  // هل المحاضرة في سجلّ الدراسة؟ (أضفتَها، أو من سلسلة استوردتَها، أو الإضافة التلقائية مفعّلة)
  const isAdded = () => !!(settings.autoTrack || (st.cur && (st.cur.record || (st.cur.series && st.cur.series.length))));
  async function addToRecord(on) {
    const id = vid(); const v = video(); if (!id) return;
    if (on) {
      const ser = st.cur && st.cur.series && st.cur.series[0];
      const rec = await send({ type: 'watch:add', data: { videoId: id, title: pageTitle(), channel: channelName(), channelUrl: channelUrl(), avatar: avatar(),
        playlistId: listId() || (ser && ser.id) || '', playlistTitle: playlistTitle() || (ser && ser.title) || '',
        duration: v && isFinite(v.duration) ? v.duration : 0, position: v ? v.currentTime : 0 } });
      if (!st.cur) st.cur = { record: null, notes: [], quotes: 0, series: [] };
      st.cur.record = rec; st.lastTick = 0;
      toast('أُضيفت المحاضرة إلى سجلّ دراستك ✓', 'ok');
    } else {
      await send({ type: 'watch:remove', videoId: id });
      if (st.cur) st.cur.record = null;
      toast('أُزيلت من سجلّ الدراسة');
    }
    paintBar();
  }
  async function importSeries() {
    const l = listId(); if (!l) return;
    toast('أستورد السلسلة…', null, 2000);
    const fallback = { title: playlistTitle(), channel: channelName(), items: [...document.querySelectorAll('ytd-playlist-panel-renderer ytd-playlist-panel-video-renderer')].map((n, i) => {
      const a = n.querySelector('a#wc-endpoint, a'); let v = '';
      try { v = new URL(a.href, location.origin).searchParams.get('v') || ''; } catch (_) {}
      const t = (n.querySelector('#video-title')?.textContent || '').trim();
      const len = (n.querySelector('ytd-thumbnail-overlay-time-status-renderer #text, .badge-shape-wiz__text, #time-status #text')?.textContent || '').trim();
      return { videoId: v, title: t, duration: len.split(':').map(Number).reduce((x, y) => x * 60 + (y || 0), 0), channel: '', index: i + 1 };
    }).filter((x) => x.videoId) };
    const r = await send({ type: 'series:import', listId: l, fallback });
    if (!r || r.error) { toast((r && r.error) || 'تعذّر استيراد السلسلة.', 'err', 4500); return; }
    toast(`استُوردت «${r.title}» — ${r.items.length} محاضرة في سجلّ الدراسة ✓`, 'ok', 4000);
    loadVideoState(true);
  }
  const serOf = () => (st.cur && st.cur.series && st.cur.series[0]) || { id: '', title: '' };
  async function flush(extra = {}) {
    if (!trackable() && !(extra.ended && isAdded() && settings.tracking)) return;
    const v = video(); const id = vid();
    if (!v || !id) return;
    const data = {
      videoId: id, title: pageTitle(), channel: channelName(), channelUrl: channelUrl(), avatar: avatar(),
      playlistId: listId() || serOf().id, playlistTitle: playlistTitle() || serOf().title,
      duration: isFinite(v.duration) ? v.duration : 0, position: v.currentTime, delta: st.delta, newSession: st.newSession, ...extra,
    };
    st.delta = 0; st.newSession = false; st.lastSend = Date.now();
    const rec = await send({ type: 'watch:put', data });
    if (rec && st.cur && vid() === id) { st.cur.record = rec; paintBar(); }
  }
  setInterval(() => {
    const v = video();
    const now = performance.now();
    if (v && !v.paused && !v.ended && trackable() && document.visibilityState !== 'hidden') {
      if (st.lastTick) st.delta += Math.min(5, (now - st.lastTick) / 1000);
      st.lastTick = now;
      if (Date.now() - st.lastSend > 15000) flush();
      paintBar();
    } else st.lastTick = 0;
  }, 2000);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
  window.addEventListener('pagehide', () => flush());
  document.addEventListener('pause', (e) => { if (e.target === video()) { flush(); paintBar(); } }, true);
  document.addEventListener('ended', (e) => { if (e.target === video()) { flush({ ended: true }); maybeAskDone(); } }, true);
  function maybeAskDone() {
    const ask = document.querySelector('.mq-ask');
    if (ask && !(st.cur && st.cur.record && st.cur.record.completed)) {
      ask.classList.add('mq-near', 'mq-pulse');
      if (barInline()) ask.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      else document.querySelector('.mq-pill')?.classList.add('mq-attn');
    }
  }

  // ================= الدفتر الجانبي =================
  function toggleDrawer() { st.drawer ? closeDrawer() : openDrawer(); }
  function openDrawer() {
    if (st.drawer) return;
    const wrap = el('div', 'mq-drawer');
    const frame = document.createElement('iframe');
    frame.className = 'mq-drawer-frame';
    frame.src = URLX('pages/notes.html') + '?v=' + encodeURIComponent(vid() || '');
    frame.allow = 'clipboard-read; clipboard-write';
    wrap.appendChild(frame);
    document.documentElement.appendChild(wrap);
    st.drawer = { wrap, frame };
    document.documentElement.classList.add('mq-drawer-open');
    requestAnimationFrame(() => { wrap.classList.add('mq-show'); window.dispatchEvent(new Event('resize')); });
    paintBar();
  }
  function closeDrawer() {
    if (!st.drawer) return;
    const { wrap } = st.drawer; st.drawer = null;
    wrap.classList.remove('mq-show');
    document.documentElement.classList.remove('mq-drawer-open');
    setTimeout(() => { wrap.remove(); window.dispatchEvent(new Event('resize')); }, 280);
    paintBar();
    loadNotesCount();
  }
  async function loadNotesCount() {
    const id = vid(); if (!id) return;
    const r = await send({ type: 'watch:get', videoId: id });
    if (r && st.cur && vid() === id) { st.cur.notes = r.notes; paintBar(); }
  }

  // ================= وضع التركيز =================
  function toggleFocus(force) {
    const on = force != null ? force : !st.focus;
    if (on === st.focus) return;
    st.focus = on;
    const flexy = document.querySelector('ytd-watch-flexy');
    if (on) {
      st.focusTheater = flexy && !flexy.hasAttribute('theater');
      if (st.focusTheater) document.querySelector('.ytp-size-button')?.click();
      document.documentElement.classList.add('mq-focus');
      toast('وضع التركيز — اضغط Esc أو الزرّ نفسه للخروج', null, 2600);
    } else {
      document.documentElement.classList.remove('mq-focus');
      if (st.focusTheater && flexy && flexy.hasAttribute('theater')) document.querySelector('.ytp-size-button')?.click();
    }
    const bar = document.querySelector('.mq-bar'); if (bar) placeBar(bar);
    setTimeout(() => window.dispatchEvent(new Event('resize')), 60);
    paintBar();
  }

  // ================= الاختصارات =================
  window.addEventListener('keydown', (e) => {
    if (!isWatch() || e.repeat) return;
    const t = e.target;
    const typing = t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName));
    if (e.key === 'Escape' && st.focus && !typing) { toggleFocus(false); return; }
    if (typing) return;
    if (MQ.matchShortcut(e, settings.shortcut)) { e.preventDefault(); e.stopPropagation(); toggleCapture(); }
  }, true);

  // ================= التقاط الترجمة =================
  const capWait = new Map();
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data) return;
    if (e.data.__mq === 'captions') onCaptions(e.data.url, e.data.body);
    if (e.data.__mq === 'captionsInfo') st.capInfo = e.data;
  });
  function parseCaptions(body) {
    const txt = String(body || '').trim();
    if (!txt) return null;
    if (txt.startsWith('{')) { try { return window.MQText.fromJson3(JSON.parse(txt)); } catch (_) { return null; } }
    if (txt.startsWith('<')) {
      try {
        const d = new DOMParser().parseFromString(txt, 'text/xml');
        const ps = [...d.querySelectorAll('p')];
        const events = ps.map((p) => {
          const s = Number(p.getAttribute('t') || 0) / 1000, dd = Number(p.getAttribute('d') || 2000) / 1000;
          const segs = [...p.querySelectorAll('s')];
          const words = segs.length ? segs.map((sg) => ({ t: s + Number(sg.getAttribute('t') || 0) / 1000, w: sg.textContent.trim() })).filter((w) => w.w) : [];
          return { s, e: s + dd, text: p.textContent.replace(/\s+/g, ' ').trim(), words };
        }).filter((x) => x.text);
        return events.length ? events : null;
      } catch (_) { return null; }
    }
    return null;
  }
  async function onCaptions(url, body) {
    const u = new URL(url, location.origin);
    const id = u.searchParams.get('v') || vid();
    const events = parseCaptions(body);
    if (!id || !events || !events.length) return;
    const lang = u.searchParams.get('lang') || u.searchParams.get('tlang') || '';
    const kind = u.searchParams.get('kind') === 'asr' ? 'asr' : 'manual';
    await send({ type: 'transcript:put', videoId: id, lang, kind, events });
    const w = capWait.get(id); if (w) { w(true); capWait.delete(id); }
  }
  async function ensureCaptions() {
    const id = vid(); if (!id) return false;
    const has = await send({ type: 'transcript:has', videoId: id });
    if (has && has.has) return true;
    const p = new Promise((r) => { capWait.set(id, r); setTimeout(() => { if (capWait.get(id) === r) { capWait.delete(id); r(false); } }, 9000); });
    window.postMessage({ __mq: 'cmd', cmd: 'loadCaptions', lang: settings.captionsLang || 'ar', restore: true }, location.origin);
    return p;
  }

  // ================= الاقتباس =================
  function toggleCapture() {
    if (!isWatch()) return;
    if (st.phase === 'idle') startCountdown();
    else if (st.phase === 'countdown') cancelCountdown();
    else if (st.phase === 'recording') stopRecording('user');
  }
  function startCountdown() {
    const v = video();
    if (!v || !v.currentSrc) { toast('لم أجد الفيديو. شغّل المحاضرة أولًا.', 'err'); return; }
    if (typeof v.captureStream !== 'function') { toast('هذا المتصفح لا يدعم التسجيل من المشغّل.', 'err'); return; }
    ensureCaptions();
    if (settings.lockQuality) window.postMessage({ __mq: 'cmd', cmd: 'lockQuality' }, location.origin);
    let n = MQ.clamp(Number(settings.countdown) || 0, 0, 10);
    if (n === 0) { startRecording(); return; }
    setPhase('countdown');
    const wrap = el('div', 'mq-countdown');
    const num = el('div', 'mq-cd-num', String(n));
    wrap.append(num, el('div', 'mq-cd-hint', 'يبدأ التسجيل بعد العدّ — اضغط مرة أخرى للإلغاء'));
    if (v.videoHeight && v.videoHeight < 1080) wrap.appendChild(el('div', 'mq-cd-hint mq-cd-warn', `الجودة الآن ${v.videoHeight}p — ارفعها من إعدادات المشغّل إن أمكن`));
    (player() || document.body).appendChild(wrap);
    st.cdEl = wrap;
    st.cdTimer = setInterval(() => {
      n -= 1;
      if (n <= 0) { clearInterval(st.cdTimer); st.cdTimer = null; wrap.remove(); st.cdEl = null; startRecording(); }
      else { num.textContent = String(n); num.classList.remove('mq-pop'); void num.offsetWidth; num.classList.add('mq-pop'); }
    }, 1000);
  }
  function cancelCountdown() { clearInterval(st.cdTimer); st.cdTimer = null; st.cdEl?.remove(); st.cdEl = null; setPhase('idle'); unlockQuality(); toast('أُلغي الاقتباس'); }
  function unlockQuality() { if (settings.lockQuality) window.postMessage({ __mq: 'cmd', cmd: 'unlockQuality' }, location.origin); }

  function grabThumb(v) {
    try {
      const w = 480, hh = Math.round((v.videoHeight / v.videoWidth) * w) || 270;
      const c = document.createElement('canvas'); c.width = w; c.height = hh;
      c.getContext('2d').drawImage(v, 0, 0, w, hh);
      return c.toDataURL('image/jpeg', 0.75);
    } catch (_) { return null; }
  }

  async function startRecording() {
    const v = video();
    if (!v) { setPhase('idle'); toast('لم أجد الفيديو.', 'err'); return; }
    try { if (v.paused) await v.play(); } catch (_) {}
    let stream;
    try { stream = v.captureStream(); } catch (_) { setPhase('idle'); toast('تعذّر التقاط الفيديو (قد يكون محميًّا).', 'err'); return; }
    if (!stream.getVideoTracks().length) {
      await new Promise((r) => setTimeout(r, 300));
      if (!stream.getVideoTracks().length) { setPhase('idle'); toast('لم يصل بثّ الصورة من المشغّل. أعد المحاولة.', 'err'); return; }
    }
    const { m, ext } = pickMime();
    let rec;
    try { rec = new MediaRecorder(stream, { ...(m ? { mimeType: m } : {}), videoBitsPerSecond: Number(settings.bitrate) || 10000000, audioBitsPerSecond: 192000 }); }
    catch (err) { setPhase('idle'); toast('تعذّر تشغيل المسجّل: ' + (err.message || err), 'err'); return; }
    Object.assign(st, {
      video: v, stream, recorder: rec, chunks: [], mime: (m || rec.mimeType || 'video/webm').split(';')[0], ext,
      start: v.currentTime, end: v.currentTime, activeMs: 0, lastResume: performance.now(), paused: false,
      thumb: grabThumb(v), meta: { ...meta(), width: v.videoWidth, height: v.videoHeight, duration: v.duration },
    });
    if (settings.forceNormalSpeed && v.playbackRate !== 1) { st.prevRate = v.playbackRate; v.playbackRate = 1; } else st.prevRate = null;
    rec.ondataavailable = (e) => { if (e.data && e.data.size) st.chunks.push(e.data); };
    rec.onstop = finalize;
    rec.onerror = () => { toast('توقّف التسجيل بسبب خطأ.', 'err'); stopRecording('error'); };
    // يتوقّف المسجّل كلما توقّفت الصورة: إيقاف مؤقّت، أو انتظار تحميل (تقطيع الشبكة)، أو قفز في المقطع.
    // بغير هذا يسجّل المسجّل الإطار الأخير ثابتًا طوال مدة التحميل، فتبدو الصورة «معلّقة» في المقطع.
    st.stalls = 0; st.resizes = 0;
    const hold = (why) => {
      if (rec.state !== 'recording') return;
      rec.pause(); st.activeMs += performance.now() - st.lastResume; st.paused = true; st.holdWhy = why;
      if (why === 'stall') st.stalls++;
      paintRec();
    };
    const go = () => {
      if (rec.state !== 'paused' || v.paused || v.seeking || v.readyState < 3) return;
      rec.resume(); st.lastResume = performance.now(); st.paused = false; st.holdWhy = null; paintRec();
    };
    st.onPause = () => hold('pause');
    st.onPlay = () => go();
    st.onWaiting = () => hold('stall');
    st.onSeeking = () => hold('seek');
    st.onResize = () => { st.resizes++; };
    v.addEventListener('waiting', st.onWaiting); v.addEventListener('seeking', st.onSeeking);
    v.addEventListener('playing', st.onPlay); v.addEventListener('canplay', st.onPlay); v.addEventListener('seeked', st.onPlay);
    v.addEventListener('resize', st.onResize);
    st.onEnded = () => stopRecording('ended');
    v.addEventListener('pause', st.onPause); v.addEventListener('play', st.onPlay); v.addEventListener('ended', st.onEnded);
    stream.getTracks().forEach((t) => t.addEventListener('ended', st.onEnded, { once: true }));
    rec.start(1000);
    setPhase('recording');
    const pill = el('div', 'mq-rec');
    pill.append(el('span', 'mq-rec-dot'), el('span', 'mq-rec-txt', 'تسجيل 0:00'));
    pill.title = 'اضغط لإيقاف التسجيل';
    pill.addEventListener('click', (e) => { e.stopPropagation(); stopRecording('user'); });
    (player() || document.body).appendChild(pill);
    st.recEl = pill;
    st.tick = setInterval(paintRec, 500);
  }
  function pickMime() {
    const pref = settings.recordCodec;
    const list0 = [['video/mp4;codecs=avc1.640028,mp4a.40.2', 'mp4'], ['video/mp4;codecs=avc1.4d002a,mp4a.40.2', 'mp4'], ['video/mp4;codecs=avc1,mp4a.40.2', 'mp4'], ['video/mp4;codecs=avc1,opus', 'mp4'], ['video/mp4', 'mp4'], ['video/webm;codecs=vp9,opus', 'webm'], ['video/webm;codecs=vp8,opus', 'webm'], ['video/webm', 'webm']];
    const list = pref === 'webm' ? [...list0.filter((x) => x[1] === 'webm'), ...list0] : pref === 'mp4' ? list0 : list0;
    for (const [m, ext] of list) if (MediaRecorder.isTypeSupported(m)) return { m, ext };
    return { m: '', ext: 'webm' };
  }
  const elapsedMs = () => st.activeMs + (st.paused ? 0 : performance.now() - st.lastResume);
  function paintRec() {
    if (!st.recEl) return;
    st.recEl.querySelector('.mq-rec-txt').textContent = (st.paused ? (st.holdWhy === 'stall' ? 'ينتظر التحميل ' : 'متوقّف مؤقتًا ') : 'تسجيل ') + MQ.fmtTime(elapsedMs() / 1000);
    st.recEl.classList.toggle('mq-paused', st.paused);
  }
  function stopRecording(reason) {
    if (st.phase !== 'recording') return;
    const v = st.video;
    st.end = v ? v.currentTime : st.end;
    st.activeMs = elapsedMs(); st.paused = true;
    clearInterval(st.tick); st.tick = null; st.recEl?.remove(); st.recEl = null;
    if (v) {
      v.removeEventListener('pause', st.onPause); v.removeEventListener('play', st.onPlay); v.removeEventListener('ended', st.onEnded);
      v.removeEventListener('waiting', st.onWaiting); v.removeEventListener('seeking', st.onSeeking);
      v.removeEventListener('playing', st.onPlay); v.removeEventListener('canplay', st.onPlay); v.removeEventListener('seeked', st.onPlay);
      v.removeEventListener('resize', st.onResize);
      if (st.prevRate) v.playbackRate = st.prevRate;
    }
    setPhase('saving');
    unlockQuality();
    if (reason === 'nav') toast('انتقلتَ إلى صفحة أخرى، فأوقفتُ التسجيل.');
    try { if (st.recorder && st.recorder.state !== 'inactive') st.recorder.stop(); else finalize(); } catch (_) { finalize(); }
  }
  function finalize() {
    if (st.phase !== 'saving') return;
    const blob = new Blob(st.chunks, { type: st.mime || 'video/webm' });
    st.chunks = []; st.recorder = null; st.stream = null;
    const dur = st.activeMs / 1000;
    if (blob.size < 2000 || dur < 0.5) { setPhase('idle'); toast('المقطع قصير جدًّا، فلم يُحفظ.', 'err'); return; }
    if (st.stalls) toast(`توقّف المقطع ${st.stalls === 1 ? 'مرة' : st.stalls + ' مرات'} للتحميل أثناء التسجيل، فأوقفتُ المسجّل معه حتى لا تتجمّد الصورة.`, null, 4200);
    openCapture(blob, {
      ...st.meta, start: st.start, end: st.end, duration: dur, stalls: st.stalls || 0, resizes: st.resizes || 0,
      link: MQ.timeLink(st.meta.videoId, st.start), mime: blob.type, ext: st.ext, size: blob.size, thumb: st.thumb,
      speaker: (st.cur && st.cur.record && st.cur.record.speaker) || st.meta.channel,
      series: (st.cur && st.cur.record && st.cur.record.series) || st.meta.series,
    });
  }

  // ================= نافذة الالتقاط =================
  function openCapture(blob, m) {
    const v = video();
    st.wasPlaying = !!(v && !v.paused);
    if (settings.pauseWhileEditing && v && !v.paused) v.pause();
    const wrap = el('div', 'mq-modal');
    const frame = document.createElement('iframe');
    frame.className = 'mq-frame';
    frame.src = URLX('pages/capture.html');
    frame.addEventListener('load', () => frame.contentWindow.postMessage({ type: 'mq:clip', blob, meta: m }, EXT), { once: true });
    wrap.appendChild(frame);
    document.documentElement.appendChild(wrap);
    requestAnimationFrame(() => wrap.classList.add('mq-show'));
    st.modal = { wrap, frame };
    setPhase('editing');
    setTimeout(() => frame.focus(), 60);
  }

  // ================= رسائل الإطارات (الالتقاط والدفتر) =================
  window.addEventListener('message', (e) => {
    if (e.origin !== EXT || !e.data || typeof e.data !== 'object') return;
    const d = e.data;
    const fromModal = st.modal && e.source === st.modal.frame.contentWindow;
    const fromDrawer = st.drawer && e.source === st.drawer.frame.contentWindow;
    if (!fromModal && !fromDrawer) return;
    const v = video();
    if (d.type === 'mq:close' && fromModal) {
      const w = st.modal.wrap; st.modal = null;
      w.classList.remove('mq-show'); setTimeout(() => w.remove(), 250);
      setPhase('idle');
      if (settings.pauseWhileEditing && st.wasPlaying && v && v.paused && !w.classList.contains('mq-mini')) v.play().catch(() => {});
      if (d.toast) toast(d.toast, d.kind);
      loadNotesCount();
    }
    if (d.type === 'mq:mini' && fromModal) {
      st.modal.wrap.classList.toggle('mq-mini', !!d.on);
      // في الوضع المصغّر نعيد تشغيل المحاضرة إن كنّا أوقفناها
      if (d.on && settings.pauseWhileEditing && st.wasPlaying && v && v.paused) v.play().catch(() => {});
    }
    const reply = (payload) => e.source.postMessage({ type: 'mq:reply', id: d.id, ...payload }, EXT);
    if (d.type === 'mq:getTime') reply({ t: v ? v.currentTime : 0, playing: v ? !v.paused : false });
    if (d.type === 'mq:seek' && v) { v.currentTime = Number(d.t) || 0; if (d.play) v.play().catch(() => {}); }
    if (d.type === 'mq:pause' && v) v.pause();
    if (d.type === 'mq:play' && v) v.play().catch(() => {});
    if (d.type === 'mq:meta') reply({ meta: { ...meta(), duration: v ? v.duration : 0, speaker: (st.cur && st.cur.record && st.cur.record.speaker) || channelName(), series: (st.cur && st.cur.record && st.cur.record.series) || playlistTitle() } });
    if (d.type === 'mq:closeDrawer') closeDrawer();
    if (d.type === 'mq:notesChanged') loadNotesCount();
    if (d.type === 'mq:openApp') send({ type: 'mq:openApp', hash: d.hash || '' });
  });

  // ================= التنقّل داخل يوتيوب =================
  let lastVid = null;
  function onNav() {
    const id = isWatch() ? vid() : null;
    if (id !== lastVid) {
      if (lastVid) flush();
      lastVid = id;
      if (st.drawer) closeDrawer();
      if (!id && st.focus) toggleFocus(false);
      if (id) loadVideoState();
    }
    ensurePlayerButton(); ensureBar();
  }
  window.addEventListener('yt-navigate-start', () => {
    if (st.phase === 'countdown') cancelCountdown();
    if (st.phase === 'recording') stopRecording('nav');
    flush();
  });
  window.addEventListener('yt-navigate-finish', onNav);
  let obsT = null;
  new MutationObserver(() => {
    if (obsT) return;
    obsT = setTimeout(() => { obsT = null; if (isWatch()) { ensurePlayerButton(); ensureBar(); if (vid() !== lastVid) onNav(); } }, 500);
  }).observe(document.documentElement, { childList: true, subtree: true });
  function paint() { paintButton(); if (isWatch()) ensureBar(); }
  onNav();
})();
