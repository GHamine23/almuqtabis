// المقتبس — يعمل في سياق صفحة يوتيوب نفسها: يلتقط ملفات الترجمة التي يطلبها المشغّل، ويتحكّم في الترجمة عند الحاجة.
(() => {
  if (window.__mqHook) return;
  window.__mqHook = true;
  const isCaps = (u) => typeof u === 'string' && u.includes('/api/timedtext');
  const post = (url, body) => { try { window.postMessage({ __mq: 'captions', url, body }, location.origin); } catch (_) {} };

  const ofetch = window.fetch;
  window.fetch = function (input, init) {
    const url = typeof input === 'string' ? input : (input && input.url) || '';
    const p = ofetch.apply(this, arguments);
    if (isCaps(url)) p.then((r) => r.clone().text().then((t) => t && post(url, t))).catch(() => {});
    return p;
  };
  const oopen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, url) {
    this.__mqUrl = url;
    return oopen.apply(this, arguments);
  };
  const osend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function () {
    if (isCaps(String(this.__mqUrl || ''))) {
      this.addEventListener('load', () => {
        try { if (this.responseType === '' || this.responseType === 'text') post(String(this.__mqUrl), this.responseText); } catch (_) {}
      });
    }
    return osend.apply(this, arguments);
  };

  // أوامر من الإضافة
  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data.__mq !== 'cmd') return;
    const p = document.getElementById('movie_player');
    if (!p) return;
    // تثبيت الجودة أثناء الاقتباس: تبديل الجودة في منتصف التسجيل يجمّد الصورة لحظات
    if (e.data.cmd === 'lockQuality') {
      try {
        const levels = (p.getAvailableQualityLevels && p.getAvailableQualityLevels()) || [];
        const cur = p.getPlaybackQuality ? p.getPlaybackQuality() : '';
        const best = levels.find((q) => q !== 'auto') || cur;
        if (best && typeof p.setPlaybackQualityRange === 'function') {
          p.setPlaybackQualityRange(best, best);
          window.__mqLocked = { prev: cur, changed: best !== cur };
        }
        window.postMessage({ __mq: 'quality', best, cur }, location.origin);
      } catch (_) {}
      return;
    }
    if (e.data.cmd === 'unlockQuality') {
      try {
        const l = window.__mqLocked; window.__mqLocked = null;
        if (l && typeof p.setPlaybackQualityRange === 'function') {
          // نعيد الجودة كما كانت: إن كانت محدّدة يدويًّا ثبّتناها عليها، وإلا أعدناها تلقائية
          let manual = false;
          try { const j = JSON.parse(localStorage.getItem('yt-player-quality') || 'null'); manual = !!(j && j.data && JSON.parse(j.data).quality); } catch (_) {}
          if (manual && l.prev) p.setPlaybackQualityRange(l.prev, l.prev); else p.setPlaybackQualityRange('auto', 'auto');
        }
      } catch (_) {}
      return;
    }
    if (typeof p.getOption !== 'function') return;
    try {
      if (e.data.cmd === 'loadCaptions') {
        try { p.loadModule('captions'); } catch (_) {}
        const tracks = p.getOption('captions', 'tracklist') || [];
        const before = p.getOption('captions', 'track') || {};
        const want = e.data.lang || 'ar';
        const pick = tracks.find((t) => t.languageCode === want && t.kind !== 'asr') ||
          tracks.find((t) => t.languageCode === want) || tracks.find((t) => (t.languageCode || '').startsWith(want)) || tracks[0];
        window.postMessage({ __mq: 'captionsInfo', count: tracks.length, lang: pick ? pick.languageCode : '', kind: pick ? (pick.kind || 'manual') : '', hadOn: !!before.languageCode }, location.origin);
        if (pick) {
          p.setOption('captions', 'track', pick);
          if (!before.languageCode && e.data.restore) setTimeout(() => { try { p.unloadModule('captions'); } catch (_) {} }, 2500);
        }
      }
    } catch (_) {}
  });
})();
